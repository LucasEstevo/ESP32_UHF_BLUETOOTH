﻿namespace SimpleReaderDemo.MySingleForm.TestForm.FunctionForm
{
    partial class FunctionWriteUserData_GB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FunctionWriteUserData_GB));
            this.label3 = new System.Windows.Forms.Label();
            this.gb_NowSelectTag = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_SelectTID = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.tb_SelectEPC = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.tb_WriteUserData = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_AccessPwd = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_WriteEPCLength = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.btn_Write = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.cb_WriteUser_DataType = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.gb_NowSelectTag.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Name = "label3";
            // 
            // gb_NowSelectTag
            // 
            this.gb_NowSelectTag.BackColor = System.Drawing.Color.Transparent;
            this.gb_NowSelectTag.Controls.Add(this.label2);
            this.gb_NowSelectTag.Controls.Add(this.label1);
            this.gb_NowSelectTag.Controls.Add(this.tb_SelectTID);
            this.gb_NowSelectTag.Controls.Add(this.tb_SelectEPC);
            resources.ApplyResources(this.gb_NowSelectTag, "gb_NowSelectTag");
            this.gb_NowSelectTag.Name = "gb_NowSelectTag";
            this.gb_NowSelectTag.TabStop = false;
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // tb_SelectTID
            // 
            this.tb_SelectTID.BackColor = System.Drawing.Color.Transparent;
            this.tb_SelectTID.Icon = null;
            this.tb_SelectTID.IconIsButton = false;
            this.tb_SelectTID.IsPasswordChat = '\0';
            this.tb_SelectTID.IsSystemPasswordChar = false;
            this.tb_SelectTID.Lines = new string[0];
            resources.ApplyResources(this.tb_SelectTID, "tb_SelectTID");
            this.tb_SelectTID.MaxLength = 32767;
            this.tb_SelectTID.Multiline = false;
            this.tb_SelectTID.Name = "tb_SelectTID";
            this.tb_SelectTID.ReadOnly = true;
            this.tb_SelectTID.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_SelectTID.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_SelectTID.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_SelectTID.WaterText = "";
            this.tb_SelectTID.WordWrap = true;
            // 
            // tb_SelectEPC
            // 
            this.tb_SelectEPC.BackColor = System.Drawing.Color.Transparent;
            this.tb_SelectEPC.Icon = null;
            this.tb_SelectEPC.IconIsButton = false;
            this.tb_SelectEPC.IsPasswordChat = '\0';
            this.tb_SelectEPC.IsSystemPasswordChar = false;
            this.tb_SelectEPC.Lines = new string[0];
            resources.ApplyResources(this.tb_SelectEPC, "tb_SelectEPC");
            this.tb_SelectEPC.MaxLength = 32767;
            this.tb_SelectEPC.Multiline = false;
            this.tb_SelectEPC.Name = "tb_SelectEPC";
            this.tb_SelectEPC.ReadOnly = true;
            this.tb_SelectEPC.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_SelectEPC.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_SelectEPC.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_SelectEPC.WaterText = "";
            this.tb_SelectEPC.WordWrap = true;
            // 
            // tb_WriteUserData
            // 
            this.tb_WriteUserData.BackColor = System.Drawing.Color.Transparent;
            this.tb_WriteUserData.Icon = null;
            this.tb_WriteUserData.IconIsButton = false;
            this.tb_WriteUserData.IsPasswordChat = '\0';
            this.tb_WriteUserData.IsSystemPasswordChar = false;
            this.tb_WriteUserData.Lines = new string[0];
            resources.ApplyResources(this.tb_WriteUserData, "tb_WriteUserData");
            this.tb_WriteUserData.MaxLength = 32767;
            this.tb_WriteUserData.Multiline = true;
            this.tb_WriteUserData.Name = "tb_WriteUserData";
            this.tb_WriteUserData.ReadOnly = false;
            this.tb_WriteUserData.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_WriteUserData.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_WriteUserData.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_WriteUserData.WaterText = "0F0F";
            this.tb_WriteUserData.WordWrap = true;
            this.tb_WriteUserData.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tb_WriteEPCData_KeyUp);
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label5.Name = "label5";
            // 
            // tb_AccessPwd
            // 
            this.tb_AccessPwd.BackColor = System.Drawing.Color.Transparent;
            this.tb_AccessPwd.Icon = null;
            this.tb_AccessPwd.IconIsButton = false;
            this.tb_AccessPwd.IsPasswordChat = '\0';
            this.tb_AccessPwd.IsSystemPasswordChar = false;
            this.tb_AccessPwd.Lines = new string[0];
            resources.ApplyResources(this.tb_AccessPwd, "tb_AccessPwd");
            this.tb_AccessPwd.MaxLength = 32767;
            this.tb_AccessPwd.Multiline = false;
            this.tb_AccessPwd.Name = "tb_AccessPwd";
            this.tb_AccessPwd.ReadOnly = false;
            this.tb_AccessPwd.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_AccessPwd.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_AccessPwd.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_AccessPwd.WaterText = "00000000";
            this.tb_AccessPwd.WordWrap = true;
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Name = "label4";
            // 
            // tb_WriteEPCLength
            // 
            this.tb_WriteEPCLength.BackColor = System.Drawing.Color.Transparent;
            this.tb_WriteEPCLength.Icon = null;
            this.tb_WriteEPCLength.IconIsButton = false;
            this.tb_WriteEPCLength.IsPasswordChat = '\0';
            this.tb_WriteEPCLength.IsSystemPasswordChar = false;
            this.tb_WriteEPCLength.Lines = new string[] {
        "0"};
            resources.ApplyResources(this.tb_WriteEPCLength, "tb_WriteEPCLength");
            this.tb_WriteEPCLength.MaxLength = 32767;
            this.tb_WriteEPCLength.Multiline = false;
            this.tb_WriteEPCLength.Name = "tb_WriteEPCLength";
            this.tb_WriteEPCLength.ReadOnly = true;
            this.tb_WriteEPCLength.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_WriteEPCLength.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_WriteEPCLength.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_WriteEPCLength.WaterText = "";
            this.tb_WriteEPCLength.WordWrap = true;
            // 
            // btn_Write
            // 
            this.btn_Write.BackColor = System.Drawing.Color.Transparent;
            this.btn_Write.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_Write.DownImage")));
            resources.ApplyResources(this.btn_Write, "btn_Write");
            this.btn_Write.IsShowBorder = true;
            this.btn_Write.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_Write.MoveImage")));
            this.btn_Write.Name = "btn_Write";
            this.btn_Write.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_Write.NormalImage")));
            this.btn_Write.UseVisualStyleBackColor = false;
            this.btn_Write.Click += new System.EventHandler(this.btn_Write_Click);
            // 
            // cb_WriteUser_DataType
            // 
            this.cb_WriteUser_DataType.FormattingEnabled = true;
            this.cb_WriteUser_DataType.Items.AddRange(new object[] {
            resources.GetString("cb_WriteUser_DataType.Items"),
            resources.GetString("cb_WriteUser_DataType.Items1"),
            resources.GetString("cb_WriteUser_DataType.Items2"),
            resources.GetString("cb_WriteUser_DataType.Items3"),
            resources.GetString("cb_WriteUser_DataType.Items4"),
            resources.GetString("cb_WriteUser_DataType.Items5"),
            resources.GetString("cb_WriteUser_DataType.Items6"),
            resources.GetString("cb_WriteUser_DataType.Items7"),
            resources.GetString("cb_WriteUser_DataType.Items8"),
            resources.GetString("cb_WriteUser_DataType.Items9"),
            resources.GetString("cb_WriteUser_DataType.Items10"),
            resources.GetString("cb_WriteUser_DataType.Items11"),
            resources.GetString("cb_WriteUser_DataType.Items12"),
            resources.GetString("cb_WriteUser_DataType.Items13"),
            resources.GetString("cb_WriteUser_DataType.Items14"),
            resources.GetString("cb_WriteUser_DataType.Items15")});
            resources.ApplyResources(this.cb_WriteUser_DataType, "cb_WriteUser_DataType");
            this.cb_WriteUser_DataType.Name = "cb_WriteUser_DataType";
            this.cb_WriteUser_DataType.SelectedIndexChanged += new System.EventHandler(this.cb_WriteUser_DataType_SelectedIndexChanged);
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Name = "label6";
            // 
            // FunctionWriteUserData_GB
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cb_WriteUser_DataType);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.gb_NowSelectTag);
            this.Controls.Add(this.tb_WriteUserData);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tb_AccessPwd);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tb_WriteEPCLength);
            this.Controls.Add(this.btn_Write);
            this.IsResize = false;
            this.Name = "FunctionWriteUserData_GB";
            this.ShowIcon = false;
            this.SysButton = SimpleReaderDemo.Forms.ESysButton.Close;
            this.Load += new System.EventHandler(this.FunctionWriteUserData_Load);
            this.gb_NowSelectTag.ResumeLayout(false);
            this.gb_NowSelectTag.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox gb_NowSelectTag;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private MyFormTemplet.QQTextBoxEx tb_SelectTID;
        private MyFormTemplet.QQTextBoxEx tb_SelectEPC;
        private MyFormTemplet.QQTextBoxEx tb_WriteUserData;
        private System.Windows.Forms.Label label5;
        private MyFormTemplet.QQTextBoxEx tb_AccessPwd;
        private System.Windows.Forms.Label label4;
        private MyFormTemplet.QQTextBoxEx tb_WriteEPCLength;
        private MyFormTemplet.QQButton btn_Write;
        private System.Windows.Forms.ComboBox cb_WriteUser_DataType;
        private System.Windows.Forms.Label label6;
    }
}