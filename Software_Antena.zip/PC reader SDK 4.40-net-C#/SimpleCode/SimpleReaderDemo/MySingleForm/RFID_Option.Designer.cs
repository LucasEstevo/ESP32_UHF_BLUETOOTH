﻿namespace SimpleReaderDemo.MySingleForm.TestForm
{
    partial class RFID_Option
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RFID_Option));
            this.toolTipTextBox = new System.Windows.Forms.ToolTip(this.components);
            this.tb_0001_08_01 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.tb_0001_08_03 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.tb_0001_08_04 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.tp_RestoreFactory = new System.Windows.Forms.TabPage();
            this.btn_RestoreFactory = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.tp_GPIO = new System.Windows.Forms.TabPage();
            this.gb_GPI = new System.Windows.Forms.GroupBox();
            this.btn_0001_0A_GET = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.btn_GPI_4 = new SimpleReaderDemo.MyFormTemplet.RoundButton();
            this.btn_GPI_3 = new SimpleReaderDemo.MyFormTemplet.RoundButton();
            this.btn_GPI_2 = new SimpleReaderDemo.MyFormTemplet.RoundButton();
            this.btn_GPI_1 = new SimpleReaderDemo.MyFormTemplet.RoundButton();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.gb_GPO = new System.Windows.Forms.GroupBox();
            this.cmb_GPO_4 = new System.Windows.Forms.ComboBox();
            this.cmb_GPO_2 = new System.Windows.Forms.ComboBox();
            this.cmb_GPO_3 = new System.Windows.Forms.ComboBox();
            this.cmb_GPO_1 = new System.Windows.Forms.ComboBox();
            this.btn_0001_09_Hight = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.chk_GPO_4 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.chk_GPO_3 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.chk_GPO_2 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.chk_GPO_1 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.btn_0001_0E_Get = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.btn_0001_0D_Get = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.label38 = new System.Windows.Forms.Label();
            this.cb_0001_0D_02 = new System.Windows.Forms.ComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.cb_0001_0D_01 = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.cb_0001_0D_00 = new System.Windows.Forms.ComboBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.lb_upload = new System.Windows.Forms.Label();
            this.cb_0001_0B_05 = new System.Windows.Forms.ComboBox();
            this.lb_DelayTime_1 = new System.Windows.Forms.Label();
            this.btn_0001_0C_Get = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.btn_0001_0B_Set = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.tb_0001_0B_04 = new System.Windows.Forms.TextBox();
            this.lb_DelayTime = new System.Windows.Forms.Label();
            this.cb_0001_0B_03 = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.tb_0001_0B_02 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.cb_0001_0B_01 = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.cb_0001_0B_00 = new System.Windows.Forms.ComboBox();
            this.tp_ReaderSet = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tbxSelfCheckIP = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.cmbSelfCheck = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_0001_17_Set = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.btn_0001_18_Get = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.cmb_0001_17_00 = new System.Windows.Forms.ComboBox();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.btn_0001_15_Set = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.btn_0001_16_Get = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.label39 = new System.Windows.Forms.Label();
            this.tb_0001_15_00 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.btn_0001_07_Set = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.btn_0001_08_Get = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.rb_0001_08_02 = new SimpleReaderDemo.MyFormTemplet.QQRadioButton();
            this.rb_0001_08_00 = new SimpleReaderDemo.MyFormTemplet.QQRadioButton();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.tb_0001_10_00 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.btn_0001_10_Set = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.btn_0001_11_Get = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.tb_0001_06_00 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.btn_0001_13_Set = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.btn_0001_06_Get = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.btn_0001_05_Set = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.btn_0001_04_Get = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tb_0001_04_00 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label11 = new System.Windows.Forms.Label();
            this.tb_0001_04_02 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.tb_0001_04_01 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_0001_02_Set = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.btn_0001_02_Get = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.cb_0001_02_00 = new System.Windows.Forms.ComboBox();
            this.tp_Main = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cb_FrequencySingle = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.cb_ANTSingle = new System.Windows.Forms.ComboBox();
            this.btn_0101_05 = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.cb_0010_03 = new System.Windows.Forms.ComboBox();
            this.btn_Set_0010_03 = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.btn_0010_04_Get = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.btn_0010_0B_Set = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.btn_0010_0C_Get = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.cb_0010_0B_03 = new System.Windows.Forms.ComboBox();
            this.cb_0010_0B_02 = new System.Windows.Forms.ComboBox();
            this.cb_0010_0B_01 = new System.Windows.Forms.ComboBox();
            this.cb_0010_0B_00 = new System.Windows.Forms.ComboBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btn_0010_09_Set = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.btn_0010_0A_Get = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tb_0010_09_01 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.tb_0010_09_00 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.gb_ANTEnable = new System.Windows.Forms.GroupBox();
            this.cb_0010_07_08 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_07_07 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_07_06 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_07_05 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_07_04 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_07_03 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_07_02 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_07_01 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.pl_New24Ant = new System.Windows.Forms.Panel();
            this.ANT24 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.ANT23 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.ANT22 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.ANT21 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.ANT20 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.ANT19 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.ANT18 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.ANT17 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.ANT16 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.ANT15 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.ANT14 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.ANT13 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.ANT12 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.ANT11 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.ANT10 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.ANT9 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.btn_0010_07_Set = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.btn_0010_08_Get = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.cb_0010_05_01 = new SimpleReaderDemo.MyFormTemplet.CheckedComboBox();
            this.btn_0010_05_Set = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.btn_0010_06_Get = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.cb_0010_05_00 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label40 = new System.Windows.Forms.Label();
            this.btn_0010_0D_Set = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.btn_0010_0E_Get = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.label16 = new System.Windows.Forms.Label();
            this.tb_0010_0D_01 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.cb_0010_0D_00 = new System.Windows.Forms.ComboBox();
            this.gb_SetANTPower = new System.Windows.Forms.GroupBox();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.cb_0010_01_24 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_24 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_23 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_23 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_22 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_22 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_21 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_21 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_20 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_20 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_19 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_19 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_18 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_18 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_17 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_17 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_16 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_16 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_15 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_15 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_14 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_14 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_13 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_13 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_12 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_12 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_11 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_11 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_10 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_10 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_09 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_09 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_08 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_08 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_07 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_07 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_06 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_06 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_05 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_05 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.btn_0010_01_Set = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.btn_0010_02_Get = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.cb_0010_01_04 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_04 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_03 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_03 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_02 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_02 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_0010_01_01 = new System.Windows.Forms.ComboBox();
            this.chk_0010_01_01 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.tc_Main = new SimpleReaderDemo.MyFormTemplet.QQTabControl();
            this.tp_RestoreFactory.SuspendLayout();
            this.tp_GPIO.SuspendLayout();
            this.gb_GPI.SuspendLayout();
            this.gb_GPO.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.tp_ReaderSet.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tp_Main.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.gb_ANTEnable.SuspendLayout();
            this.pl_New24Ant.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.gb_SetANTPower.SuspendLayout();
            this.tc_Main.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb_0001_08_01
            // 
            this.tb_0001_08_01.BackColor = System.Drawing.Color.Transparent;
            this.tb_0001_08_01.Icon = null;
            this.tb_0001_08_01.IconIsButton = false;
            this.tb_0001_08_01.IsPasswordChat = '\0';
            this.tb_0001_08_01.IsSystemPasswordChar = false;
            this.tb_0001_08_01.Lines = new string[0];
            resources.ApplyResources(this.tb_0001_08_01, "tb_0001_08_01");
            this.tb_0001_08_01.MaxLength = 32767;
            this.tb_0001_08_01.Multiline = false;
            this.tb_0001_08_01.Name = "tb_0001_08_01";
            this.tb_0001_08_01.ReadOnly = false;
            this.tb_0001_08_01.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_0001_08_01.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.toolTipTextBox.SetToolTip(this.tb_0001_08_01, resources.GetString("tb_0001_08_01.ToolTip"));
            this.tb_0001_08_01.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_0001_08_01.WaterText = "9090";
            this.tb_0001_08_01.WordWrap = true;
            // 
            // tb_0001_08_03
            // 
            this.tb_0001_08_03.BackColor = System.Drawing.Color.Transparent;
            this.tb_0001_08_03.Icon = null;
            this.tb_0001_08_03.IconIsButton = false;
            this.tb_0001_08_03.IsPasswordChat = '\0';
            this.tb_0001_08_03.IsSystemPasswordChar = false;
            this.tb_0001_08_03.Lines = new string[0];
            resources.ApplyResources(this.tb_0001_08_03, "tb_0001_08_03");
            this.tb_0001_08_03.MaxLength = 32767;
            this.tb_0001_08_03.Multiline = false;
            this.tb_0001_08_03.Name = "tb_0001_08_03";
            this.tb_0001_08_03.ReadOnly = false;
            this.tb_0001_08_03.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_0001_08_03.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.toolTipTextBox.SetToolTip(this.tb_0001_08_03, resources.GetString("tb_0001_08_03.ToolTip"));
            this.tb_0001_08_03.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_0001_08_03.WaterText = "192.168.1.1";
            this.tb_0001_08_03.WordWrap = true;
            // 
            // tb_0001_08_04
            // 
            this.tb_0001_08_04.BackColor = System.Drawing.Color.Transparent;
            this.tb_0001_08_04.Icon = null;
            this.tb_0001_08_04.IconIsButton = false;
            this.tb_0001_08_04.IsPasswordChat = '\0';
            this.tb_0001_08_04.IsSystemPasswordChar = false;
            this.tb_0001_08_04.Lines = new string[0];
            resources.ApplyResources(this.tb_0001_08_04, "tb_0001_08_04");
            this.tb_0001_08_04.MaxLength = 32767;
            this.tb_0001_08_04.Multiline = false;
            this.tb_0001_08_04.Name = "tb_0001_08_04";
            this.tb_0001_08_04.ReadOnly = false;
            this.tb_0001_08_04.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_0001_08_04.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.toolTipTextBox.SetToolTip(this.tb_0001_08_04, resources.GetString("tb_0001_08_04.ToolTip"));
            this.tb_0001_08_04.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_0001_08_04.WaterText = "9090";
            this.tb_0001_08_04.WordWrap = true;
            // 
            // tp_RestoreFactory
            // 
            this.tp_RestoreFactory.BackColor = System.Drawing.Color.White;
            this.tp_RestoreFactory.Controls.Add(this.btn_RestoreFactory);
            resources.ApplyResources(this.tp_RestoreFactory, "tp_RestoreFactory");
            this.tp_RestoreFactory.Name = "tp_RestoreFactory";
            // 
            // btn_RestoreFactory
            // 
            this.btn_RestoreFactory.BackColor = System.Drawing.Color.Transparent;
            this.btn_RestoreFactory.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_RestoreFactory.DownImage")));
            resources.ApplyResources(this.btn_RestoreFactory, "btn_RestoreFactory");
            this.btn_RestoreFactory.IsShowBorder = true;
            this.btn_RestoreFactory.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_RestoreFactory.MoveImage")));
            this.btn_RestoreFactory.Name = "btn_RestoreFactory";
            this.btn_RestoreFactory.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_RestoreFactory.NormalImage")));
            this.btn_RestoreFactory.UseVisualStyleBackColor = true;
            this.btn_RestoreFactory.Click += new System.EventHandler(this.btn_RestoreFactory_Click);
            // 
            // tp_GPIO
            // 
            this.tp_GPIO.BackColor = System.Drawing.Color.White;
            this.tp_GPIO.Controls.Add(this.gb_GPI);
            this.tp_GPIO.Controls.Add(this.gb_GPO);
            this.tp_GPIO.Controls.Add(this.groupBox19);
            this.tp_GPIO.Controls.Add(this.groupBox12);
            resources.ApplyResources(this.tp_GPIO, "tp_GPIO");
            this.tp_GPIO.Name = "tp_GPIO";
            // 
            // gb_GPI
            // 
            this.gb_GPI.Controls.Add(this.btn_0001_0A_GET);
            this.gb_GPI.Controls.Add(this.btn_GPI_4);
            this.gb_GPI.Controls.Add(this.btn_GPI_3);
            this.gb_GPI.Controls.Add(this.btn_GPI_2);
            this.gb_GPI.Controls.Add(this.btn_GPI_1);
            this.gb_GPI.Controls.Add(this.label32);
            this.gb_GPI.Controls.Add(this.label33);
            this.gb_GPI.Controls.Add(this.label34);
            this.gb_GPI.Controls.Add(this.label35);
            this.gb_GPI.Controls.Add(this.label26);
            resources.ApplyResources(this.gb_GPI, "gb_GPI");
            this.gb_GPI.Name = "gb_GPI";
            this.gb_GPI.TabStop = false;
            // 
            // btn_0001_0A_GET
            // 
            this.btn_0001_0A_GET.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_0A_GET.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_0A_GET.DownImage")));
            resources.ApplyResources(this.btn_0001_0A_GET, "btn_0001_0A_GET");
            this.btn_0001_0A_GET.IsShowBorder = true;
            this.btn_0001_0A_GET.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_0A_GET.MoveImage")));
            this.btn_0001_0A_GET.Name = "btn_0001_0A_GET";
            this.btn_0001_0A_GET.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_0A_GET.NormalImage")));
            this.btn_0001_0A_GET.UseVisualStyleBackColor = false;
            this.btn_0001_0A_GET.Click += new System.EventHandler(this.btn_0001_0A_GET_Click);
            // 
            // btn_GPI_4
            // 
            this.btn_GPI_4.BackColor = System.Drawing.Color.Blue;
            resources.ApplyResources(this.btn_GPI_4, "btn_GPI_4");
            this.btn_GPI_4.Name = "btn_GPI_4";
            this.btn_GPI_4.Radius = 15;
            this.btn_GPI_4.Tag = "4";
            this.btn_GPI_4.UseVisualStyleBackColor = false;
            // 
            // btn_GPI_3
            // 
            this.btn_GPI_3.BackColor = System.Drawing.Color.Blue;
            resources.ApplyResources(this.btn_GPI_3, "btn_GPI_3");
            this.btn_GPI_3.Name = "btn_GPI_3";
            this.btn_GPI_3.Radius = 15;
            this.btn_GPI_3.Tag = "3";
            this.btn_GPI_3.UseVisualStyleBackColor = false;
            // 
            // btn_GPI_2
            // 
            this.btn_GPI_2.BackColor = System.Drawing.Color.Blue;
            resources.ApplyResources(this.btn_GPI_2, "btn_GPI_2");
            this.btn_GPI_2.Name = "btn_GPI_2";
            this.btn_GPI_2.Radius = 15;
            this.btn_GPI_2.Tag = "2";
            this.btn_GPI_2.UseVisualStyleBackColor = false;
            // 
            // btn_GPI_1
            // 
            this.btn_GPI_1.BackColor = System.Drawing.Color.Blue;
            resources.ApplyResources(this.btn_GPI_1, "btn_GPI_1");
            this.btn_GPI_1.Name = "btn_GPI_1";
            this.btn_GPI_1.Radius = 15;
            this.btn_GPI_1.Tag = "1";
            this.btn_GPI_1.UseVisualStyleBackColor = false;
            // 
            // label32
            // 
            resources.ApplyResources(this.label32, "label32");
            this.label32.Name = "label32";
            // 
            // label33
            // 
            resources.ApplyResources(this.label33, "label33");
            this.label33.Name = "label33";
            // 
            // label34
            // 
            resources.ApplyResources(this.label34, "label34");
            this.label34.Name = "label34";
            // 
            // label35
            // 
            resources.ApplyResources(this.label35, "label35");
            this.label35.Name = "label35";
            // 
            // label26
            // 
            resources.ApplyResources(this.label26, "label26");
            this.label26.Name = "label26";
            // 
            // gb_GPO
            // 
            this.gb_GPO.Controls.Add(this.cmb_GPO_4);
            this.gb_GPO.Controls.Add(this.cmb_GPO_2);
            this.gb_GPO.Controls.Add(this.cmb_GPO_3);
            this.gb_GPO.Controls.Add(this.cmb_GPO_1);
            this.gb_GPO.Controls.Add(this.btn_0001_09_Hight);
            this.gb_GPO.Controls.Add(this.chk_GPO_4);
            this.gb_GPO.Controls.Add(this.chk_GPO_3);
            this.gb_GPO.Controls.Add(this.chk_GPO_2);
            this.gb_GPO.Controls.Add(this.chk_GPO_1);
            resources.ApplyResources(this.gb_GPO, "gb_GPO");
            this.gb_GPO.Name = "gb_GPO";
            this.gb_GPO.TabStop = false;
            // 
            // cmb_GPO_4
            // 
            this.cmb_GPO_4.FormattingEnabled = true;
            this.cmb_GPO_4.Items.AddRange(new object[] {
            resources.GetString("cmb_GPO_4.Items"),
            resources.GetString("cmb_GPO_4.Items1")});
            resources.ApplyResources(this.cmb_GPO_4, "cmb_GPO_4");
            this.cmb_GPO_4.Name = "cmb_GPO_4";
            // 
            // cmb_GPO_2
            // 
            this.cmb_GPO_2.FormattingEnabled = true;
            this.cmb_GPO_2.Items.AddRange(new object[] {
            resources.GetString("cmb_GPO_2.Items"),
            resources.GetString("cmb_GPO_2.Items1")});
            resources.ApplyResources(this.cmb_GPO_2, "cmb_GPO_2");
            this.cmb_GPO_2.Name = "cmb_GPO_2";
            // 
            // cmb_GPO_3
            // 
            this.cmb_GPO_3.FormattingEnabled = true;
            this.cmb_GPO_3.Items.AddRange(new object[] {
            resources.GetString("cmb_GPO_3.Items"),
            resources.GetString("cmb_GPO_3.Items1")});
            resources.ApplyResources(this.cmb_GPO_3, "cmb_GPO_3");
            this.cmb_GPO_3.Name = "cmb_GPO_3";
            // 
            // cmb_GPO_1
            // 
            this.cmb_GPO_1.FormattingEnabled = true;
            this.cmb_GPO_1.Items.AddRange(new object[] {
            resources.GetString("cmb_GPO_1.Items"),
            resources.GetString("cmb_GPO_1.Items1")});
            resources.ApplyResources(this.cmb_GPO_1, "cmb_GPO_1");
            this.cmb_GPO_1.Name = "cmb_GPO_1";
            // 
            // btn_0001_09_Hight
            // 
            this.btn_0001_09_Hight.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_09_Hight.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_09_Hight.DownImage")));
            resources.ApplyResources(this.btn_0001_09_Hight, "btn_0001_09_Hight");
            this.btn_0001_09_Hight.IsShowBorder = true;
            this.btn_0001_09_Hight.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_09_Hight.MoveImage")));
            this.btn_0001_09_Hight.Name = "btn_0001_09_Hight";
            this.btn_0001_09_Hight.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_09_Hight.NormalImage")));
            this.btn_0001_09_Hight.UseVisualStyleBackColor = false;
            this.btn_0001_09_Hight.Click += new System.EventHandler(this.btn_0001_09_Hight_Click);
            // 
            // chk_GPO_4
            // 
            resources.ApplyResources(this.chk_GPO_4, "chk_GPO_4");
            this.chk_GPO_4.BackColor = System.Drawing.Color.Transparent;
            this.chk_GPO_4.Name = "chk_GPO_4";
            this.chk_GPO_4.Tag = "4";
            this.chk_GPO_4.UseVisualStyleBackColor = false;
            // 
            // chk_GPO_3
            // 
            resources.ApplyResources(this.chk_GPO_3, "chk_GPO_3");
            this.chk_GPO_3.BackColor = System.Drawing.Color.Transparent;
            this.chk_GPO_3.Name = "chk_GPO_3";
            this.chk_GPO_3.Tag = "3";
            this.chk_GPO_3.UseVisualStyleBackColor = false;
            // 
            // chk_GPO_2
            // 
            resources.ApplyResources(this.chk_GPO_2, "chk_GPO_2");
            this.chk_GPO_2.BackColor = System.Drawing.Color.Transparent;
            this.chk_GPO_2.Name = "chk_GPO_2";
            this.chk_GPO_2.Tag = "2";
            this.chk_GPO_2.UseVisualStyleBackColor = false;
            // 
            // chk_GPO_1
            // 
            resources.ApplyResources(this.chk_GPO_1, "chk_GPO_1");
            this.chk_GPO_1.BackColor = System.Drawing.Color.Transparent;
            this.chk_GPO_1.Name = "chk_GPO_1";
            this.chk_GPO_1.Tag = "1";
            this.chk_GPO_1.UseVisualStyleBackColor = false;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.btn_0001_0E_Get);
            this.groupBox19.Controls.Add(this.btn_0001_0D_Get);
            this.groupBox19.Controls.Add(this.label38);
            this.groupBox19.Controls.Add(this.cb_0001_0D_02);
            this.groupBox19.Controls.Add(this.label37);
            this.groupBox19.Controls.Add(this.cb_0001_0D_01);
            this.groupBox19.Controls.Add(this.label36);
            this.groupBox19.Controls.Add(this.cb_0001_0D_00);
            resources.ApplyResources(this.groupBox19, "groupBox19");
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.TabStop = false;
            // 
            // btn_0001_0E_Get
            // 
            this.btn_0001_0E_Get.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_0E_Get.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_0E_Get.DownImage")));
            resources.ApplyResources(this.btn_0001_0E_Get, "btn_0001_0E_Get");
            this.btn_0001_0E_Get.IsShowBorder = true;
            this.btn_0001_0E_Get.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_0E_Get.MoveImage")));
            this.btn_0001_0E_Get.Name = "btn_0001_0E_Get";
            this.btn_0001_0E_Get.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_0E_Get.NormalImage")));
            this.btn_0001_0E_Get.UseVisualStyleBackColor = false;
            this.btn_0001_0E_Get.Click += new System.EventHandler(this.btn_0001_0E_Get_Click);
            // 
            // btn_0001_0D_Get
            // 
            this.btn_0001_0D_Get.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_0D_Get.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_0D_Get.DownImage")));
            resources.ApplyResources(this.btn_0001_0D_Get, "btn_0001_0D_Get");
            this.btn_0001_0D_Get.IsShowBorder = true;
            this.btn_0001_0D_Get.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_0D_Get.MoveImage")));
            this.btn_0001_0D_Get.Name = "btn_0001_0D_Get";
            this.btn_0001_0D_Get.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_0D_Get.NormalImage")));
            this.btn_0001_0D_Get.UseVisualStyleBackColor = false;
            this.btn_0001_0D_Get.Click += new System.EventHandler(this.btn_0001_0D_Get_Click);
            // 
            // label38
            // 
            resources.ApplyResources(this.label38, "label38");
            this.label38.Name = "label38";
            // 
            // cb_0001_0D_02
            // 
            this.cb_0001_0D_02.FormattingEnabled = true;
            this.cb_0001_0D_02.Items.AddRange(new object[] {
            resources.GetString("cb_0001_0D_02.Items"),
            resources.GetString("cb_0001_0D_02.Items1")});
            resources.ApplyResources(this.cb_0001_0D_02, "cb_0001_0D_02");
            this.cb_0001_0D_02.Name = "cb_0001_0D_02";
            // 
            // label37
            // 
            resources.ApplyResources(this.label37, "label37");
            this.label37.Name = "label37";
            // 
            // cb_0001_0D_01
            // 
            this.cb_0001_0D_01.FormattingEnabled = true;
            this.cb_0001_0D_01.Items.AddRange(new object[] {
            resources.GetString("cb_0001_0D_01.Items"),
            resources.GetString("cb_0001_0D_01.Items1"),
            resources.GetString("cb_0001_0D_01.Items2")});
            resources.ApplyResources(this.cb_0001_0D_01, "cb_0001_0D_01");
            this.cb_0001_0D_01.Name = "cb_0001_0D_01";
            // 
            // label36
            // 
            resources.ApplyResources(this.label36, "label36");
            this.label36.Name = "label36";
            // 
            // cb_0001_0D_00
            // 
            this.cb_0001_0D_00.FormattingEnabled = true;
            this.cb_0001_0D_00.Items.AddRange(new object[] {
            resources.GetString("cb_0001_0D_00.Items"),
            resources.GetString("cb_0001_0D_00.Items1")});
            resources.ApplyResources(this.cb_0001_0D_00, "cb_0001_0D_00");
            this.cb_0001_0D_00.Name = "cb_0001_0D_00";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.lb_upload);
            this.groupBox12.Controls.Add(this.cb_0001_0B_05);
            this.groupBox12.Controls.Add(this.lb_DelayTime_1);
            this.groupBox12.Controls.Add(this.btn_0001_0C_Get);
            this.groupBox12.Controls.Add(this.btn_0001_0B_Set);
            this.groupBox12.Controls.Add(this.tb_0001_0B_04);
            this.groupBox12.Controls.Add(this.lb_DelayTime);
            this.groupBox12.Controls.Add(this.cb_0001_0B_03);
            this.groupBox12.Controls.Add(this.label24);
            this.groupBox12.Controls.Add(this.tb_0001_0B_02);
            this.groupBox12.Controls.Add(this.label23);
            this.groupBox12.Controls.Add(this.cb_0001_0B_01);
            this.groupBox12.Controls.Add(this.label22);
            this.groupBox12.Controls.Add(this.label21);
            this.groupBox12.Controls.Add(this.cb_0001_0B_00);
            resources.ApplyResources(this.groupBox12, "groupBox12");
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.TabStop = false;
            // 
            // lb_upload
            // 
            resources.ApplyResources(this.lb_upload, "lb_upload");
            this.lb_upload.Name = "lb_upload";
            // 
            // cb_0001_0B_05
            // 
            this.cb_0001_0B_05.FormattingEnabled = true;
            this.cb_0001_0B_05.Items.AddRange(new object[] {
            resources.GetString("cb_0001_0B_05.Items"),
            resources.GetString("cb_0001_0B_05.Items1")});
            resources.ApplyResources(this.cb_0001_0B_05, "cb_0001_0B_05");
            this.cb_0001_0B_05.Name = "cb_0001_0B_05";
            // 
            // lb_DelayTime_1
            // 
            resources.ApplyResources(this.lb_DelayTime_1, "lb_DelayTime_1");
            this.lb_DelayTime_1.Name = "lb_DelayTime_1";
            // 
            // btn_0001_0C_Get
            // 
            this.btn_0001_0C_Get.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_0C_Get.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_0C_Get.DownImage")));
            resources.ApplyResources(this.btn_0001_0C_Get, "btn_0001_0C_Get");
            this.btn_0001_0C_Get.IsShowBorder = true;
            this.btn_0001_0C_Get.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_0C_Get.MoveImage")));
            this.btn_0001_0C_Get.Name = "btn_0001_0C_Get";
            this.btn_0001_0C_Get.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_0C_Get.NormalImage")));
            this.btn_0001_0C_Get.UseVisualStyleBackColor = false;
            this.btn_0001_0C_Get.Click += new System.EventHandler(this.btn_0001_0C_Get_Click);
            // 
            // btn_0001_0B_Set
            // 
            this.btn_0001_0B_Set.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_0B_Set.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_0B_Set.DownImage")));
            resources.ApplyResources(this.btn_0001_0B_Set, "btn_0001_0B_Set");
            this.btn_0001_0B_Set.IsShowBorder = true;
            this.btn_0001_0B_Set.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_0B_Set.MoveImage")));
            this.btn_0001_0B_Set.Name = "btn_0001_0B_Set";
            this.btn_0001_0B_Set.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_0B_Set.NormalImage")));
            this.btn_0001_0B_Set.UseVisualStyleBackColor = false;
            this.btn_0001_0B_Set.Click += new System.EventHandler(this.btn_0001_0B_Set_Click);
            // 
            // tb_0001_0B_04
            // 
            resources.ApplyResources(this.tb_0001_0B_04, "tb_0001_0B_04");
            this.tb_0001_0B_04.Name = "tb_0001_0B_04";
            // 
            // lb_DelayTime
            // 
            resources.ApplyResources(this.lb_DelayTime, "lb_DelayTime");
            this.lb_DelayTime.Name = "lb_DelayTime";
            // 
            // cb_0001_0B_03
            // 
            this.cb_0001_0B_03.FormattingEnabled = true;
            this.cb_0001_0B_03.Items.AddRange(new object[] {
            resources.GetString("cb_0001_0B_03.Items"),
            resources.GetString("cb_0001_0B_03.Items1"),
            resources.GetString("cb_0001_0B_03.Items2"),
            resources.GetString("cb_0001_0B_03.Items3"),
            resources.GetString("cb_0001_0B_03.Items4"),
            resources.GetString("cb_0001_0B_03.Items5"),
            resources.GetString("cb_0001_0B_03.Items6")});
            resources.ApplyResources(this.cb_0001_0B_03, "cb_0001_0B_03");
            this.cb_0001_0B_03.Name = "cb_0001_0B_03";
            this.cb_0001_0B_03.SelectedIndexChanged += new System.EventHandler(this.cb_0001_0B_03_SelectedIndexChanged);
            // 
            // label24
            // 
            resources.ApplyResources(this.label24, "label24");
            this.label24.Name = "label24";
            // 
            // tb_0001_0B_02
            // 
            resources.ApplyResources(this.tb_0001_0B_02, "tb_0001_0B_02");
            this.tb_0001_0B_02.Name = "tb_0001_0B_02";
            // 
            // label23
            // 
            resources.ApplyResources(this.label23, "label23");
            this.label23.Name = "label23";
            // 
            // cb_0001_0B_01
            // 
            this.cb_0001_0B_01.FormattingEnabled = true;
            this.cb_0001_0B_01.Items.AddRange(new object[] {
            resources.GetString("cb_0001_0B_01.Items"),
            resources.GetString("cb_0001_0B_01.Items1"),
            resources.GetString("cb_0001_0B_01.Items2"),
            resources.GetString("cb_0001_0B_01.Items3"),
            resources.GetString("cb_0001_0B_01.Items4"),
            resources.GetString("cb_0001_0B_01.Items5")});
            resources.ApplyResources(this.cb_0001_0B_01, "cb_0001_0B_01");
            this.cb_0001_0B_01.Name = "cb_0001_0B_01";
            // 
            // label22
            // 
            resources.ApplyResources(this.label22, "label22");
            this.label22.Name = "label22";
            // 
            // label21
            // 
            resources.ApplyResources(this.label21, "label21");
            this.label21.Name = "label21";
            // 
            // cb_0001_0B_00
            // 
            this.cb_0001_0B_00.FormattingEnabled = true;
            this.cb_0001_0B_00.Items.AddRange(new object[] {
            resources.GetString("cb_0001_0B_00.Items"),
            resources.GetString("cb_0001_0B_00.Items1"),
            resources.GetString("cb_0001_0B_00.Items2"),
            resources.GetString("cb_0001_0B_00.Items3")});
            resources.ApplyResources(this.cb_0001_0B_00, "cb_0001_0B_00");
            this.cb_0001_0B_00.Name = "cb_0001_0B_00";
            this.cb_0001_0B_00.SelectedIndexChanged += new System.EventHandler(this.cb_0001_0B_00_SelectedIndexChanged);
            // 
            // tp_ReaderSet
            // 
            this.tp_ReaderSet.BackColor = System.Drawing.Color.White;
            this.tp_ReaderSet.Controls.Add(this.groupBox5);
            this.tp_ReaderSet.Controls.Add(this.groupBox1);
            this.tp_ReaderSet.Controls.Add(this.groupBox20);
            this.tp_ReaderSet.Controls.Add(this.groupBox18);
            this.tp_ReaderSet.Controls.Add(this.groupBox17);
            this.tp_ReaderSet.Controls.Add(this.groupBox16);
            this.tp_ReaderSet.Controls.Add(this.groupBox14);
            this.tp_ReaderSet.Controls.Add(this.groupBox2);
            resources.ApplyResources(this.tp_ReaderSet, "tp_ReaderSet");
            this.tp_ReaderSet.Name = "tp_ReaderSet";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.tbxSelfCheckIP);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.button2);
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.cmbSelfCheck);
            resources.ApplyResources(this.groupBox5, "groupBox5");
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.TabStop = false;
            // 
            // tbxSelfCheckIP
            // 
            this.tbxSelfCheckIP.BackColor = System.Drawing.Color.Transparent;
            this.tbxSelfCheckIP.Icon = null;
            this.tbxSelfCheckIP.IconIsButton = false;
            this.tbxSelfCheckIP.IsPasswordChat = '\0';
            this.tbxSelfCheckIP.IsSystemPasswordChar = false;
            this.tbxSelfCheckIP.Lines = new string[0];
            resources.ApplyResources(this.tbxSelfCheckIP, "tbxSelfCheckIP");
            this.tbxSelfCheckIP.MaxLength = 32767;
            this.tbxSelfCheckIP.Multiline = false;
            this.tbxSelfCheckIP.Name = "tbxSelfCheckIP";
            this.tbxSelfCheckIP.ReadOnly = false;
            this.tbxSelfCheckIP.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbxSelfCheckIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbxSelfCheckIP.WaterColor = System.Drawing.Color.DarkGray;
            this.tbxSelfCheckIP.WaterText = "192.168.1.116";
            this.tbxSelfCheckIP.WordWrap = true;
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // button2
            // 
            resources.ApplyResources(this.button2, "button2");
            this.button2.Name = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cmbSelfCheck
            // 
            this.cmbSelfCheck.FormattingEnabled = true;
            this.cmbSelfCheck.Items.AddRange(new object[] {
            resources.GetString("cmbSelfCheck.Items"),
            resources.GetString("cmbSelfCheck.Items1")});
            resources.ApplyResources(this.cmbSelfCheck, "cmbSelfCheck");
            this.cmbSelfCheck.Name = "cmbSelfCheck";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btn_0001_17_Set);
            this.groupBox1.Controls.Add(this.btn_0001_18_Get);
            this.groupBox1.Controls.Add(this.cmb_0001_17_00);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // btn_0001_17_Set
            // 
            this.btn_0001_17_Set.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_17_Set.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_17_Set.DownImage")));
            resources.ApplyResources(this.btn_0001_17_Set, "btn_0001_17_Set");
            this.btn_0001_17_Set.IsShowBorder = true;
            this.btn_0001_17_Set.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_17_Set.MoveImage")));
            this.btn_0001_17_Set.Name = "btn_0001_17_Set";
            this.btn_0001_17_Set.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_17_Set.NormalImage")));
            this.btn_0001_17_Set.UseVisualStyleBackColor = false;
            this.btn_0001_17_Set.Click += new System.EventHandler(this.btn_0001_17_Set_Click);
            // 
            // btn_0001_18_Get
            // 
            this.btn_0001_18_Get.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_18_Get.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_18_Get.DownImage")));
            resources.ApplyResources(this.btn_0001_18_Get, "btn_0001_18_Get");
            this.btn_0001_18_Get.IsShowBorder = true;
            this.btn_0001_18_Get.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_18_Get.MoveImage")));
            this.btn_0001_18_Get.Name = "btn_0001_18_Get";
            this.btn_0001_18_Get.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_18_Get.NormalImage")));
            this.btn_0001_18_Get.UseVisualStyleBackColor = false;
            this.btn_0001_18_Get.Click += new System.EventHandler(this.btn_0001_18_Get_Click);
            // 
            // cmb_0001_17_00
            // 
            this.cmb_0001_17_00.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_0001_17_00.FormattingEnabled = true;
            this.cmb_0001_17_00.Items.AddRange(new object[] {
            resources.GetString("cmb_0001_17_00.Items"),
            resources.GetString("cmb_0001_17_00.Items1")});
            resources.ApplyResources(this.cmb_0001_17_00, "cmb_0001_17_00");
            this.cmb_0001_17_00.Name = "cmb_0001_17_00";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.btn_0001_15_Set);
            this.groupBox20.Controls.Add(this.btn_0001_16_Get);
            this.groupBox20.Controls.Add(this.label39);
            this.groupBox20.Controls.Add(this.tb_0001_15_00);
            resources.ApplyResources(this.groupBox20, "groupBox20");
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.TabStop = false;
            // 
            // btn_0001_15_Set
            // 
            this.btn_0001_15_Set.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_15_Set.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_15_Set.DownImage")));
            resources.ApplyResources(this.btn_0001_15_Set, "btn_0001_15_Set");
            this.btn_0001_15_Set.IsShowBorder = true;
            this.btn_0001_15_Set.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_15_Set.MoveImage")));
            this.btn_0001_15_Set.Name = "btn_0001_15_Set";
            this.btn_0001_15_Set.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_15_Set.NormalImage")));
            this.btn_0001_15_Set.UseVisualStyleBackColor = false;
            this.btn_0001_15_Set.Click += new System.EventHandler(this.btn_0001_15_Set_Click);
            // 
            // btn_0001_16_Get
            // 
            this.btn_0001_16_Get.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_16_Get.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_16_Get.DownImage")));
            resources.ApplyResources(this.btn_0001_16_Get, "btn_0001_16_Get");
            this.btn_0001_16_Get.IsShowBorder = true;
            this.btn_0001_16_Get.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_16_Get.MoveImage")));
            this.btn_0001_16_Get.Name = "btn_0001_16_Get";
            this.btn_0001_16_Get.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_16_Get.NormalImage")));
            this.btn_0001_16_Get.UseVisualStyleBackColor = false;
            this.btn_0001_16_Get.Click += new System.EventHandler(this.btn_0001_16_Get_Click);
            // 
            // label39
            // 
            resources.ApplyResources(this.label39, "label39");
            this.label39.Name = "label39";
            // 
            // tb_0001_15_00
            // 
            this.tb_0001_15_00.BackColor = System.Drawing.Color.Transparent;
            this.tb_0001_15_00.Icon = null;
            this.tb_0001_15_00.IconIsButton = false;
            this.tb_0001_15_00.IsPasswordChat = '\0';
            this.tb_0001_15_00.IsSystemPasswordChar = false;
            this.tb_0001_15_00.Lines = new string[0];
            resources.ApplyResources(this.tb_0001_15_00, "tb_0001_15_00");
            this.tb_0001_15_00.MaxLength = 32767;
            this.tb_0001_15_00.Multiline = false;
            this.tb_0001_15_00.Name = "tb_0001_15_00";
            this.tb_0001_15_00.ReadOnly = false;
            this.tb_0001_15_00.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_0001_15_00.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_0001_15_00.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_0001_15_00.WaterText = "0-255";
            this.tb_0001_15_00.WordWrap = true;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.btn_0001_07_Set);
            this.groupBox18.Controls.Add(this.btn_0001_08_Get);
            this.groupBox18.Controls.Add(this.tb_0001_08_04);
            this.groupBox18.Controls.Add(this.tb_0001_08_03);
            this.groupBox18.Controls.Add(this.tb_0001_08_01);
            this.groupBox18.Controls.Add(this.rb_0001_08_02);
            this.groupBox18.Controls.Add(this.rb_0001_08_00);
            resources.ApplyResources(this.groupBox18, "groupBox18");
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.TabStop = false;
            // 
            // btn_0001_07_Set
            // 
            this.btn_0001_07_Set.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_07_Set.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_07_Set.DownImage")));
            resources.ApplyResources(this.btn_0001_07_Set, "btn_0001_07_Set");
            this.btn_0001_07_Set.IsShowBorder = true;
            this.btn_0001_07_Set.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_07_Set.MoveImage")));
            this.btn_0001_07_Set.Name = "btn_0001_07_Set";
            this.btn_0001_07_Set.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_07_Set.NormalImage")));
            this.btn_0001_07_Set.UseVisualStyleBackColor = false;
            this.btn_0001_07_Set.Click += new System.EventHandler(this.btn_0001_07_Set_Click);
            // 
            // btn_0001_08_Get
            // 
            this.btn_0001_08_Get.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_08_Get.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_08_Get.DownImage")));
            resources.ApplyResources(this.btn_0001_08_Get, "btn_0001_08_Get");
            this.btn_0001_08_Get.IsShowBorder = true;
            this.btn_0001_08_Get.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_08_Get.MoveImage")));
            this.btn_0001_08_Get.Name = "btn_0001_08_Get";
            this.btn_0001_08_Get.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_08_Get.NormalImage")));
            this.btn_0001_08_Get.UseVisualStyleBackColor = false;
            this.btn_0001_08_Get.Click += new System.EventHandler(this.btn_0001_08_Get_Click);
            // 
            // rb_0001_08_02
            // 
            resources.ApplyResources(this.rb_0001_08_02, "rb_0001_08_02");
            this.rb_0001_08_02.BackColor = System.Drawing.Color.Transparent;
            this.rb_0001_08_02.Name = "rb_0001_08_02";
            this.rb_0001_08_02.TabStop = true;
            this.rb_0001_08_02.UseVisualStyleBackColor = false;
            // 
            // rb_0001_08_00
            // 
            resources.ApplyResources(this.rb_0001_08_00, "rb_0001_08_00");
            this.rb_0001_08_00.BackColor = System.Drawing.Color.Transparent;
            this.rb_0001_08_00.Name = "rb_0001_08_00";
            this.rb_0001_08_00.TabStop = true;
            this.rb_0001_08_00.UseVisualStyleBackColor = false;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.tb_0001_10_00);
            this.groupBox17.Controls.Add(this.btn_0001_10_Set);
            this.groupBox17.Controls.Add(this.btn_0001_11_Get);
            resources.ApplyResources(this.groupBox17, "groupBox17");
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.TabStop = false;
            // 
            // tb_0001_10_00
            // 
            this.tb_0001_10_00.BackColor = System.Drawing.Color.Transparent;
            this.tb_0001_10_00.Icon = null;
            this.tb_0001_10_00.IconIsButton = false;
            this.tb_0001_10_00.IsPasswordChat = '\0';
            this.tb_0001_10_00.IsSystemPasswordChar = false;
            this.tb_0001_10_00.Lines = new string[0];
            resources.ApplyResources(this.tb_0001_10_00, "tb_0001_10_00");
            this.tb_0001_10_00.MaxLength = 32767;
            this.tb_0001_10_00.Multiline = false;
            this.tb_0001_10_00.Name = "tb_0001_10_00";
            this.tb_0001_10_00.ReadOnly = false;
            this.tb_0001_10_00.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_0001_10_00.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_0001_10_00.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_0001_10_00.WaterText = "1970.01.01 00:00:00.000";
            this.tb_0001_10_00.WordWrap = true;
            this.tb_0001_10_00.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tb_0001_10_00_MouseClick);
            // 
            // btn_0001_10_Set
            // 
            this.btn_0001_10_Set.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_10_Set.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_10_Set.DownImage")));
            resources.ApplyResources(this.btn_0001_10_Set, "btn_0001_10_Set");
            this.btn_0001_10_Set.IsShowBorder = true;
            this.btn_0001_10_Set.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_10_Set.MoveImage")));
            this.btn_0001_10_Set.Name = "btn_0001_10_Set";
            this.btn_0001_10_Set.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_10_Set.NormalImage")));
            this.btn_0001_10_Set.UseVisualStyleBackColor = false;
            this.btn_0001_10_Set.Click += new System.EventHandler(this.btn_0001_10_Set_Click);
            // 
            // btn_0001_11_Get
            // 
            this.btn_0001_11_Get.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_11_Get.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_11_Get.DownImage")));
            resources.ApplyResources(this.btn_0001_11_Get, "btn_0001_11_Get");
            this.btn_0001_11_Get.IsShowBorder = true;
            this.btn_0001_11_Get.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_11_Get.MoveImage")));
            this.btn_0001_11_Get.Name = "btn_0001_11_Get";
            this.btn_0001_11_Get.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_11_Get.NormalImage")));
            this.btn_0001_11_Get.UseVisualStyleBackColor = false;
            this.btn_0001_11_Get.Click += new System.EventHandler(this.btn_0001_11_Get_Click);
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.tb_0001_06_00);
            this.groupBox16.Controls.Add(this.btn_0001_13_Set);
            this.groupBox16.Controls.Add(this.btn_0001_06_Get);
            resources.ApplyResources(this.groupBox16, "groupBox16");
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.TabStop = false;
            // 
            // tb_0001_06_00
            // 
            this.tb_0001_06_00.BackColor = System.Drawing.Color.Transparent;
            this.tb_0001_06_00.Icon = null;
            this.tb_0001_06_00.IconIsButton = false;
            this.tb_0001_06_00.IsPasswordChat = '\0';
            this.tb_0001_06_00.IsSystemPasswordChar = false;
            this.tb_0001_06_00.Lines = new string[0];
            resources.ApplyResources(this.tb_0001_06_00, "tb_0001_06_00");
            this.tb_0001_06_00.MaxLength = 32767;
            this.tb_0001_06_00.Multiline = false;
            this.tb_0001_06_00.Name = "tb_0001_06_00";
            this.tb_0001_06_00.ReadOnly = false;
            this.tb_0001_06_00.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_0001_06_00.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_0001_06_00.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_0001_06_00.WaterText = "00-00-00-00-00-00";
            this.tb_0001_06_00.WordWrap = true;
            // 
            // btn_0001_13_Set
            // 
            this.btn_0001_13_Set.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_13_Set.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_13_Set.DownImage")));
            resources.ApplyResources(this.btn_0001_13_Set, "btn_0001_13_Set");
            this.btn_0001_13_Set.IsShowBorder = true;
            this.btn_0001_13_Set.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_13_Set.MoveImage")));
            this.btn_0001_13_Set.Name = "btn_0001_13_Set";
            this.btn_0001_13_Set.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_13_Set.NormalImage")));
            this.btn_0001_13_Set.UseVisualStyleBackColor = false;
            this.btn_0001_13_Set.Click += new System.EventHandler(this.btn_0001_13_Set_Click);
            // 
            // btn_0001_06_Get
            // 
            this.btn_0001_06_Get.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_06_Get.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_06_Get.DownImage")));
            resources.ApplyResources(this.btn_0001_06_Get, "btn_0001_06_Get");
            this.btn_0001_06_Get.IsShowBorder = true;
            this.btn_0001_06_Get.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_06_Get.MoveImage")));
            this.btn_0001_06_Get.Name = "btn_0001_06_Get";
            this.btn_0001_06_Get.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_06_Get.NormalImage")));
            this.btn_0001_06_Get.UseVisualStyleBackColor = false;
            this.btn_0001_06_Get.Click += new System.EventHandler(this.btn_0001_06_Get_Click);
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.btn_0001_05_Set);
            this.groupBox14.Controls.Add(this.btn_0001_04_Get);
            this.groupBox14.Controls.Add(this.label13);
            this.groupBox14.Controls.Add(this.label12);
            this.groupBox14.Controls.Add(this.tb_0001_04_00);
            this.groupBox14.Controls.Add(this.label11);
            this.groupBox14.Controls.Add(this.tb_0001_04_02);
            this.groupBox14.Controls.Add(this.tb_0001_04_01);
            resources.ApplyResources(this.groupBox14, "groupBox14");
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.TabStop = false;
            // 
            // btn_0001_05_Set
            // 
            this.btn_0001_05_Set.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_05_Set.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_05_Set.DownImage")));
            resources.ApplyResources(this.btn_0001_05_Set, "btn_0001_05_Set");
            this.btn_0001_05_Set.IsShowBorder = true;
            this.btn_0001_05_Set.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_05_Set.MoveImage")));
            this.btn_0001_05_Set.Name = "btn_0001_05_Set";
            this.btn_0001_05_Set.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_05_Set.NormalImage")));
            this.btn_0001_05_Set.UseVisualStyleBackColor = false;
            this.btn_0001_05_Set.Click += new System.EventHandler(this.btn_0001_05_Set_Click);
            // 
            // btn_0001_04_Get
            // 
            this.btn_0001_04_Get.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_04_Get.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_04_Get.DownImage")));
            resources.ApplyResources(this.btn_0001_04_Get, "btn_0001_04_Get");
            this.btn_0001_04_Get.IsShowBorder = true;
            this.btn_0001_04_Get.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_04_Get.MoveImage")));
            this.btn_0001_04_Get.Name = "btn_0001_04_Get";
            this.btn_0001_04_Get.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_04_Get.NormalImage")));
            this.btn_0001_04_Get.UseVisualStyleBackColor = false;
            this.btn_0001_04_Get.Click += new System.EventHandler(this.btn_0001_04_Get_Click);
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // tb_0001_04_00
            // 
            this.tb_0001_04_00.BackColor = System.Drawing.Color.Transparent;
            this.tb_0001_04_00.Icon = null;
            this.tb_0001_04_00.IconIsButton = false;
            this.tb_0001_04_00.IsPasswordChat = '\0';
            this.tb_0001_04_00.IsSystemPasswordChar = false;
            this.tb_0001_04_00.Lines = new string[0];
            resources.ApplyResources(this.tb_0001_04_00, "tb_0001_04_00");
            this.tb_0001_04_00.MaxLength = 32767;
            this.tb_0001_04_00.Multiline = false;
            this.tb_0001_04_00.Name = "tb_0001_04_00";
            this.tb_0001_04_00.ReadOnly = false;
            this.tb_0001_04_00.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_0001_04_00.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_0001_04_00.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_0001_04_00.WaterText = "192.168.1.88";
            this.tb_0001_04_00.WordWrap = true;
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            // 
            // tb_0001_04_02
            // 
            this.tb_0001_04_02.BackColor = System.Drawing.Color.Transparent;
            this.tb_0001_04_02.Icon = null;
            this.tb_0001_04_02.IconIsButton = false;
            this.tb_0001_04_02.IsPasswordChat = '\0';
            this.tb_0001_04_02.IsSystemPasswordChar = false;
            this.tb_0001_04_02.Lines = new string[0];
            resources.ApplyResources(this.tb_0001_04_02, "tb_0001_04_02");
            this.tb_0001_04_02.MaxLength = 32767;
            this.tb_0001_04_02.Multiline = false;
            this.tb_0001_04_02.Name = "tb_0001_04_02";
            this.tb_0001_04_02.ReadOnly = false;
            this.tb_0001_04_02.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_0001_04_02.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_0001_04_02.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_0001_04_02.WaterText = "192.168.1.1";
            this.tb_0001_04_02.WordWrap = true;
            // 
            // tb_0001_04_01
            // 
            this.tb_0001_04_01.BackColor = System.Drawing.Color.Transparent;
            this.tb_0001_04_01.Icon = null;
            this.tb_0001_04_01.IconIsButton = false;
            this.tb_0001_04_01.IsPasswordChat = '\0';
            this.tb_0001_04_01.IsSystemPasswordChar = false;
            this.tb_0001_04_01.Lines = new string[0];
            resources.ApplyResources(this.tb_0001_04_01, "tb_0001_04_01");
            this.tb_0001_04_01.MaxLength = 32767;
            this.tb_0001_04_01.Multiline = false;
            this.tb_0001_04_01.Name = "tb_0001_04_01";
            this.tb_0001_04_01.ReadOnly = false;
            this.tb_0001_04_01.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_0001_04_01.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_0001_04_01.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_0001_04_01.WaterText = "255.255.255.0";
            this.tb_0001_04_01.WordWrap = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_0001_02_Set);
            this.groupBox2.Controls.Add(this.btn_0001_02_Get);
            this.groupBox2.Controls.Add(this.cb_0001_02_00);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // btn_0001_02_Set
            // 
            this.btn_0001_02_Set.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_02_Set.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_02_Set.DownImage")));
            resources.ApplyResources(this.btn_0001_02_Set, "btn_0001_02_Set");
            this.btn_0001_02_Set.IsShowBorder = true;
            this.btn_0001_02_Set.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_02_Set.MoveImage")));
            this.btn_0001_02_Set.Name = "btn_0001_02_Set";
            this.btn_0001_02_Set.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_02_Set.NormalImage")));
            this.btn_0001_02_Set.UseVisualStyleBackColor = false;
            this.btn_0001_02_Set.Click += new System.EventHandler(this.btn_0001_02_Set_Click);
            // 
            // btn_0001_02_Get
            // 
            this.btn_0001_02_Get.BackColor = System.Drawing.Color.Transparent;
            this.btn_0001_02_Get.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_02_Get.DownImage")));
            resources.ApplyResources(this.btn_0001_02_Get, "btn_0001_02_Get");
            this.btn_0001_02_Get.IsShowBorder = true;
            this.btn_0001_02_Get.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_02_Get.MoveImage")));
            this.btn_0001_02_Get.Name = "btn_0001_02_Get";
            this.btn_0001_02_Get.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0001_02_Get.NormalImage")));
            this.btn_0001_02_Get.UseVisualStyleBackColor = false;
            this.btn_0001_02_Get.Click += new System.EventHandler(this.btn_0001_02_Get_Click);
            // 
            // cb_0001_02_00
            // 
            this.cb_0001_02_00.FormattingEnabled = true;
            this.cb_0001_02_00.Items.AddRange(new object[] {
            resources.GetString("cb_0001_02_00.Items"),
            resources.GetString("cb_0001_02_00.Items1"),
            resources.GetString("cb_0001_02_00.Items2"),
            resources.GetString("cb_0001_02_00.Items3"),
            resources.GetString("cb_0001_02_00.Items4")});
            resources.ApplyResources(this.cb_0001_02_00, "cb_0001_02_00");
            this.cb_0001_02_00.Name = "cb_0001_02_00";
            // 
            // tp_Main
            // 
            this.tp_Main.BackColor = System.Drawing.Color.White;
            this.tp_Main.Controls.Add(this.groupBox3);
            this.tp_Main.Controls.Add(this.groupBox6);
            this.tp_Main.Controls.Add(this.groupBox11);
            this.tp_Main.Controls.Add(this.groupBox10);
            this.tp_Main.Controls.Add(this.gb_ANTEnable);
            this.tp_Main.Controls.Add(this.groupBox8);
            this.tp_Main.Controls.Add(this.groupBox7);
            this.tp_Main.Controls.Add(this.gb_SetANTPower);
            resources.ApplyResources(this.tp_Main, "tp_Main");
            this.tp_Main.Name = "tp_Main";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cb_FrequencySingle);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.cb_ANTSingle);
            this.groupBox3.Controls.Add(this.btn_0101_05);
            resources.ApplyResources(this.groupBox3, "groupBox3");
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.TabStop = false;
            // 
            // cb_FrequencySingle
            // 
            this.cb_FrequencySingle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_FrequencySingle.FormattingEnabled = true;
            resources.ApplyResources(this.cb_FrequencySingle, "cb_FrequencySingle");
            this.cb_FrequencySingle.Name = "cb_FrequencySingle";
            // 
            // label27
            // 
            resources.ApplyResources(this.label27, "label27");
            this.label27.Name = "label27";
            // 
            // label25
            // 
            resources.ApplyResources(this.label25, "label25");
            this.label25.Name = "label25";
            // 
            // cb_ANTSingle
            // 
            this.cb_ANTSingle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_ANTSingle.FormattingEnabled = true;
            resources.ApplyResources(this.cb_ANTSingle, "cb_ANTSingle");
            this.cb_ANTSingle.Name = "cb_ANTSingle";
            // 
            // btn_0101_05
            // 
            this.btn_0101_05.BackColor = System.Drawing.Color.Transparent;
            this.btn_0101_05.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0101_05.DownImage")));
            resources.ApplyResources(this.btn_0101_05, "btn_0101_05");
            this.btn_0101_05.IsShowBorder = true;
            this.btn_0101_05.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0101_05.MoveImage")));
            this.btn_0101_05.Name = "btn_0101_05";
            this.btn_0101_05.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0101_05.NormalImage")));
            this.btn_0101_05.UseVisualStyleBackColor = true;
            this.btn_0101_05.Click += new System.EventHandler(this.btn_0101_05_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.cb_0010_03);
            this.groupBox6.Controls.Add(this.btn_Set_0010_03);
            this.groupBox6.Controls.Add(this.btn_0010_04_Get);
            resources.ApplyResources(this.groupBox6, "groupBox6");
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.TabStop = false;
            // 
            // cb_0010_03
            // 
            this.cb_0010_03.FormattingEnabled = true;
            this.cb_0010_03.Items.AddRange(new object[] {
            resources.GetString("cb_0010_03.Items"),
            resources.GetString("cb_0010_03.Items1"),
            resources.GetString("cb_0010_03.Items2"),
            resources.GetString("cb_0010_03.Items3"),
            resources.GetString("cb_0010_03.Items4"),
            resources.GetString("cb_0010_03.Items5"),
            resources.GetString("cb_0010_03.Items6"),
            resources.GetString("cb_0010_03.Items7"),
            resources.GetString("cb_0010_03.Items8"),
            resources.GetString("cb_0010_03.Items9"),
            resources.GetString("cb_0010_03.Items10")});
            resources.ApplyResources(this.cb_0010_03, "cb_0010_03");
            this.cb_0010_03.Name = "cb_0010_03";
            // 
            // btn_Set_0010_03
            // 
            this.btn_Set_0010_03.BackColor = System.Drawing.Color.Transparent;
            this.btn_Set_0010_03.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_Set_0010_03.DownImage")));
            resources.ApplyResources(this.btn_Set_0010_03, "btn_Set_0010_03");
            this.btn_Set_0010_03.IsShowBorder = true;
            this.btn_Set_0010_03.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_Set_0010_03.MoveImage")));
            this.btn_Set_0010_03.Name = "btn_Set_0010_03";
            this.btn_Set_0010_03.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_Set_0010_03.NormalImage")));
            this.btn_Set_0010_03.UseVisualStyleBackColor = true;
            this.btn_Set_0010_03.Click += new System.EventHandler(this.btn_Set_0010_03_Click);
            // 
            // btn_0010_04_Get
            // 
            this.btn_0010_04_Get.BackColor = System.Drawing.Color.Transparent;
            this.btn_0010_04_Get.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_04_Get.DownImage")));
            resources.ApplyResources(this.btn_0010_04_Get, "btn_0010_04_Get");
            this.btn_0010_04_Get.IsShowBorder = true;
            this.btn_0010_04_Get.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_04_Get.MoveImage")));
            this.btn_0010_04_Get.Name = "btn_0010_04_Get";
            this.btn_0010_04_Get.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_04_Get.NormalImage")));
            this.btn_0010_04_Get.UseVisualStyleBackColor = true;
            this.btn_0010_04_Get.Click += new System.EventHandler(this.btn_0010_04_Get_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label20);
            this.groupBox11.Controls.Add(this.label19);
            this.groupBox11.Controls.Add(this.label18);
            this.groupBox11.Controls.Add(this.label17);
            this.groupBox11.Controls.Add(this.btn_0010_0B_Set);
            this.groupBox11.Controls.Add(this.btn_0010_0C_Get);
            this.groupBox11.Controls.Add(this.cb_0010_0B_03);
            this.groupBox11.Controls.Add(this.cb_0010_0B_02);
            this.groupBox11.Controls.Add(this.cb_0010_0B_01);
            this.groupBox11.Controls.Add(this.cb_0010_0B_00);
            resources.ApplyResources(this.groupBox11, "groupBox11");
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.TabStop = false;
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.Name = "label20";
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.Name = "label19";
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.Name = "label18";
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.Name = "label17";
            // 
            // btn_0010_0B_Set
            // 
            this.btn_0010_0B_Set.BackColor = System.Drawing.Color.Transparent;
            this.btn_0010_0B_Set.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_0B_Set.DownImage")));
            resources.ApplyResources(this.btn_0010_0B_Set, "btn_0010_0B_Set");
            this.btn_0010_0B_Set.IsShowBorder = true;
            this.btn_0010_0B_Set.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_0B_Set.MoveImage")));
            this.btn_0010_0B_Set.Name = "btn_0010_0B_Set";
            this.btn_0010_0B_Set.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_0B_Set.NormalImage")));
            this.btn_0010_0B_Set.UseVisualStyleBackColor = false;
            this.btn_0010_0B_Set.Click += new System.EventHandler(this.btn_0010_0B_Set_Click);
            // 
            // btn_0010_0C_Get
            // 
            this.btn_0010_0C_Get.BackColor = System.Drawing.Color.Transparent;
            this.btn_0010_0C_Get.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_0C_Get.DownImage")));
            resources.ApplyResources(this.btn_0010_0C_Get, "btn_0010_0C_Get");
            this.btn_0010_0C_Get.IsShowBorder = true;
            this.btn_0010_0C_Get.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_0C_Get.MoveImage")));
            this.btn_0010_0C_Get.Name = "btn_0010_0C_Get";
            this.btn_0010_0C_Get.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_0C_Get.NormalImage")));
            this.btn_0010_0C_Get.UseVisualStyleBackColor = false;
            this.btn_0010_0C_Get.Click += new System.EventHandler(this.btn_0010_0C_Get_Click);
            // 
            // cb_0010_0B_03
            // 
            this.cb_0010_0B_03.FormattingEnabled = true;
            this.cb_0010_0B_03.Items.AddRange(new object[] {
            resources.GetString("cb_0010_0B_03.Items"),
            resources.GetString("cb_0010_0B_03.Items1"),
            resources.GetString("cb_0010_0B_03.Items2")});
            resources.ApplyResources(this.cb_0010_0B_03, "cb_0010_0B_03");
            this.cb_0010_0B_03.Name = "cb_0010_0B_03";
            // 
            // cb_0010_0B_02
            // 
            this.cb_0010_0B_02.FormattingEnabled = true;
            this.cb_0010_0B_02.Items.AddRange(new object[] {
            resources.GetString("cb_0010_0B_02.Items"),
            resources.GetString("cb_0010_0B_02.Items1"),
            resources.GetString("cb_0010_0B_02.Items2"),
            resources.GetString("cb_0010_0B_02.Items3")});
            resources.ApplyResources(this.cb_0010_0B_02, "cb_0010_0B_02");
            this.cb_0010_0B_02.Name = "cb_0010_0B_02";
            // 
            // cb_0010_0B_01
            // 
            this.cb_0010_0B_01.FormattingEnabled = true;
            this.cb_0010_0B_01.Items.AddRange(new object[] {
            resources.GetString("cb_0010_0B_01.Items"),
            resources.GetString("cb_0010_0B_01.Items1"),
            resources.GetString("cb_0010_0B_01.Items2"),
            resources.GetString("cb_0010_0B_01.Items3"),
            resources.GetString("cb_0010_0B_01.Items4"),
            resources.GetString("cb_0010_0B_01.Items5"),
            resources.GetString("cb_0010_0B_01.Items6"),
            resources.GetString("cb_0010_0B_01.Items7"),
            resources.GetString("cb_0010_0B_01.Items8"),
            resources.GetString("cb_0010_0B_01.Items9"),
            resources.GetString("cb_0010_0B_01.Items10"),
            resources.GetString("cb_0010_0B_01.Items11"),
            resources.GetString("cb_0010_0B_01.Items12"),
            resources.GetString("cb_0010_0B_01.Items13"),
            resources.GetString("cb_0010_0B_01.Items14"),
            resources.GetString("cb_0010_0B_01.Items15")});
            resources.ApplyResources(this.cb_0010_0B_01, "cb_0010_0B_01");
            this.cb_0010_0B_01.Name = "cb_0010_0B_01";
            // 
            // cb_0010_0B_00
            // 
            this.cb_0010_0B_00.FormattingEnabled = true;
            this.cb_0010_0B_00.Items.AddRange(new object[] {
            resources.GetString("cb_0010_0B_00.Items"),
            resources.GetString("cb_0010_0B_00.Items1"),
            resources.GetString("cb_0010_0B_00.Items2"),
            resources.GetString("cb_0010_0B_00.Items3"),
            resources.GetString("cb_0010_0B_00.Items4"),
            resources.GetString("cb_0010_0B_00.Items5"),
            resources.GetString("cb_0010_0B_00.Items6")});
            resources.ApplyResources(this.cb_0010_0B_00, "cb_0010_0B_00");
            this.cb_0010_0B_00.Name = "cb_0010_0B_00";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label10);
            this.groupBox10.Controls.Add(this.btn_0010_09_Set);
            this.groupBox10.Controls.Add(this.btn_0010_0A_Get);
            this.groupBox10.Controls.Add(this.label15);
            this.groupBox10.Controls.Add(this.label14);
            this.groupBox10.Controls.Add(this.tb_0010_09_01);
            this.groupBox10.Controls.Add(this.tb_0010_09_00);
            resources.ApplyResources(this.groupBox10, "groupBox10");
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.TabStop = false;
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // btn_0010_09_Set
            // 
            this.btn_0010_09_Set.BackColor = System.Drawing.Color.Transparent;
            this.btn_0010_09_Set.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_09_Set.DownImage")));
            resources.ApplyResources(this.btn_0010_09_Set, "btn_0010_09_Set");
            this.btn_0010_09_Set.IsShowBorder = true;
            this.btn_0010_09_Set.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_09_Set.MoveImage")));
            this.btn_0010_09_Set.Name = "btn_0010_09_Set";
            this.btn_0010_09_Set.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_09_Set.NormalImage")));
            this.btn_0010_09_Set.UseVisualStyleBackColor = false;
            this.btn_0010_09_Set.Click += new System.EventHandler(this.btn_0010_09_Set_Click);
            // 
            // btn_0010_0A_Get
            // 
            this.btn_0010_0A_Get.BackColor = System.Drawing.Color.Transparent;
            this.btn_0010_0A_Get.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_0A_Get.DownImage")));
            resources.ApplyResources(this.btn_0010_0A_Get, "btn_0010_0A_Get");
            this.btn_0010_0A_Get.IsShowBorder = true;
            this.btn_0010_0A_Get.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_0A_Get.MoveImage")));
            this.btn_0010_0A_Get.Name = "btn_0010_0A_Get";
            this.btn_0010_0A_Get.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_0A_Get.NormalImage")));
            this.btn_0010_0A_Get.UseVisualStyleBackColor = false;
            this.btn_0010_0A_Get.Click += new System.EventHandler(this.btn_0010_0A_Get_Click);
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            // 
            // tb_0010_09_01
            // 
            this.tb_0010_09_01.BackColor = System.Drawing.Color.Transparent;
            this.tb_0010_09_01.Icon = null;
            this.tb_0010_09_01.IconIsButton = false;
            this.tb_0010_09_01.IsPasswordChat = '\0';
            this.tb_0010_09_01.IsSystemPasswordChar = false;
            this.tb_0010_09_01.Lines = new string[0];
            resources.ApplyResources(this.tb_0010_09_01, "tb_0010_09_01");
            this.tb_0010_09_01.MaxLength = 32767;
            this.tb_0010_09_01.Multiline = false;
            this.tb_0010_09_01.Name = "tb_0010_09_01";
            this.tb_0010_09_01.ReadOnly = false;
            this.tb_0010_09_01.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_0010_09_01.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_0010_09_01.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_0010_09_01.WaterText = "255";
            this.tb_0010_09_01.WordWrap = true;
            // 
            // tb_0010_09_00
            // 
            this.tb_0010_09_00.BackColor = System.Drawing.Color.Transparent;
            this.tb_0010_09_00.Icon = null;
            this.tb_0010_09_00.IconIsButton = false;
            this.tb_0010_09_00.IsPasswordChat = '\0';
            this.tb_0010_09_00.IsSystemPasswordChar = false;
            this.tb_0010_09_00.Lines = new string[0];
            resources.ApplyResources(this.tb_0010_09_00, "tb_0010_09_00");
            this.tb_0010_09_00.MaxLength = 32767;
            this.tb_0010_09_00.Multiline = false;
            this.tb_0010_09_00.Name = "tb_0010_09_00";
            this.tb_0010_09_00.ReadOnly = false;
            this.tb_0010_09_00.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_0010_09_00.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_0010_09_00.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_0010_09_00.WaterText = "65535";
            this.tb_0010_09_00.WordWrap = true;
            // 
            // gb_ANTEnable
            // 
            this.gb_ANTEnable.Controls.Add(this.cb_0010_07_08);
            this.gb_ANTEnable.Controls.Add(this.cb_0010_07_07);
            this.gb_ANTEnable.Controls.Add(this.cb_0010_07_06);
            this.gb_ANTEnable.Controls.Add(this.cb_0010_07_05);
            this.gb_ANTEnable.Controls.Add(this.cb_0010_07_04);
            this.gb_ANTEnable.Controls.Add(this.cb_0010_07_03);
            this.gb_ANTEnable.Controls.Add(this.cb_0010_07_02);
            this.gb_ANTEnable.Controls.Add(this.cb_0010_07_01);
            this.gb_ANTEnable.Controls.Add(this.button14);
            this.gb_ANTEnable.Controls.Add(this.button13);
            this.gb_ANTEnable.Controls.Add(this.pl_New24Ant);
            this.gb_ANTEnable.Controls.Add(this.btn_0010_07_Set);
            this.gb_ANTEnable.Controls.Add(this.btn_0010_08_Get);
            resources.ApplyResources(this.gb_ANTEnable, "gb_ANTEnable");
            this.gb_ANTEnable.Name = "gb_ANTEnable";
            this.gb_ANTEnable.TabStop = false;
            // 
            // cb_0010_07_08
            // 
            resources.ApplyResources(this.cb_0010_07_08, "cb_0010_07_08");
            this.cb_0010_07_08.BackColor = System.Drawing.Color.Transparent;
            this.cb_0010_07_08.Name = "cb_0010_07_08";
            this.cb_0010_07_08.Tag = "128";
            this.cb_0010_07_08.UseVisualStyleBackColor = false;
            // 
            // cb_0010_07_07
            // 
            resources.ApplyResources(this.cb_0010_07_07, "cb_0010_07_07");
            this.cb_0010_07_07.BackColor = System.Drawing.Color.Transparent;
            this.cb_0010_07_07.Name = "cb_0010_07_07";
            this.cb_0010_07_07.Tag = "64";
            this.cb_0010_07_07.UseVisualStyleBackColor = false;
            // 
            // cb_0010_07_06
            // 
            resources.ApplyResources(this.cb_0010_07_06, "cb_0010_07_06");
            this.cb_0010_07_06.BackColor = System.Drawing.Color.Transparent;
            this.cb_0010_07_06.Name = "cb_0010_07_06";
            this.cb_0010_07_06.Tag = "32";
            this.cb_0010_07_06.UseVisualStyleBackColor = false;
            // 
            // cb_0010_07_05
            // 
            resources.ApplyResources(this.cb_0010_07_05, "cb_0010_07_05");
            this.cb_0010_07_05.BackColor = System.Drawing.Color.Transparent;
            this.cb_0010_07_05.Name = "cb_0010_07_05";
            this.cb_0010_07_05.Tag = "16";
            this.cb_0010_07_05.UseVisualStyleBackColor = false;
            // 
            // cb_0010_07_04
            // 
            resources.ApplyResources(this.cb_0010_07_04, "cb_0010_07_04");
            this.cb_0010_07_04.BackColor = System.Drawing.Color.Transparent;
            this.cb_0010_07_04.Name = "cb_0010_07_04";
            this.cb_0010_07_04.Tag = "8";
            this.cb_0010_07_04.UseVisualStyleBackColor = false;
            // 
            // cb_0010_07_03
            // 
            resources.ApplyResources(this.cb_0010_07_03, "cb_0010_07_03");
            this.cb_0010_07_03.BackColor = System.Drawing.Color.Transparent;
            this.cb_0010_07_03.Name = "cb_0010_07_03";
            this.cb_0010_07_03.Tag = "4";
            this.cb_0010_07_03.UseVisualStyleBackColor = false;
            // 
            // cb_0010_07_02
            // 
            resources.ApplyResources(this.cb_0010_07_02, "cb_0010_07_02");
            this.cb_0010_07_02.BackColor = System.Drawing.Color.Transparent;
            this.cb_0010_07_02.Name = "cb_0010_07_02";
            this.cb_0010_07_02.Tag = "2";
            this.cb_0010_07_02.UseVisualStyleBackColor = false;
            // 
            // cb_0010_07_01
            // 
            resources.ApplyResources(this.cb_0010_07_01, "cb_0010_07_01");
            this.cb_0010_07_01.BackColor = System.Drawing.Color.Transparent;
            this.cb_0010_07_01.Name = "cb_0010_07_01";
            this.cb_0010_07_01.Tag = "1";
            this.cb_0010_07_01.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            resources.ApplyResources(this.button14, "button14");
            this.button14.Name = "button14";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button13
            // 
            resources.ApplyResources(this.button13, "button13");
            this.button13.Name = "button13";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // pl_New24Ant
            // 
            this.pl_New24Ant.Controls.Add(this.ANT24);
            this.pl_New24Ant.Controls.Add(this.ANT23);
            this.pl_New24Ant.Controls.Add(this.ANT22);
            this.pl_New24Ant.Controls.Add(this.ANT21);
            this.pl_New24Ant.Controls.Add(this.ANT20);
            this.pl_New24Ant.Controls.Add(this.ANT19);
            this.pl_New24Ant.Controls.Add(this.ANT18);
            this.pl_New24Ant.Controls.Add(this.ANT17);
            this.pl_New24Ant.Controls.Add(this.ANT16);
            this.pl_New24Ant.Controls.Add(this.ANT15);
            this.pl_New24Ant.Controls.Add(this.ANT14);
            this.pl_New24Ant.Controls.Add(this.ANT13);
            this.pl_New24Ant.Controls.Add(this.ANT12);
            this.pl_New24Ant.Controls.Add(this.ANT11);
            this.pl_New24Ant.Controls.Add(this.ANT10);
            this.pl_New24Ant.Controls.Add(this.ANT9);
            resources.ApplyResources(this.pl_New24Ant, "pl_New24Ant");
            this.pl_New24Ant.Name = "pl_New24Ant";
            // 
            // ANT24
            // 
            resources.ApplyResources(this.ANT24, "ANT24");
            this.ANT24.BackColor = System.Drawing.Color.Transparent;
            this.ANT24.Name = "ANT24";
            this.ANT24.Tag = "32768";
            this.ANT24.UseVisualStyleBackColor = false;
            // 
            // ANT23
            // 
            resources.ApplyResources(this.ANT23, "ANT23");
            this.ANT23.BackColor = System.Drawing.Color.Transparent;
            this.ANT23.Name = "ANT23";
            this.ANT23.Tag = "16384";
            this.ANT23.UseVisualStyleBackColor = false;
            // 
            // ANT22
            // 
            resources.ApplyResources(this.ANT22, "ANT22");
            this.ANT22.BackColor = System.Drawing.Color.Transparent;
            this.ANT22.Name = "ANT22";
            this.ANT22.Tag = "8192";
            this.ANT22.UseVisualStyleBackColor = false;
            // 
            // ANT21
            // 
            resources.ApplyResources(this.ANT21, "ANT21");
            this.ANT21.BackColor = System.Drawing.Color.Transparent;
            this.ANT21.Name = "ANT21";
            this.ANT21.Tag = "4096";
            this.ANT21.UseVisualStyleBackColor = false;
            // 
            // ANT20
            // 
            resources.ApplyResources(this.ANT20, "ANT20");
            this.ANT20.BackColor = System.Drawing.Color.Transparent;
            this.ANT20.Name = "ANT20";
            this.ANT20.Tag = "2048";
            this.ANT20.UseVisualStyleBackColor = false;
            // 
            // ANT19
            // 
            resources.ApplyResources(this.ANT19, "ANT19");
            this.ANT19.BackColor = System.Drawing.Color.Transparent;
            this.ANT19.Name = "ANT19";
            this.ANT19.Tag = "1024";
            this.ANT19.UseVisualStyleBackColor = false;
            // 
            // ANT18
            // 
            resources.ApplyResources(this.ANT18, "ANT18");
            this.ANT18.BackColor = System.Drawing.Color.Transparent;
            this.ANT18.Name = "ANT18";
            this.ANT18.Tag = "512";
            this.ANT18.UseVisualStyleBackColor = false;
            // 
            // ANT17
            // 
            resources.ApplyResources(this.ANT17, "ANT17");
            this.ANT17.BackColor = System.Drawing.Color.Transparent;
            this.ANT17.Name = "ANT17";
            this.ANT17.Tag = "256";
            this.ANT17.UseVisualStyleBackColor = false;
            // 
            // ANT16
            // 
            resources.ApplyResources(this.ANT16, "ANT16");
            this.ANT16.BackColor = System.Drawing.Color.Transparent;
            this.ANT16.Name = "ANT16";
            this.ANT16.Tag = "128";
            this.ANT16.UseVisualStyleBackColor = false;
            // 
            // ANT15
            // 
            resources.ApplyResources(this.ANT15, "ANT15");
            this.ANT15.BackColor = System.Drawing.Color.Transparent;
            this.ANT15.Name = "ANT15";
            this.ANT15.Tag = "64";
            this.ANT15.UseVisualStyleBackColor = false;
            // 
            // ANT14
            // 
            resources.ApplyResources(this.ANT14, "ANT14");
            this.ANT14.BackColor = System.Drawing.Color.Transparent;
            this.ANT14.Name = "ANT14";
            this.ANT14.Tag = "32";
            this.ANT14.UseVisualStyleBackColor = false;
            // 
            // ANT13
            // 
            resources.ApplyResources(this.ANT13, "ANT13");
            this.ANT13.BackColor = System.Drawing.Color.Transparent;
            this.ANT13.Name = "ANT13";
            this.ANT13.Tag = "16";
            this.ANT13.UseVisualStyleBackColor = false;
            // 
            // ANT12
            // 
            resources.ApplyResources(this.ANT12, "ANT12");
            this.ANT12.BackColor = System.Drawing.Color.Transparent;
            this.ANT12.Name = "ANT12";
            this.ANT12.Tag = "8";
            this.ANT12.UseVisualStyleBackColor = false;
            // 
            // ANT11
            // 
            resources.ApplyResources(this.ANT11, "ANT11");
            this.ANT11.BackColor = System.Drawing.Color.Transparent;
            this.ANT11.Name = "ANT11";
            this.ANT11.Tag = "4";
            this.ANT11.UseVisualStyleBackColor = false;
            // 
            // ANT10
            // 
            resources.ApplyResources(this.ANT10, "ANT10");
            this.ANT10.BackColor = System.Drawing.Color.Transparent;
            this.ANT10.Name = "ANT10";
            this.ANT10.Tag = "2";
            this.ANT10.UseVisualStyleBackColor = false;
            // 
            // ANT9
            // 
            resources.ApplyResources(this.ANT9, "ANT9");
            this.ANT9.BackColor = System.Drawing.Color.Transparent;
            this.ANT9.Name = "ANT9";
            this.ANT9.Tag = "1";
            this.ANT9.UseVisualStyleBackColor = false;
            // 
            // btn_0010_07_Set
            // 
            this.btn_0010_07_Set.BackColor = System.Drawing.Color.Transparent;
            this.btn_0010_07_Set.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_07_Set.DownImage")));
            resources.ApplyResources(this.btn_0010_07_Set, "btn_0010_07_Set");
            this.btn_0010_07_Set.IsShowBorder = true;
            this.btn_0010_07_Set.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_07_Set.MoveImage")));
            this.btn_0010_07_Set.Name = "btn_0010_07_Set";
            this.btn_0010_07_Set.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_07_Set.NormalImage")));
            this.btn_0010_07_Set.UseVisualStyleBackColor = false;
            this.btn_0010_07_Set.Click += new System.EventHandler(this.btn_0010_07_Set_Click);
            // 
            // btn_0010_08_Get
            // 
            this.btn_0010_08_Get.BackColor = System.Drawing.Color.Transparent;
            this.btn_0010_08_Get.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_08_Get.DownImage")));
            resources.ApplyResources(this.btn_0010_08_Get, "btn_0010_08_Get");
            this.btn_0010_08_Get.IsShowBorder = true;
            this.btn_0010_08_Get.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_08_Get.MoveImage")));
            this.btn_0010_08_Get.Name = "btn_0010_08_Get";
            this.btn_0010_08_Get.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_08_Get.NormalImage")));
            this.btn_0010_08_Get.UseVisualStyleBackColor = false;
            this.btn_0010_08_Get.Click += new System.EventHandler(this.btn_0010_08_Get_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.cb_0010_05_01);
            this.groupBox8.Controls.Add(this.btn_0010_05_Set);
            this.groupBox8.Controls.Add(this.btn_0010_06_Get);
            this.groupBox8.Controls.Add(this.cb_0010_05_00);
            this.groupBox8.Controls.Add(this.label8);
            this.groupBox8.Controls.Add(this.label9);
            resources.ApplyResources(this.groupBox8, "groupBox8");
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.TabStop = false;
            // 
            // cb_0010_05_01
            // 
            this.cb_0010_05_01.CheckOnClick = true;
            this.cb_0010_05_01.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.cb_0010_05_01.DropDownHeight = 1;
            this.cb_0010_05_01.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_05_01, "cb_0010_05_01");
            this.cb_0010_05_01.Name = "cb_0010_05_01";
            this.cb_0010_05_01.ValueSeparator = ", ";
            // 
            // btn_0010_05_Set
            // 
            this.btn_0010_05_Set.BackColor = System.Drawing.Color.Transparent;
            this.btn_0010_05_Set.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_05_Set.DownImage")));
            resources.ApplyResources(this.btn_0010_05_Set, "btn_0010_05_Set");
            this.btn_0010_05_Set.IsShowBorder = true;
            this.btn_0010_05_Set.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_05_Set.MoveImage")));
            this.btn_0010_05_Set.Name = "btn_0010_05_Set";
            this.btn_0010_05_Set.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_05_Set.NormalImage")));
            this.btn_0010_05_Set.UseVisualStyleBackColor = false;
            this.btn_0010_05_Set.Click += new System.EventHandler(this.btn_0010_05_Set_Click);
            // 
            // btn_0010_06_Get
            // 
            this.btn_0010_06_Get.BackColor = System.Drawing.Color.Transparent;
            this.btn_0010_06_Get.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_06_Get.DownImage")));
            resources.ApplyResources(this.btn_0010_06_Get, "btn_0010_06_Get");
            this.btn_0010_06_Get.IsShowBorder = true;
            this.btn_0010_06_Get.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_06_Get.MoveImage")));
            this.btn_0010_06_Get.Name = "btn_0010_06_Get";
            this.btn_0010_06_Get.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_06_Get.NormalImage")));
            this.btn_0010_06_Get.UseVisualStyleBackColor = false;
            this.btn_0010_06_Get.Click += new System.EventHandler(this.btn_0010_06_Get_Click);
            // 
            // cb_0010_05_00
            // 
            this.cb_0010_05_00.FormattingEnabled = true;
            this.cb_0010_05_00.Items.AddRange(new object[] {
            resources.GetString("cb_0010_05_00.Items"),
            resources.GetString("cb_0010_05_00.Items1")});
            resources.ApplyResources(this.cb_0010_05_00, "cb_0010_05_00");
            this.cb_0010_05_00.Name = "cb_0010_05_00";
            this.cb_0010_05_00.SelectedIndexChanged += new System.EventHandler(this.cb_0010_05_00_SelectedIndexChanged);
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label40);
            this.groupBox7.Controls.Add(this.btn_0010_0D_Set);
            this.groupBox7.Controls.Add(this.btn_0010_0E_Get);
            this.groupBox7.Controls.Add(this.label16);
            this.groupBox7.Controls.Add(this.tb_0010_0D_01);
            this.groupBox7.Controls.Add(this.cb_0010_0D_00);
            resources.ApplyResources(this.groupBox7, "groupBox7");
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.TabStop = false;
            // 
            // label40
            // 
            resources.ApplyResources(this.label40, "label40");
            this.label40.Name = "label40";
            // 
            // btn_0010_0D_Set
            // 
            this.btn_0010_0D_Set.BackColor = System.Drawing.Color.Transparent;
            this.btn_0010_0D_Set.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_0D_Set.DownImage")));
            resources.ApplyResources(this.btn_0010_0D_Set, "btn_0010_0D_Set");
            this.btn_0010_0D_Set.IsShowBorder = true;
            this.btn_0010_0D_Set.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_0D_Set.MoveImage")));
            this.btn_0010_0D_Set.Name = "btn_0010_0D_Set";
            this.btn_0010_0D_Set.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_0D_Set.NormalImage")));
            this.btn_0010_0D_Set.UseVisualStyleBackColor = false;
            this.btn_0010_0D_Set.Click += new System.EventHandler(this.btn_0010_0D_Set_Click);
            // 
            // btn_0010_0E_Get
            // 
            this.btn_0010_0E_Get.BackColor = System.Drawing.Color.Transparent;
            this.btn_0010_0E_Get.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_0E_Get.DownImage")));
            resources.ApplyResources(this.btn_0010_0E_Get, "btn_0010_0E_Get");
            this.btn_0010_0E_Get.IsShowBorder = true;
            this.btn_0010_0E_Get.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_0E_Get.MoveImage")));
            this.btn_0010_0E_Get.Name = "btn_0010_0E_Get";
            this.btn_0010_0E_Get.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_0E_Get.NormalImage")));
            this.btn_0010_0E_Get.UseVisualStyleBackColor = false;
            this.btn_0010_0E_Get.Click += new System.EventHandler(this.btn_0010_0E_Get_Click);
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.Name = "label16";
            // 
            // tb_0010_0D_01
            // 
            this.tb_0010_0D_01.BackColor = System.Drawing.Color.Transparent;
            this.tb_0010_0D_01.Icon = null;
            this.tb_0010_0D_01.IconIsButton = false;
            this.tb_0010_0D_01.IsPasswordChat = '\0';
            this.tb_0010_0D_01.IsSystemPasswordChar = false;
            this.tb_0010_0D_01.Lines = new string[0];
            resources.ApplyResources(this.tb_0010_0D_01, "tb_0010_0D_01");
            this.tb_0010_0D_01.MaxLength = 32767;
            this.tb_0010_0D_01.Multiline = false;
            this.tb_0010_0D_01.Name = "tb_0010_0D_01";
            this.tb_0010_0D_01.ReadOnly = false;
            this.tb_0010_0D_01.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_0010_0D_01.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_0010_0D_01.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_0010_0D_01.WaterText = "255";
            this.tb_0010_0D_01.WordWrap = true;
            // 
            // cb_0010_0D_00
            // 
            this.cb_0010_0D_00.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_0D_00.FormattingEnabled = true;
            this.cb_0010_0D_00.Items.AddRange(new object[] {
            resources.GetString("cb_0010_0D_00.Items"),
            resources.GetString("cb_0010_0D_00.Items1")});
            resources.ApplyResources(this.cb_0010_0D_00, "cb_0010_0D_00");
            this.cb_0010_0D_00.Name = "cb_0010_0D_00";
            // 
            // gb_SetANTPower
            // 
            this.gb_SetANTPower.Controls.Add(this.button17);
            this.gb_SetANTPower.Controls.Add(this.button16);
            this.gb_SetANTPower.Controls.Add(this.button15);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_24);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_24);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_23);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_23);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_22);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_22);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_21);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_21);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_20);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_20);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_19);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_19);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_18);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_18);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_17);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_17);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_16);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_16);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_15);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_15);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_14);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_14);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_13);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_13);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_12);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_12);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_11);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_11);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_10);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_10);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_09);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_09);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_08);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_08);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_07);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_07);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_06);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_06);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_05);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_05);
            this.gb_SetANTPower.Controls.Add(this.btn_0010_01_Set);
            this.gb_SetANTPower.Controls.Add(this.btn_0010_02_Get);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_04);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_04);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_03);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_03);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_02);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_02);
            this.gb_SetANTPower.Controls.Add(this.cb_0010_01_01);
            this.gb_SetANTPower.Controls.Add(this.chk_0010_01_01);
            resources.ApplyResources(this.gb_SetANTPower, "gb_SetANTPower");
            this.gb_SetANTPower.Name = "gb_SetANTPower";
            this.gb_SetANTPower.TabStop = false;
            // 
            // button17
            // 
            resources.ApplyResources(this.button17, "button17");
            this.button17.Name = "button17";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button16
            // 
            resources.ApplyResources(this.button16, "button16");
            this.button16.Name = "button16";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button15
            // 
            resources.ApplyResources(this.button15, "button15");
            this.button15.Name = "button15";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // cb_0010_01_24
            // 
            this.cb_0010_01_24.DropDownHeight = 80;
            this.cb_0010_01_24.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_24.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_24, "cb_0010_01_24");
            this.cb_0010_01_24.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_24.Items"),
            resources.GetString("cb_0010_01_24.Items1"),
            resources.GetString("cb_0010_01_24.Items2"),
            resources.GetString("cb_0010_01_24.Items3"),
            resources.GetString("cb_0010_01_24.Items4"),
            resources.GetString("cb_0010_01_24.Items5"),
            resources.GetString("cb_0010_01_24.Items6"),
            resources.GetString("cb_0010_01_24.Items7"),
            resources.GetString("cb_0010_01_24.Items8"),
            resources.GetString("cb_0010_01_24.Items9"),
            resources.GetString("cb_0010_01_24.Items10"),
            resources.GetString("cb_0010_01_24.Items11"),
            resources.GetString("cb_0010_01_24.Items12"),
            resources.GetString("cb_0010_01_24.Items13"),
            resources.GetString("cb_0010_01_24.Items14"),
            resources.GetString("cb_0010_01_24.Items15"),
            resources.GetString("cb_0010_01_24.Items16"),
            resources.GetString("cb_0010_01_24.Items17"),
            resources.GetString("cb_0010_01_24.Items18"),
            resources.GetString("cb_0010_01_24.Items19"),
            resources.GetString("cb_0010_01_24.Items20"),
            resources.GetString("cb_0010_01_24.Items21"),
            resources.GetString("cb_0010_01_24.Items22"),
            resources.GetString("cb_0010_01_24.Items23"),
            resources.GetString("cb_0010_01_24.Items24"),
            resources.GetString("cb_0010_01_24.Items25"),
            resources.GetString("cb_0010_01_24.Items26"),
            resources.GetString("cb_0010_01_24.Items27"),
            resources.GetString("cb_0010_01_24.Items28"),
            resources.GetString("cb_0010_01_24.Items29"),
            resources.GetString("cb_0010_01_24.Items30"),
            resources.GetString("cb_0010_01_24.Items31"),
            resources.GetString("cb_0010_01_24.Items32"),
            resources.GetString("cb_0010_01_24.Items33"),
            resources.GetString("cb_0010_01_24.Items34"),
            resources.GetString("cb_0010_01_24.Items35"),
            resources.GetString("cb_0010_01_24.Items36")});
            this.cb_0010_01_24.Name = "cb_0010_01_24";
            // 
            // chk_0010_01_24
            // 
            resources.ApplyResources(this.chk_0010_01_24, "chk_0010_01_24");
            this.chk_0010_01_24.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_24.Name = "chk_0010_01_24";
            this.chk_0010_01_24.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_23
            // 
            this.cb_0010_01_23.DropDownHeight = 80;
            this.cb_0010_01_23.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_23.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_23, "cb_0010_01_23");
            this.cb_0010_01_23.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_23.Items"),
            resources.GetString("cb_0010_01_23.Items1"),
            resources.GetString("cb_0010_01_23.Items2"),
            resources.GetString("cb_0010_01_23.Items3"),
            resources.GetString("cb_0010_01_23.Items4"),
            resources.GetString("cb_0010_01_23.Items5"),
            resources.GetString("cb_0010_01_23.Items6"),
            resources.GetString("cb_0010_01_23.Items7"),
            resources.GetString("cb_0010_01_23.Items8"),
            resources.GetString("cb_0010_01_23.Items9"),
            resources.GetString("cb_0010_01_23.Items10"),
            resources.GetString("cb_0010_01_23.Items11"),
            resources.GetString("cb_0010_01_23.Items12"),
            resources.GetString("cb_0010_01_23.Items13"),
            resources.GetString("cb_0010_01_23.Items14"),
            resources.GetString("cb_0010_01_23.Items15"),
            resources.GetString("cb_0010_01_23.Items16"),
            resources.GetString("cb_0010_01_23.Items17"),
            resources.GetString("cb_0010_01_23.Items18"),
            resources.GetString("cb_0010_01_23.Items19"),
            resources.GetString("cb_0010_01_23.Items20"),
            resources.GetString("cb_0010_01_23.Items21"),
            resources.GetString("cb_0010_01_23.Items22"),
            resources.GetString("cb_0010_01_23.Items23"),
            resources.GetString("cb_0010_01_23.Items24"),
            resources.GetString("cb_0010_01_23.Items25"),
            resources.GetString("cb_0010_01_23.Items26"),
            resources.GetString("cb_0010_01_23.Items27"),
            resources.GetString("cb_0010_01_23.Items28"),
            resources.GetString("cb_0010_01_23.Items29"),
            resources.GetString("cb_0010_01_23.Items30"),
            resources.GetString("cb_0010_01_23.Items31"),
            resources.GetString("cb_0010_01_23.Items32"),
            resources.GetString("cb_0010_01_23.Items33"),
            resources.GetString("cb_0010_01_23.Items34"),
            resources.GetString("cb_0010_01_23.Items35"),
            resources.GetString("cb_0010_01_23.Items36")});
            this.cb_0010_01_23.Name = "cb_0010_01_23";
            // 
            // chk_0010_01_23
            // 
            resources.ApplyResources(this.chk_0010_01_23, "chk_0010_01_23");
            this.chk_0010_01_23.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_23.Name = "chk_0010_01_23";
            this.chk_0010_01_23.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_22
            // 
            this.cb_0010_01_22.DropDownHeight = 80;
            this.cb_0010_01_22.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_22.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_22, "cb_0010_01_22");
            this.cb_0010_01_22.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_22.Items"),
            resources.GetString("cb_0010_01_22.Items1"),
            resources.GetString("cb_0010_01_22.Items2"),
            resources.GetString("cb_0010_01_22.Items3"),
            resources.GetString("cb_0010_01_22.Items4"),
            resources.GetString("cb_0010_01_22.Items5"),
            resources.GetString("cb_0010_01_22.Items6"),
            resources.GetString("cb_0010_01_22.Items7"),
            resources.GetString("cb_0010_01_22.Items8"),
            resources.GetString("cb_0010_01_22.Items9"),
            resources.GetString("cb_0010_01_22.Items10"),
            resources.GetString("cb_0010_01_22.Items11"),
            resources.GetString("cb_0010_01_22.Items12"),
            resources.GetString("cb_0010_01_22.Items13"),
            resources.GetString("cb_0010_01_22.Items14"),
            resources.GetString("cb_0010_01_22.Items15"),
            resources.GetString("cb_0010_01_22.Items16"),
            resources.GetString("cb_0010_01_22.Items17"),
            resources.GetString("cb_0010_01_22.Items18"),
            resources.GetString("cb_0010_01_22.Items19"),
            resources.GetString("cb_0010_01_22.Items20"),
            resources.GetString("cb_0010_01_22.Items21"),
            resources.GetString("cb_0010_01_22.Items22"),
            resources.GetString("cb_0010_01_22.Items23"),
            resources.GetString("cb_0010_01_22.Items24"),
            resources.GetString("cb_0010_01_22.Items25"),
            resources.GetString("cb_0010_01_22.Items26"),
            resources.GetString("cb_0010_01_22.Items27"),
            resources.GetString("cb_0010_01_22.Items28"),
            resources.GetString("cb_0010_01_22.Items29"),
            resources.GetString("cb_0010_01_22.Items30"),
            resources.GetString("cb_0010_01_22.Items31"),
            resources.GetString("cb_0010_01_22.Items32"),
            resources.GetString("cb_0010_01_22.Items33"),
            resources.GetString("cb_0010_01_22.Items34"),
            resources.GetString("cb_0010_01_22.Items35"),
            resources.GetString("cb_0010_01_22.Items36")});
            this.cb_0010_01_22.Name = "cb_0010_01_22";
            // 
            // chk_0010_01_22
            // 
            resources.ApplyResources(this.chk_0010_01_22, "chk_0010_01_22");
            this.chk_0010_01_22.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_22.Name = "chk_0010_01_22";
            this.chk_0010_01_22.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_21
            // 
            this.cb_0010_01_21.DropDownHeight = 80;
            this.cb_0010_01_21.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_21.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_21, "cb_0010_01_21");
            this.cb_0010_01_21.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_21.Items"),
            resources.GetString("cb_0010_01_21.Items1"),
            resources.GetString("cb_0010_01_21.Items2"),
            resources.GetString("cb_0010_01_21.Items3"),
            resources.GetString("cb_0010_01_21.Items4"),
            resources.GetString("cb_0010_01_21.Items5"),
            resources.GetString("cb_0010_01_21.Items6"),
            resources.GetString("cb_0010_01_21.Items7"),
            resources.GetString("cb_0010_01_21.Items8"),
            resources.GetString("cb_0010_01_21.Items9"),
            resources.GetString("cb_0010_01_21.Items10"),
            resources.GetString("cb_0010_01_21.Items11"),
            resources.GetString("cb_0010_01_21.Items12"),
            resources.GetString("cb_0010_01_21.Items13"),
            resources.GetString("cb_0010_01_21.Items14"),
            resources.GetString("cb_0010_01_21.Items15"),
            resources.GetString("cb_0010_01_21.Items16"),
            resources.GetString("cb_0010_01_21.Items17"),
            resources.GetString("cb_0010_01_21.Items18"),
            resources.GetString("cb_0010_01_21.Items19"),
            resources.GetString("cb_0010_01_21.Items20"),
            resources.GetString("cb_0010_01_21.Items21"),
            resources.GetString("cb_0010_01_21.Items22"),
            resources.GetString("cb_0010_01_21.Items23"),
            resources.GetString("cb_0010_01_21.Items24"),
            resources.GetString("cb_0010_01_21.Items25"),
            resources.GetString("cb_0010_01_21.Items26"),
            resources.GetString("cb_0010_01_21.Items27"),
            resources.GetString("cb_0010_01_21.Items28"),
            resources.GetString("cb_0010_01_21.Items29"),
            resources.GetString("cb_0010_01_21.Items30"),
            resources.GetString("cb_0010_01_21.Items31"),
            resources.GetString("cb_0010_01_21.Items32"),
            resources.GetString("cb_0010_01_21.Items33"),
            resources.GetString("cb_0010_01_21.Items34"),
            resources.GetString("cb_0010_01_21.Items35"),
            resources.GetString("cb_0010_01_21.Items36")});
            this.cb_0010_01_21.Name = "cb_0010_01_21";
            // 
            // chk_0010_01_21
            // 
            resources.ApplyResources(this.chk_0010_01_21, "chk_0010_01_21");
            this.chk_0010_01_21.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_21.Name = "chk_0010_01_21";
            this.chk_0010_01_21.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_20
            // 
            this.cb_0010_01_20.DropDownHeight = 80;
            this.cb_0010_01_20.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_20.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_20, "cb_0010_01_20");
            this.cb_0010_01_20.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_20.Items"),
            resources.GetString("cb_0010_01_20.Items1"),
            resources.GetString("cb_0010_01_20.Items2"),
            resources.GetString("cb_0010_01_20.Items3"),
            resources.GetString("cb_0010_01_20.Items4"),
            resources.GetString("cb_0010_01_20.Items5"),
            resources.GetString("cb_0010_01_20.Items6"),
            resources.GetString("cb_0010_01_20.Items7"),
            resources.GetString("cb_0010_01_20.Items8"),
            resources.GetString("cb_0010_01_20.Items9"),
            resources.GetString("cb_0010_01_20.Items10"),
            resources.GetString("cb_0010_01_20.Items11"),
            resources.GetString("cb_0010_01_20.Items12"),
            resources.GetString("cb_0010_01_20.Items13"),
            resources.GetString("cb_0010_01_20.Items14"),
            resources.GetString("cb_0010_01_20.Items15"),
            resources.GetString("cb_0010_01_20.Items16"),
            resources.GetString("cb_0010_01_20.Items17"),
            resources.GetString("cb_0010_01_20.Items18"),
            resources.GetString("cb_0010_01_20.Items19"),
            resources.GetString("cb_0010_01_20.Items20"),
            resources.GetString("cb_0010_01_20.Items21"),
            resources.GetString("cb_0010_01_20.Items22"),
            resources.GetString("cb_0010_01_20.Items23"),
            resources.GetString("cb_0010_01_20.Items24"),
            resources.GetString("cb_0010_01_20.Items25"),
            resources.GetString("cb_0010_01_20.Items26"),
            resources.GetString("cb_0010_01_20.Items27"),
            resources.GetString("cb_0010_01_20.Items28"),
            resources.GetString("cb_0010_01_20.Items29"),
            resources.GetString("cb_0010_01_20.Items30"),
            resources.GetString("cb_0010_01_20.Items31"),
            resources.GetString("cb_0010_01_20.Items32"),
            resources.GetString("cb_0010_01_20.Items33"),
            resources.GetString("cb_0010_01_20.Items34"),
            resources.GetString("cb_0010_01_20.Items35"),
            resources.GetString("cb_0010_01_20.Items36")});
            this.cb_0010_01_20.Name = "cb_0010_01_20";
            // 
            // chk_0010_01_20
            // 
            resources.ApplyResources(this.chk_0010_01_20, "chk_0010_01_20");
            this.chk_0010_01_20.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_20.Name = "chk_0010_01_20";
            this.chk_0010_01_20.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_19
            // 
            this.cb_0010_01_19.DropDownHeight = 80;
            this.cb_0010_01_19.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_19.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_19, "cb_0010_01_19");
            this.cb_0010_01_19.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_19.Items"),
            resources.GetString("cb_0010_01_19.Items1"),
            resources.GetString("cb_0010_01_19.Items2"),
            resources.GetString("cb_0010_01_19.Items3"),
            resources.GetString("cb_0010_01_19.Items4"),
            resources.GetString("cb_0010_01_19.Items5"),
            resources.GetString("cb_0010_01_19.Items6"),
            resources.GetString("cb_0010_01_19.Items7"),
            resources.GetString("cb_0010_01_19.Items8"),
            resources.GetString("cb_0010_01_19.Items9"),
            resources.GetString("cb_0010_01_19.Items10"),
            resources.GetString("cb_0010_01_19.Items11"),
            resources.GetString("cb_0010_01_19.Items12"),
            resources.GetString("cb_0010_01_19.Items13"),
            resources.GetString("cb_0010_01_19.Items14"),
            resources.GetString("cb_0010_01_19.Items15"),
            resources.GetString("cb_0010_01_19.Items16"),
            resources.GetString("cb_0010_01_19.Items17"),
            resources.GetString("cb_0010_01_19.Items18"),
            resources.GetString("cb_0010_01_19.Items19"),
            resources.GetString("cb_0010_01_19.Items20"),
            resources.GetString("cb_0010_01_19.Items21"),
            resources.GetString("cb_0010_01_19.Items22"),
            resources.GetString("cb_0010_01_19.Items23"),
            resources.GetString("cb_0010_01_19.Items24"),
            resources.GetString("cb_0010_01_19.Items25"),
            resources.GetString("cb_0010_01_19.Items26"),
            resources.GetString("cb_0010_01_19.Items27"),
            resources.GetString("cb_0010_01_19.Items28"),
            resources.GetString("cb_0010_01_19.Items29"),
            resources.GetString("cb_0010_01_19.Items30"),
            resources.GetString("cb_0010_01_19.Items31"),
            resources.GetString("cb_0010_01_19.Items32"),
            resources.GetString("cb_0010_01_19.Items33"),
            resources.GetString("cb_0010_01_19.Items34"),
            resources.GetString("cb_0010_01_19.Items35"),
            resources.GetString("cb_0010_01_19.Items36")});
            this.cb_0010_01_19.Name = "cb_0010_01_19";
            // 
            // chk_0010_01_19
            // 
            resources.ApplyResources(this.chk_0010_01_19, "chk_0010_01_19");
            this.chk_0010_01_19.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_19.Name = "chk_0010_01_19";
            this.chk_0010_01_19.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_18
            // 
            this.cb_0010_01_18.DropDownHeight = 80;
            this.cb_0010_01_18.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_18.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_18, "cb_0010_01_18");
            this.cb_0010_01_18.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_18.Items"),
            resources.GetString("cb_0010_01_18.Items1"),
            resources.GetString("cb_0010_01_18.Items2"),
            resources.GetString("cb_0010_01_18.Items3"),
            resources.GetString("cb_0010_01_18.Items4"),
            resources.GetString("cb_0010_01_18.Items5"),
            resources.GetString("cb_0010_01_18.Items6"),
            resources.GetString("cb_0010_01_18.Items7"),
            resources.GetString("cb_0010_01_18.Items8"),
            resources.GetString("cb_0010_01_18.Items9"),
            resources.GetString("cb_0010_01_18.Items10"),
            resources.GetString("cb_0010_01_18.Items11"),
            resources.GetString("cb_0010_01_18.Items12"),
            resources.GetString("cb_0010_01_18.Items13"),
            resources.GetString("cb_0010_01_18.Items14"),
            resources.GetString("cb_0010_01_18.Items15"),
            resources.GetString("cb_0010_01_18.Items16"),
            resources.GetString("cb_0010_01_18.Items17"),
            resources.GetString("cb_0010_01_18.Items18"),
            resources.GetString("cb_0010_01_18.Items19"),
            resources.GetString("cb_0010_01_18.Items20"),
            resources.GetString("cb_0010_01_18.Items21"),
            resources.GetString("cb_0010_01_18.Items22"),
            resources.GetString("cb_0010_01_18.Items23"),
            resources.GetString("cb_0010_01_18.Items24"),
            resources.GetString("cb_0010_01_18.Items25"),
            resources.GetString("cb_0010_01_18.Items26"),
            resources.GetString("cb_0010_01_18.Items27"),
            resources.GetString("cb_0010_01_18.Items28"),
            resources.GetString("cb_0010_01_18.Items29"),
            resources.GetString("cb_0010_01_18.Items30"),
            resources.GetString("cb_0010_01_18.Items31"),
            resources.GetString("cb_0010_01_18.Items32"),
            resources.GetString("cb_0010_01_18.Items33"),
            resources.GetString("cb_0010_01_18.Items34"),
            resources.GetString("cb_0010_01_18.Items35"),
            resources.GetString("cb_0010_01_18.Items36")});
            this.cb_0010_01_18.Name = "cb_0010_01_18";
            // 
            // chk_0010_01_18
            // 
            resources.ApplyResources(this.chk_0010_01_18, "chk_0010_01_18");
            this.chk_0010_01_18.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_18.Name = "chk_0010_01_18";
            this.chk_0010_01_18.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_17
            // 
            this.cb_0010_01_17.DropDownHeight = 80;
            this.cb_0010_01_17.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_17.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_17, "cb_0010_01_17");
            this.cb_0010_01_17.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_17.Items"),
            resources.GetString("cb_0010_01_17.Items1"),
            resources.GetString("cb_0010_01_17.Items2"),
            resources.GetString("cb_0010_01_17.Items3"),
            resources.GetString("cb_0010_01_17.Items4"),
            resources.GetString("cb_0010_01_17.Items5"),
            resources.GetString("cb_0010_01_17.Items6"),
            resources.GetString("cb_0010_01_17.Items7"),
            resources.GetString("cb_0010_01_17.Items8"),
            resources.GetString("cb_0010_01_17.Items9"),
            resources.GetString("cb_0010_01_17.Items10"),
            resources.GetString("cb_0010_01_17.Items11"),
            resources.GetString("cb_0010_01_17.Items12"),
            resources.GetString("cb_0010_01_17.Items13"),
            resources.GetString("cb_0010_01_17.Items14"),
            resources.GetString("cb_0010_01_17.Items15"),
            resources.GetString("cb_0010_01_17.Items16"),
            resources.GetString("cb_0010_01_17.Items17"),
            resources.GetString("cb_0010_01_17.Items18"),
            resources.GetString("cb_0010_01_17.Items19"),
            resources.GetString("cb_0010_01_17.Items20"),
            resources.GetString("cb_0010_01_17.Items21"),
            resources.GetString("cb_0010_01_17.Items22"),
            resources.GetString("cb_0010_01_17.Items23"),
            resources.GetString("cb_0010_01_17.Items24"),
            resources.GetString("cb_0010_01_17.Items25"),
            resources.GetString("cb_0010_01_17.Items26"),
            resources.GetString("cb_0010_01_17.Items27"),
            resources.GetString("cb_0010_01_17.Items28"),
            resources.GetString("cb_0010_01_17.Items29"),
            resources.GetString("cb_0010_01_17.Items30"),
            resources.GetString("cb_0010_01_17.Items31"),
            resources.GetString("cb_0010_01_17.Items32"),
            resources.GetString("cb_0010_01_17.Items33"),
            resources.GetString("cb_0010_01_17.Items34"),
            resources.GetString("cb_0010_01_17.Items35"),
            resources.GetString("cb_0010_01_17.Items36")});
            this.cb_0010_01_17.Name = "cb_0010_01_17";
            // 
            // chk_0010_01_17
            // 
            resources.ApplyResources(this.chk_0010_01_17, "chk_0010_01_17");
            this.chk_0010_01_17.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_17.Name = "chk_0010_01_17";
            this.chk_0010_01_17.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_16
            // 
            this.cb_0010_01_16.DropDownHeight = 80;
            this.cb_0010_01_16.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_16.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_16, "cb_0010_01_16");
            this.cb_0010_01_16.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_16.Items"),
            resources.GetString("cb_0010_01_16.Items1"),
            resources.GetString("cb_0010_01_16.Items2"),
            resources.GetString("cb_0010_01_16.Items3"),
            resources.GetString("cb_0010_01_16.Items4"),
            resources.GetString("cb_0010_01_16.Items5"),
            resources.GetString("cb_0010_01_16.Items6"),
            resources.GetString("cb_0010_01_16.Items7"),
            resources.GetString("cb_0010_01_16.Items8"),
            resources.GetString("cb_0010_01_16.Items9"),
            resources.GetString("cb_0010_01_16.Items10"),
            resources.GetString("cb_0010_01_16.Items11"),
            resources.GetString("cb_0010_01_16.Items12"),
            resources.GetString("cb_0010_01_16.Items13"),
            resources.GetString("cb_0010_01_16.Items14"),
            resources.GetString("cb_0010_01_16.Items15"),
            resources.GetString("cb_0010_01_16.Items16"),
            resources.GetString("cb_0010_01_16.Items17"),
            resources.GetString("cb_0010_01_16.Items18"),
            resources.GetString("cb_0010_01_16.Items19"),
            resources.GetString("cb_0010_01_16.Items20"),
            resources.GetString("cb_0010_01_16.Items21"),
            resources.GetString("cb_0010_01_16.Items22"),
            resources.GetString("cb_0010_01_16.Items23"),
            resources.GetString("cb_0010_01_16.Items24"),
            resources.GetString("cb_0010_01_16.Items25"),
            resources.GetString("cb_0010_01_16.Items26"),
            resources.GetString("cb_0010_01_16.Items27"),
            resources.GetString("cb_0010_01_16.Items28"),
            resources.GetString("cb_0010_01_16.Items29"),
            resources.GetString("cb_0010_01_16.Items30"),
            resources.GetString("cb_0010_01_16.Items31"),
            resources.GetString("cb_0010_01_16.Items32"),
            resources.GetString("cb_0010_01_16.Items33"),
            resources.GetString("cb_0010_01_16.Items34"),
            resources.GetString("cb_0010_01_16.Items35"),
            resources.GetString("cb_0010_01_16.Items36")});
            this.cb_0010_01_16.Name = "cb_0010_01_16";
            // 
            // chk_0010_01_16
            // 
            resources.ApplyResources(this.chk_0010_01_16, "chk_0010_01_16");
            this.chk_0010_01_16.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_16.Name = "chk_0010_01_16";
            this.chk_0010_01_16.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_15
            // 
            this.cb_0010_01_15.DropDownHeight = 80;
            this.cb_0010_01_15.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_15.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_15, "cb_0010_01_15");
            this.cb_0010_01_15.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_15.Items"),
            resources.GetString("cb_0010_01_15.Items1"),
            resources.GetString("cb_0010_01_15.Items2"),
            resources.GetString("cb_0010_01_15.Items3"),
            resources.GetString("cb_0010_01_15.Items4"),
            resources.GetString("cb_0010_01_15.Items5"),
            resources.GetString("cb_0010_01_15.Items6"),
            resources.GetString("cb_0010_01_15.Items7"),
            resources.GetString("cb_0010_01_15.Items8"),
            resources.GetString("cb_0010_01_15.Items9"),
            resources.GetString("cb_0010_01_15.Items10"),
            resources.GetString("cb_0010_01_15.Items11"),
            resources.GetString("cb_0010_01_15.Items12"),
            resources.GetString("cb_0010_01_15.Items13"),
            resources.GetString("cb_0010_01_15.Items14"),
            resources.GetString("cb_0010_01_15.Items15"),
            resources.GetString("cb_0010_01_15.Items16"),
            resources.GetString("cb_0010_01_15.Items17"),
            resources.GetString("cb_0010_01_15.Items18"),
            resources.GetString("cb_0010_01_15.Items19"),
            resources.GetString("cb_0010_01_15.Items20"),
            resources.GetString("cb_0010_01_15.Items21"),
            resources.GetString("cb_0010_01_15.Items22"),
            resources.GetString("cb_0010_01_15.Items23"),
            resources.GetString("cb_0010_01_15.Items24"),
            resources.GetString("cb_0010_01_15.Items25"),
            resources.GetString("cb_0010_01_15.Items26"),
            resources.GetString("cb_0010_01_15.Items27"),
            resources.GetString("cb_0010_01_15.Items28"),
            resources.GetString("cb_0010_01_15.Items29"),
            resources.GetString("cb_0010_01_15.Items30"),
            resources.GetString("cb_0010_01_15.Items31"),
            resources.GetString("cb_0010_01_15.Items32"),
            resources.GetString("cb_0010_01_15.Items33"),
            resources.GetString("cb_0010_01_15.Items34"),
            resources.GetString("cb_0010_01_15.Items35"),
            resources.GetString("cb_0010_01_15.Items36")});
            this.cb_0010_01_15.Name = "cb_0010_01_15";
            // 
            // chk_0010_01_15
            // 
            resources.ApplyResources(this.chk_0010_01_15, "chk_0010_01_15");
            this.chk_0010_01_15.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_15.Name = "chk_0010_01_15";
            this.chk_0010_01_15.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_14
            // 
            this.cb_0010_01_14.DropDownHeight = 80;
            this.cb_0010_01_14.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_14.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_14, "cb_0010_01_14");
            this.cb_0010_01_14.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_14.Items"),
            resources.GetString("cb_0010_01_14.Items1"),
            resources.GetString("cb_0010_01_14.Items2"),
            resources.GetString("cb_0010_01_14.Items3"),
            resources.GetString("cb_0010_01_14.Items4"),
            resources.GetString("cb_0010_01_14.Items5"),
            resources.GetString("cb_0010_01_14.Items6"),
            resources.GetString("cb_0010_01_14.Items7"),
            resources.GetString("cb_0010_01_14.Items8"),
            resources.GetString("cb_0010_01_14.Items9"),
            resources.GetString("cb_0010_01_14.Items10"),
            resources.GetString("cb_0010_01_14.Items11"),
            resources.GetString("cb_0010_01_14.Items12"),
            resources.GetString("cb_0010_01_14.Items13"),
            resources.GetString("cb_0010_01_14.Items14"),
            resources.GetString("cb_0010_01_14.Items15"),
            resources.GetString("cb_0010_01_14.Items16"),
            resources.GetString("cb_0010_01_14.Items17"),
            resources.GetString("cb_0010_01_14.Items18"),
            resources.GetString("cb_0010_01_14.Items19"),
            resources.GetString("cb_0010_01_14.Items20"),
            resources.GetString("cb_0010_01_14.Items21"),
            resources.GetString("cb_0010_01_14.Items22"),
            resources.GetString("cb_0010_01_14.Items23"),
            resources.GetString("cb_0010_01_14.Items24"),
            resources.GetString("cb_0010_01_14.Items25"),
            resources.GetString("cb_0010_01_14.Items26"),
            resources.GetString("cb_0010_01_14.Items27"),
            resources.GetString("cb_0010_01_14.Items28"),
            resources.GetString("cb_0010_01_14.Items29"),
            resources.GetString("cb_0010_01_14.Items30"),
            resources.GetString("cb_0010_01_14.Items31"),
            resources.GetString("cb_0010_01_14.Items32"),
            resources.GetString("cb_0010_01_14.Items33"),
            resources.GetString("cb_0010_01_14.Items34"),
            resources.GetString("cb_0010_01_14.Items35"),
            resources.GetString("cb_0010_01_14.Items36")});
            this.cb_0010_01_14.Name = "cb_0010_01_14";
            // 
            // chk_0010_01_14
            // 
            resources.ApplyResources(this.chk_0010_01_14, "chk_0010_01_14");
            this.chk_0010_01_14.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_14.Name = "chk_0010_01_14";
            this.chk_0010_01_14.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_13
            // 
            this.cb_0010_01_13.DropDownHeight = 80;
            this.cb_0010_01_13.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_13.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_13, "cb_0010_01_13");
            this.cb_0010_01_13.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_13.Items"),
            resources.GetString("cb_0010_01_13.Items1"),
            resources.GetString("cb_0010_01_13.Items2"),
            resources.GetString("cb_0010_01_13.Items3"),
            resources.GetString("cb_0010_01_13.Items4"),
            resources.GetString("cb_0010_01_13.Items5"),
            resources.GetString("cb_0010_01_13.Items6"),
            resources.GetString("cb_0010_01_13.Items7"),
            resources.GetString("cb_0010_01_13.Items8"),
            resources.GetString("cb_0010_01_13.Items9"),
            resources.GetString("cb_0010_01_13.Items10"),
            resources.GetString("cb_0010_01_13.Items11"),
            resources.GetString("cb_0010_01_13.Items12"),
            resources.GetString("cb_0010_01_13.Items13"),
            resources.GetString("cb_0010_01_13.Items14"),
            resources.GetString("cb_0010_01_13.Items15"),
            resources.GetString("cb_0010_01_13.Items16"),
            resources.GetString("cb_0010_01_13.Items17"),
            resources.GetString("cb_0010_01_13.Items18"),
            resources.GetString("cb_0010_01_13.Items19"),
            resources.GetString("cb_0010_01_13.Items20"),
            resources.GetString("cb_0010_01_13.Items21"),
            resources.GetString("cb_0010_01_13.Items22"),
            resources.GetString("cb_0010_01_13.Items23"),
            resources.GetString("cb_0010_01_13.Items24"),
            resources.GetString("cb_0010_01_13.Items25"),
            resources.GetString("cb_0010_01_13.Items26"),
            resources.GetString("cb_0010_01_13.Items27"),
            resources.GetString("cb_0010_01_13.Items28"),
            resources.GetString("cb_0010_01_13.Items29"),
            resources.GetString("cb_0010_01_13.Items30"),
            resources.GetString("cb_0010_01_13.Items31"),
            resources.GetString("cb_0010_01_13.Items32"),
            resources.GetString("cb_0010_01_13.Items33"),
            resources.GetString("cb_0010_01_13.Items34"),
            resources.GetString("cb_0010_01_13.Items35"),
            resources.GetString("cb_0010_01_13.Items36")});
            this.cb_0010_01_13.Name = "cb_0010_01_13";
            // 
            // chk_0010_01_13
            // 
            resources.ApplyResources(this.chk_0010_01_13, "chk_0010_01_13");
            this.chk_0010_01_13.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_13.Name = "chk_0010_01_13";
            this.chk_0010_01_13.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_12
            // 
            this.cb_0010_01_12.DropDownHeight = 80;
            this.cb_0010_01_12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_12.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_12, "cb_0010_01_12");
            this.cb_0010_01_12.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_12.Items"),
            resources.GetString("cb_0010_01_12.Items1"),
            resources.GetString("cb_0010_01_12.Items2"),
            resources.GetString("cb_0010_01_12.Items3"),
            resources.GetString("cb_0010_01_12.Items4"),
            resources.GetString("cb_0010_01_12.Items5"),
            resources.GetString("cb_0010_01_12.Items6"),
            resources.GetString("cb_0010_01_12.Items7"),
            resources.GetString("cb_0010_01_12.Items8"),
            resources.GetString("cb_0010_01_12.Items9"),
            resources.GetString("cb_0010_01_12.Items10"),
            resources.GetString("cb_0010_01_12.Items11"),
            resources.GetString("cb_0010_01_12.Items12"),
            resources.GetString("cb_0010_01_12.Items13"),
            resources.GetString("cb_0010_01_12.Items14"),
            resources.GetString("cb_0010_01_12.Items15"),
            resources.GetString("cb_0010_01_12.Items16"),
            resources.GetString("cb_0010_01_12.Items17"),
            resources.GetString("cb_0010_01_12.Items18"),
            resources.GetString("cb_0010_01_12.Items19"),
            resources.GetString("cb_0010_01_12.Items20"),
            resources.GetString("cb_0010_01_12.Items21"),
            resources.GetString("cb_0010_01_12.Items22"),
            resources.GetString("cb_0010_01_12.Items23"),
            resources.GetString("cb_0010_01_12.Items24"),
            resources.GetString("cb_0010_01_12.Items25"),
            resources.GetString("cb_0010_01_12.Items26"),
            resources.GetString("cb_0010_01_12.Items27"),
            resources.GetString("cb_0010_01_12.Items28"),
            resources.GetString("cb_0010_01_12.Items29"),
            resources.GetString("cb_0010_01_12.Items30"),
            resources.GetString("cb_0010_01_12.Items31"),
            resources.GetString("cb_0010_01_12.Items32"),
            resources.GetString("cb_0010_01_12.Items33"),
            resources.GetString("cb_0010_01_12.Items34"),
            resources.GetString("cb_0010_01_12.Items35"),
            resources.GetString("cb_0010_01_12.Items36")});
            this.cb_0010_01_12.Name = "cb_0010_01_12";
            // 
            // chk_0010_01_12
            // 
            resources.ApplyResources(this.chk_0010_01_12, "chk_0010_01_12");
            this.chk_0010_01_12.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_12.Name = "chk_0010_01_12";
            this.chk_0010_01_12.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_11
            // 
            this.cb_0010_01_11.DropDownHeight = 80;
            this.cb_0010_01_11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_11.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_11, "cb_0010_01_11");
            this.cb_0010_01_11.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_11.Items"),
            resources.GetString("cb_0010_01_11.Items1"),
            resources.GetString("cb_0010_01_11.Items2"),
            resources.GetString("cb_0010_01_11.Items3"),
            resources.GetString("cb_0010_01_11.Items4"),
            resources.GetString("cb_0010_01_11.Items5"),
            resources.GetString("cb_0010_01_11.Items6"),
            resources.GetString("cb_0010_01_11.Items7"),
            resources.GetString("cb_0010_01_11.Items8"),
            resources.GetString("cb_0010_01_11.Items9"),
            resources.GetString("cb_0010_01_11.Items10"),
            resources.GetString("cb_0010_01_11.Items11"),
            resources.GetString("cb_0010_01_11.Items12"),
            resources.GetString("cb_0010_01_11.Items13"),
            resources.GetString("cb_0010_01_11.Items14"),
            resources.GetString("cb_0010_01_11.Items15"),
            resources.GetString("cb_0010_01_11.Items16"),
            resources.GetString("cb_0010_01_11.Items17"),
            resources.GetString("cb_0010_01_11.Items18"),
            resources.GetString("cb_0010_01_11.Items19"),
            resources.GetString("cb_0010_01_11.Items20"),
            resources.GetString("cb_0010_01_11.Items21"),
            resources.GetString("cb_0010_01_11.Items22"),
            resources.GetString("cb_0010_01_11.Items23"),
            resources.GetString("cb_0010_01_11.Items24"),
            resources.GetString("cb_0010_01_11.Items25"),
            resources.GetString("cb_0010_01_11.Items26"),
            resources.GetString("cb_0010_01_11.Items27"),
            resources.GetString("cb_0010_01_11.Items28"),
            resources.GetString("cb_0010_01_11.Items29"),
            resources.GetString("cb_0010_01_11.Items30"),
            resources.GetString("cb_0010_01_11.Items31"),
            resources.GetString("cb_0010_01_11.Items32"),
            resources.GetString("cb_0010_01_11.Items33"),
            resources.GetString("cb_0010_01_11.Items34"),
            resources.GetString("cb_0010_01_11.Items35"),
            resources.GetString("cb_0010_01_11.Items36")});
            this.cb_0010_01_11.Name = "cb_0010_01_11";
            // 
            // chk_0010_01_11
            // 
            resources.ApplyResources(this.chk_0010_01_11, "chk_0010_01_11");
            this.chk_0010_01_11.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_11.Name = "chk_0010_01_11";
            this.chk_0010_01_11.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_10
            // 
            this.cb_0010_01_10.DropDownHeight = 80;
            this.cb_0010_01_10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_10.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_10, "cb_0010_01_10");
            this.cb_0010_01_10.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_10.Items"),
            resources.GetString("cb_0010_01_10.Items1"),
            resources.GetString("cb_0010_01_10.Items2"),
            resources.GetString("cb_0010_01_10.Items3"),
            resources.GetString("cb_0010_01_10.Items4"),
            resources.GetString("cb_0010_01_10.Items5"),
            resources.GetString("cb_0010_01_10.Items6"),
            resources.GetString("cb_0010_01_10.Items7"),
            resources.GetString("cb_0010_01_10.Items8"),
            resources.GetString("cb_0010_01_10.Items9"),
            resources.GetString("cb_0010_01_10.Items10"),
            resources.GetString("cb_0010_01_10.Items11"),
            resources.GetString("cb_0010_01_10.Items12"),
            resources.GetString("cb_0010_01_10.Items13"),
            resources.GetString("cb_0010_01_10.Items14"),
            resources.GetString("cb_0010_01_10.Items15"),
            resources.GetString("cb_0010_01_10.Items16"),
            resources.GetString("cb_0010_01_10.Items17"),
            resources.GetString("cb_0010_01_10.Items18"),
            resources.GetString("cb_0010_01_10.Items19"),
            resources.GetString("cb_0010_01_10.Items20"),
            resources.GetString("cb_0010_01_10.Items21"),
            resources.GetString("cb_0010_01_10.Items22"),
            resources.GetString("cb_0010_01_10.Items23"),
            resources.GetString("cb_0010_01_10.Items24"),
            resources.GetString("cb_0010_01_10.Items25"),
            resources.GetString("cb_0010_01_10.Items26"),
            resources.GetString("cb_0010_01_10.Items27"),
            resources.GetString("cb_0010_01_10.Items28"),
            resources.GetString("cb_0010_01_10.Items29"),
            resources.GetString("cb_0010_01_10.Items30"),
            resources.GetString("cb_0010_01_10.Items31"),
            resources.GetString("cb_0010_01_10.Items32"),
            resources.GetString("cb_0010_01_10.Items33"),
            resources.GetString("cb_0010_01_10.Items34"),
            resources.GetString("cb_0010_01_10.Items35"),
            resources.GetString("cb_0010_01_10.Items36")});
            this.cb_0010_01_10.Name = "cb_0010_01_10";
            // 
            // chk_0010_01_10
            // 
            resources.ApplyResources(this.chk_0010_01_10, "chk_0010_01_10");
            this.chk_0010_01_10.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_10.Name = "chk_0010_01_10";
            this.chk_0010_01_10.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_09
            // 
            this.cb_0010_01_09.DropDownHeight = 80;
            this.cb_0010_01_09.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_09.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_09, "cb_0010_01_09");
            this.cb_0010_01_09.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_09.Items"),
            resources.GetString("cb_0010_01_09.Items1"),
            resources.GetString("cb_0010_01_09.Items2"),
            resources.GetString("cb_0010_01_09.Items3"),
            resources.GetString("cb_0010_01_09.Items4"),
            resources.GetString("cb_0010_01_09.Items5"),
            resources.GetString("cb_0010_01_09.Items6"),
            resources.GetString("cb_0010_01_09.Items7"),
            resources.GetString("cb_0010_01_09.Items8"),
            resources.GetString("cb_0010_01_09.Items9"),
            resources.GetString("cb_0010_01_09.Items10"),
            resources.GetString("cb_0010_01_09.Items11"),
            resources.GetString("cb_0010_01_09.Items12"),
            resources.GetString("cb_0010_01_09.Items13"),
            resources.GetString("cb_0010_01_09.Items14"),
            resources.GetString("cb_0010_01_09.Items15"),
            resources.GetString("cb_0010_01_09.Items16"),
            resources.GetString("cb_0010_01_09.Items17"),
            resources.GetString("cb_0010_01_09.Items18"),
            resources.GetString("cb_0010_01_09.Items19"),
            resources.GetString("cb_0010_01_09.Items20"),
            resources.GetString("cb_0010_01_09.Items21"),
            resources.GetString("cb_0010_01_09.Items22"),
            resources.GetString("cb_0010_01_09.Items23"),
            resources.GetString("cb_0010_01_09.Items24"),
            resources.GetString("cb_0010_01_09.Items25"),
            resources.GetString("cb_0010_01_09.Items26"),
            resources.GetString("cb_0010_01_09.Items27"),
            resources.GetString("cb_0010_01_09.Items28"),
            resources.GetString("cb_0010_01_09.Items29"),
            resources.GetString("cb_0010_01_09.Items30"),
            resources.GetString("cb_0010_01_09.Items31"),
            resources.GetString("cb_0010_01_09.Items32"),
            resources.GetString("cb_0010_01_09.Items33"),
            resources.GetString("cb_0010_01_09.Items34"),
            resources.GetString("cb_0010_01_09.Items35"),
            resources.GetString("cb_0010_01_09.Items36")});
            this.cb_0010_01_09.Name = "cb_0010_01_09";
            // 
            // chk_0010_01_09
            // 
            resources.ApplyResources(this.chk_0010_01_09, "chk_0010_01_09");
            this.chk_0010_01_09.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_09.Name = "chk_0010_01_09";
            this.chk_0010_01_09.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_08
            // 
            this.cb_0010_01_08.DropDownHeight = 80;
            this.cb_0010_01_08.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_08.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_08, "cb_0010_01_08");
            this.cb_0010_01_08.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_08.Items"),
            resources.GetString("cb_0010_01_08.Items1"),
            resources.GetString("cb_0010_01_08.Items2"),
            resources.GetString("cb_0010_01_08.Items3"),
            resources.GetString("cb_0010_01_08.Items4"),
            resources.GetString("cb_0010_01_08.Items5"),
            resources.GetString("cb_0010_01_08.Items6"),
            resources.GetString("cb_0010_01_08.Items7"),
            resources.GetString("cb_0010_01_08.Items8"),
            resources.GetString("cb_0010_01_08.Items9"),
            resources.GetString("cb_0010_01_08.Items10"),
            resources.GetString("cb_0010_01_08.Items11"),
            resources.GetString("cb_0010_01_08.Items12"),
            resources.GetString("cb_0010_01_08.Items13"),
            resources.GetString("cb_0010_01_08.Items14"),
            resources.GetString("cb_0010_01_08.Items15"),
            resources.GetString("cb_0010_01_08.Items16"),
            resources.GetString("cb_0010_01_08.Items17"),
            resources.GetString("cb_0010_01_08.Items18"),
            resources.GetString("cb_0010_01_08.Items19"),
            resources.GetString("cb_0010_01_08.Items20"),
            resources.GetString("cb_0010_01_08.Items21"),
            resources.GetString("cb_0010_01_08.Items22"),
            resources.GetString("cb_0010_01_08.Items23"),
            resources.GetString("cb_0010_01_08.Items24"),
            resources.GetString("cb_0010_01_08.Items25"),
            resources.GetString("cb_0010_01_08.Items26"),
            resources.GetString("cb_0010_01_08.Items27"),
            resources.GetString("cb_0010_01_08.Items28"),
            resources.GetString("cb_0010_01_08.Items29"),
            resources.GetString("cb_0010_01_08.Items30"),
            resources.GetString("cb_0010_01_08.Items31"),
            resources.GetString("cb_0010_01_08.Items32"),
            resources.GetString("cb_0010_01_08.Items33"),
            resources.GetString("cb_0010_01_08.Items34"),
            resources.GetString("cb_0010_01_08.Items35"),
            resources.GetString("cb_0010_01_08.Items36")});
            this.cb_0010_01_08.Name = "cb_0010_01_08";
            // 
            // chk_0010_01_08
            // 
            resources.ApplyResources(this.chk_0010_01_08, "chk_0010_01_08");
            this.chk_0010_01_08.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_08.Name = "chk_0010_01_08";
            this.chk_0010_01_08.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_07
            // 
            this.cb_0010_01_07.DropDownHeight = 80;
            this.cb_0010_01_07.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_07.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_07, "cb_0010_01_07");
            this.cb_0010_01_07.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_07.Items"),
            resources.GetString("cb_0010_01_07.Items1"),
            resources.GetString("cb_0010_01_07.Items2"),
            resources.GetString("cb_0010_01_07.Items3"),
            resources.GetString("cb_0010_01_07.Items4"),
            resources.GetString("cb_0010_01_07.Items5"),
            resources.GetString("cb_0010_01_07.Items6"),
            resources.GetString("cb_0010_01_07.Items7"),
            resources.GetString("cb_0010_01_07.Items8"),
            resources.GetString("cb_0010_01_07.Items9"),
            resources.GetString("cb_0010_01_07.Items10"),
            resources.GetString("cb_0010_01_07.Items11"),
            resources.GetString("cb_0010_01_07.Items12"),
            resources.GetString("cb_0010_01_07.Items13"),
            resources.GetString("cb_0010_01_07.Items14"),
            resources.GetString("cb_0010_01_07.Items15"),
            resources.GetString("cb_0010_01_07.Items16"),
            resources.GetString("cb_0010_01_07.Items17"),
            resources.GetString("cb_0010_01_07.Items18"),
            resources.GetString("cb_0010_01_07.Items19"),
            resources.GetString("cb_0010_01_07.Items20"),
            resources.GetString("cb_0010_01_07.Items21"),
            resources.GetString("cb_0010_01_07.Items22"),
            resources.GetString("cb_0010_01_07.Items23"),
            resources.GetString("cb_0010_01_07.Items24"),
            resources.GetString("cb_0010_01_07.Items25"),
            resources.GetString("cb_0010_01_07.Items26"),
            resources.GetString("cb_0010_01_07.Items27"),
            resources.GetString("cb_0010_01_07.Items28"),
            resources.GetString("cb_0010_01_07.Items29"),
            resources.GetString("cb_0010_01_07.Items30"),
            resources.GetString("cb_0010_01_07.Items31"),
            resources.GetString("cb_0010_01_07.Items32"),
            resources.GetString("cb_0010_01_07.Items33"),
            resources.GetString("cb_0010_01_07.Items34"),
            resources.GetString("cb_0010_01_07.Items35"),
            resources.GetString("cb_0010_01_07.Items36")});
            this.cb_0010_01_07.Name = "cb_0010_01_07";
            // 
            // chk_0010_01_07
            // 
            resources.ApplyResources(this.chk_0010_01_07, "chk_0010_01_07");
            this.chk_0010_01_07.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_07.Name = "chk_0010_01_07";
            this.chk_0010_01_07.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_06
            // 
            this.cb_0010_01_06.DropDownHeight = 80;
            this.cb_0010_01_06.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_06.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_06, "cb_0010_01_06");
            this.cb_0010_01_06.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_06.Items"),
            resources.GetString("cb_0010_01_06.Items1"),
            resources.GetString("cb_0010_01_06.Items2"),
            resources.GetString("cb_0010_01_06.Items3"),
            resources.GetString("cb_0010_01_06.Items4"),
            resources.GetString("cb_0010_01_06.Items5"),
            resources.GetString("cb_0010_01_06.Items6"),
            resources.GetString("cb_0010_01_06.Items7"),
            resources.GetString("cb_0010_01_06.Items8"),
            resources.GetString("cb_0010_01_06.Items9"),
            resources.GetString("cb_0010_01_06.Items10"),
            resources.GetString("cb_0010_01_06.Items11"),
            resources.GetString("cb_0010_01_06.Items12"),
            resources.GetString("cb_0010_01_06.Items13"),
            resources.GetString("cb_0010_01_06.Items14"),
            resources.GetString("cb_0010_01_06.Items15"),
            resources.GetString("cb_0010_01_06.Items16"),
            resources.GetString("cb_0010_01_06.Items17"),
            resources.GetString("cb_0010_01_06.Items18"),
            resources.GetString("cb_0010_01_06.Items19"),
            resources.GetString("cb_0010_01_06.Items20"),
            resources.GetString("cb_0010_01_06.Items21"),
            resources.GetString("cb_0010_01_06.Items22"),
            resources.GetString("cb_0010_01_06.Items23"),
            resources.GetString("cb_0010_01_06.Items24"),
            resources.GetString("cb_0010_01_06.Items25"),
            resources.GetString("cb_0010_01_06.Items26"),
            resources.GetString("cb_0010_01_06.Items27"),
            resources.GetString("cb_0010_01_06.Items28"),
            resources.GetString("cb_0010_01_06.Items29"),
            resources.GetString("cb_0010_01_06.Items30"),
            resources.GetString("cb_0010_01_06.Items31"),
            resources.GetString("cb_0010_01_06.Items32"),
            resources.GetString("cb_0010_01_06.Items33"),
            resources.GetString("cb_0010_01_06.Items34"),
            resources.GetString("cb_0010_01_06.Items35"),
            resources.GetString("cb_0010_01_06.Items36")});
            this.cb_0010_01_06.Name = "cb_0010_01_06";
            // 
            // chk_0010_01_06
            // 
            resources.ApplyResources(this.chk_0010_01_06, "chk_0010_01_06");
            this.chk_0010_01_06.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_06.Name = "chk_0010_01_06";
            this.chk_0010_01_06.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_05
            // 
            this.cb_0010_01_05.DropDownHeight = 80;
            this.cb_0010_01_05.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_05.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_05, "cb_0010_01_05");
            this.cb_0010_01_05.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_05.Items"),
            resources.GetString("cb_0010_01_05.Items1"),
            resources.GetString("cb_0010_01_05.Items2"),
            resources.GetString("cb_0010_01_05.Items3"),
            resources.GetString("cb_0010_01_05.Items4"),
            resources.GetString("cb_0010_01_05.Items5"),
            resources.GetString("cb_0010_01_05.Items6"),
            resources.GetString("cb_0010_01_05.Items7"),
            resources.GetString("cb_0010_01_05.Items8"),
            resources.GetString("cb_0010_01_05.Items9"),
            resources.GetString("cb_0010_01_05.Items10"),
            resources.GetString("cb_0010_01_05.Items11"),
            resources.GetString("cb_0010_01_05.Items12"),
            resources.GetString("cb_0010_01_05.Items13"),
            resources.GetString("cb_0010_01_05.Items14"),
            resources.GetString("cb_0010_01_05.Items15"),
            resources.GetString("cb_0010_01_05.Items16"),
            resources.GetString("cb_0010_01_05.Items17"),
            resources.GetString("cb_0010_01_05.Items18"),
            resources.GetString("cb_0010_01_05.Items19"),
            resources.GetString("cb_0010_01_05.Items20"),
            resources.GetString("cb_0010_01_05.Items21"),
            resources.GetString("cb_0010_01_05.Items22"),
            resources.GetString("cb_0010_01_05.Items23"),
            resources.GetString("cb_0010_01_05.Items24"),
            resources.GetString("cb_0010_01_05.Items25"),
            resources.GetString("cb_0010_01_05.Items26"),
            resources.GetString("cb_0010_01_05.Items27"),
            resources.GetString("cb_0010_01_05.Items28"),
            resources.GetString("cb_0010_01_05.Items29"),
            resources.GetString("cb_0010_01_05.Items30"),
            resources.GetString("cb_0010_01_05.Items31"),
            resources.GetString("cb_0010_01_05.Items32"),
            resources.GetString("cb_0010_01_05.Items33"),
            resources.GetString("cb_0010_01_05.Items34"),
            resources.GetString("cb_0010_01_05.Items35"),
            resources.GetString("cb_0010_01_05.Items36")});
            this.cb_0010_01_05.Name = "cb_0010_01_05";
            // 
            // chk_0010_01_05
            // 
            resources.ApplyResources(this.chk_0010_01_05, "chk_0010_01_05");
            this.chk_0010_01_05.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_05.Name = "chk_0010_01_05";
            this.chk_0010_01_05.UseVisualStyleBackColor = false;
            // 
            // btn_0010_01_Set
            // 
            this.btn_0010_01_Set.BackColor = System.Drawing.Color.Transparent;
            this.btn_0010_01_Set.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_01_Set.DownImage")));
            resources.ApplyResources(this.btn_0010_01_Set, "btn_0010_01_Set");
            this.btn_0010_01_Set.IsShowBorder = true;
            this.btn_0010_01_Set.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_01_Set.MoveImage")));
            this.btn_0010_01_Set.Name = "btn_0010_01_Set";
            this.btn_0010_01_Set.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_01_Set.NormalImage")));
            this.btn_0010_01_Set.UseVisualStyleBackColor = false;
            this.btn_0010_01_Set.Click += new System.EventHandler(this.btn_0010_01_Set_Click);
            // 
            // btn_0010_02_Get
            // 
            this.btn_0010_02_Get.BackColor = System.Drawing.Color.Transparent;
            this.btn_0010_02_Get.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_02_Get.DownImage")));
            resources.ApplyResources(this.btn_0010_02_Get, "btn_0010_02_Get");
            this.btn_0010_02_Get.IsShowBorder = true;
            this.btn_0010_02_Get.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_02_Get.MoveImage")));
            this.btn_0010_02_Get.Name = "btn_0010_02_Get";
            this.btn_0010_02_Get.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_02_Get.NormalImage")));
            this.btn_0010_02_Get.UseVisualStyleBackColor = false;
            this.btn_0010_02_Get.Click += new System.EventHandler(this.btn_0010_02_Get_Click);
            // 
            // cb_0010_01_04
            // 
            this.cb_0010_01_04.DropDownHeight = 80;
            this.cb_0010_01_04.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_04.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_04, "cb_0010_01_04");
            this.cb_0010_01_04.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_04.Items"),
            resources.GetString("cb_0010_01_04.Items1"),
            resources.GetString("cb_0010_01_04.Items2"),
            resources.GetString("cb_0010_01_04.Items3"),
            resources.GetString("cb_0010_01_04.Items4"),
            resources.GetString("cb_0010_01_04.Items5"),
            resources.GetString("cb_0010_01_04.Items6"),
            resources.GetString("cb_0010_01_04.Items7"),
            resources.GetString("cb_0010_01_04.Items8"),
            resources.GetString("cb_0010_01_04.Items9"),
            resources.GetString("cb_0010_01_04.Items10"),
            resources.GetString("cb_0010_01_04.Items11"),
            resources.GetString("cb_0010_01_04.Items12"),
            resources.GetString("cb_0010_01_04.Items13"),
            resources.GetString("cb_0010_01_04.Items14"),
            resources.GetString("cb_0010_01_04.Items15"),
            resources.GetString("cb_0010_01_04.Items16"),
            resources.GetString("cb_0010_01_04.Items17"),
            resources.GetString("cb_0010_01_04.Items18"),
            resources.GetString("cb_0010_01_04.Items19"),
            resources.GetString("cb_0010_01_04.Items20"),
            resources.GetString("cb_0010_01_04.Items21"),
            resources.GetString("cb_0010_01_04.Items22"),
            resources.GetString("cb_0010_01_04.Items23"),
            resources.GetString("cb_0010_01_04.Items24"),
            resources.GetString("cb_0010_01_04.Items25"),
            resources.GetString("cb_0010_01_04.Items26"),
            resources.GetString("cb_0010_01_04.Items27"),
            resources.GetString("cb_0010_01_04.Items28"),
            resources.GetString("cb_0010_01_04.Items29"),
            resources.GetString("cb_0010_01_04.Items30"),
            resources.GetString("cb_0010_01_04.Items31"),
            resources.GetString("cb_0010_01_04.Items32"),
            resources.GetString("cb_0010_01_04.Items33"),
            resources.GetString("cb_0010_01_04.Items34"),
            resources.GetString("cb_0010_01_04.Items35"),
            resources.GetString("cb_0010_01_04.Items36")});
            this.cb_0010_01_04.Name = "cb_0010_01_04";
            // 
            // chk_0010_01_04
            // 
            resources.ApplyResources(this.chk_0010_01_04, "chk_0010_01_04");
            this.chk_0010_01_04.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_04.Name = "chk_0010_01_04";
            this.chk_0010_01_04.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_03
            // 
            this.cb_0010_01_03.DropDownHeight = 80;
            this.cb_0010_01_03.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_03.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_03, "cb_0010_01_03");
            this.cb_0010_01_03.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_03.Items"),
            resources.GetString("cb_0010_01_03.Items1"),
            resources.GetString("cb_0010_01_03.Items2"),
            resources.GetString("cb_0010_01_03.Items3"),
            resources.GetString("cb_0010_01_03.Items4"),
            resources.GetString("cb_0010_01_03.Items5"),
            resources.GetString("cb_0010_01_03.Items6"),
            resources.GetString("cb_0010_01_03.Items7"),
            resources.GetString("cb_0010_01_03.Items8"),
            resources.GetString("cb_0010_01_03.Items9"),
            resources.GetString("cb_0010_01_03.Items10"),
            resources.GetString("cb_0010_01_03.Items11"),
            resources.GetString("cb_0010_01_03.Items12"),
            resources.GetString("cb_0010_01_03.Items13"),
            resources.GetString("cb_0010_01_03.Items14"),
            resources.GetString("cb_0010_01_03.Items15"),
            resources.GetString("cb_0010_01_03.Items16"),
            resources.GetString("cb_0010_01_03.Items17"),
            resources.GetString("cb_0010_01_03.Items18"),
            resources.GetString("cb_0010_01_03.Items19"),
            resources.GetString("cb_0010_01_03.Items20"),
            resources.GetString("cb_0010_01_03.Items21"),
            resources.GetString("cb_0010_01_03.Items22"),
            resources.GetString("cb_0010_01_03.Items23"),
            resources.GetString("cb_0010_01_03.Items24"),
            resources.GetString("cb_0010_01_03.Items25"),
            resources.GetString("cb_0010_01_03.Items26"),
            resources.GetString("cb_0010_01_03.Items27"),
            resources.GetString("cb_0010_01_03.Items28"),
            resources.GetString("cb_0010_01_03.Items29"),
            resources.GetString("cb_0010_01_03.Items30"),
            resources.GetString("cb_0010_01_03.Items31"),
            resources.GetString("cb_0010_01_03.Items32"),
            resources.GetString("cb_0010_01_03.Items33"),
            resources.GetString("cb_0010_01_03.Items34"),
            resources.GetString("cb_0010_01_03.Items35"),
            resources.GetString("cb_0010_01_03.Items36")});
            this.cb_0010_01_03.Name = "cb_0010_01_03";
            // 
            // chk_0010_01_03
            // 
            resources.ApplyResources(this.chk_0010_01_03, "chk_0010_01_03");
            this.chk_0010_01_03.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_03.Name = "chk_0010_01_03";
            this.chk_0010_01_03.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_02
            // 
            this.cb_0010_01_02.DropDownHeight = 80;
            this.cb_0010_01_02.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_02.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_02, "cb_0010_01_02");
            this.cb_0010_01_02.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_02.Items"),
            resources.GetString("cb_0010_01_02.Items1"),
            resources.GetString("cb_0010_01_02.Items2"),
            resources.GetString("cb_0010_01_02.Items3"),
            resources.GetString("cb_0010_01_02.Items4"),
            resources.GetString("cb_0010_01_02.Items5"),
            resources.GetString("cb_0010_01_02.Items6"),
            resources.GetString("cb_0010_01_02.Items7"),
            resources.GetString("cb_0010_01_02.Items8"),
            resources.GetString("cb_0010_01_02.Items9"),
            resources.GetString("cb_0010_01_02.Items10"),
            resources.GetString("cb_0010_01_02.Items11"),
            resources.GetString("cb_0010_01_02.Items12"),
            resources.GetString("cb_0010_01_02.Items13"),
            resources.GetString("cb_0010_01_02.Items14"),
            resources.GetString("cb_0010_01_02.Items15"),
            resources.GetString("cb_0010_01_02.Items16"),
            resources.GetString("cb_0010_01_02.Items17"),
            resources.GetString("cb_0010_01_02.Items18"),
            resources.GetString("cb_0010_01_02.Items19"),
            resources.GetString("cb_0010_01_02.Items20"),
            resources.GetString("cb_0010_01_02.Items21"),
            resources.GetString("cb_0010_01_02.Items22"),
            resources.GetString("cb_0010_01_02.Items23"),
            resources.GetString("cb_0010_01_02.Items24"),
            resources.GetString("cb_0010_01_02.Items25"),
            resources.GetString("cb_0010_01_02.Items26"),
            resources.GetString("cb_0010_01_02.Items27"),
            resources.GetString("cb_0010_01_02.Items28"),
            resources.GetString("cb_0010_01_02.Items29"),
            resources.GetString("cb_0010_01_02.Items30"),
            resources.GetString("cb_0010_01_02.Items31"),
            resources.GetString("cb_0010_01_02.Items32"),
            resources.GetString("cb_0010_01_02.Items33"),
            resources.GetString("cb_0010_01_02.Items34"),
            resources.GetString("cb_0010_01_02.Items35"),
            resources.GetString("cb_0010_01_02.Items36")});
            this.cb_0010_01_02.Name = "cb_0010_01_02";
            // 
            // chk_0010_01_02
            // 
            resources.ApplyResources(this.chk_0010_01_02, "chk_0010_01_02");
            this.chk_0010_01_02.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_02.Name = "chk_0010_01_02";
            this.chk_0010_01_02.UseVisualStyleBackColor = false;
            // 
            // cb_0010_01_01
            // 
            this.cb_0010_01_01.DropDownHeight = 80;
            this.cb_0010_01_01.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_0010_01_01.FormattingEnabled = true;
            resources.ApplyResources(this.cb_0010_01_01, "cb_0010_01_01");
            this.cb_0010_01_01.Items.AddRange(new object[] {
            resources.GetString("cb_0010_01_01.Items"),
            resources.GetString("cb_0010_01_01.Items1"),
            resources.GetString("cb_0010_01_01.Items2"),
            resources.GetString("cb_0010_01_01.Items3"),
            resources.GetString("cb_0010_01_01.Items4"),
            resources.GetString("cb_0010_01_01.Items5"),
            resources.GetString("cb_0010_01_01.Items6"),
            resources.GetString("cb_0010_01_01.Items7"),
            resources.GetString("cb_0010_01_01.Items8"),
            resources.GetString("cb_0010_01_01.Items9"),
            resources.GetString("cb_0010_01_01.Items10"),
            resources.GetString("cb_0010_01_01.Items11"),
            resources.GetString("cb_0010_01_01.Items12"),
            resources.GetString("cb_0010_01_01.Items13"),
            resources.GetString("cb_0010_01_01.Items14"),
            resources.GetString("cb_0010_01_01.Items15"),
            resources.GetString("cb_0010_01_01.Items16"),
            resources.GetString("cb_0010_01_01.Items17"),
            resources.GetString("cb_0010_01_01.Items18"),
            resources.GetString("cb_0010_01_01.Items19"),
            resources.GetString("cb_0010_01_01.Items20"),
            resources.GetString("cb_0010_01_01.Items21"),
            resources.GetString("cb_0010_01_01.Items22"),
            resources.GetString("cb_0010_01_01.Items23"),
            resources.GetString("cb_0010_01_01.Items24"),
            resources.GetString("cb_0010_01_01.Items25"),
            resources.GetString("cb_0010_01_01.Items26"),
            resources.GetString("cb_0010_01_01.Items27"),
            resources.GetString("cb_0010_01_01.Items28"),
            resources.GetString("cb_0010_01_01.Items29"),
            resources.GetString("cb_0010_01_01.Items30"),
            resources.GetString("cb_0010_01_01.Items31"),
            resources.GetString("cb_0010_01_01.Items32"),
            resources.GetString("cb_0010_01_01.Items33"),
            resources.GetString("cb_0010_01_01.Items34"),
            resources.GetString("cb_0010_01_01.Items35"),
            resources.GetString("cb_0010_01_01.Items36")});
            this.cb_0010_01_01.Name = "cb_0010_01_01";
            // 
            // chk_0010_01_01
            // 
            resources.ApplyResources(this.chk_0010_01_01, "chk_0010_01_01");
            this.chk_0010_01_01.BackColor = System.Drawing.Color.Transparent;
            this.chk_0010_01_01.Name = "chk_0010_01_01";
            this.chk_0010_01_01.UseVisualStyleBackColor = false;
            // 
            // tc_Main
            // 
            this.tc_Main.BackColor = System.Drawing.Color.Transparent;
            this.tc_Main.BaseColor = System.Drawing.Color.White;
            this.tc_Main.BorderColor = System.Drawing.Color.White;
            this.tc_Main.Controls.Add(this.tp_Main);
            this.tc_Main.Controls.Add(this.tp_ReaderSet);
            this.tc_Main.Controls.Add(this.tp_GPIO);
            this.tc_Main.Controls.Add(this.tp_RestoreFactory);
            resources.ApplyResources(this.tc_Main, "tc_Main");
            this.tc_Main.Name = "tc_Main";
            this.tc_Main.PageColor = System.Drawing.Color.White;
            this.tc_Main.SelectedIndex = 0;
            this.tc_Main.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tc_Main.SelectedIndexChanged += new System.EventHandler(this.tc_Main_SelectedIndexChanged);
            // 
            // RFID_Option
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SimpleReaderDemo.Properties.Resources._100011;
            this.Controls.Add(this.tc_Main);
            this.IsResize = false;
            this.Name = "RFID_Option";
            this.ShowIcon = false;
            this.SysButton = SimpleReaderDemo.Forms.ESysButton.Close_Mini;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.RFID_Option_FormClosing);
            this.Load += new System.EventHandler(this.RFID_Option_Load);
            this.tp_RestoreFactory.ResumeLayout(false);
            this.tp_GPIO.ResumeLayout(false);
            this.gb_GPI.ResumeLayout(false);
            this.gb_GPI.PerformLayout();
            this.gb_GPO.ResumeLayout(false);
            this.gb_GPO.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.tp_ReaderSet.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox16.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tp_Main.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.gb_ANTEnable.ResumeLayout(false);
            this.gb_ANTEnable.PerformLayout();
            this.pl_New24Ant.ResumeLayout(false);
            this.pl_New24Ant.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.gb_SetANTPower.ResumeLayout(false);
            this.gb_SetANTPower.PerformLayout();
            this.tc_Main.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolTip toolTipTextBox;
        private System.Windows.Forms.TabPage tp_RestoreFactory;
        private MyFormTemplet.QQButton btn_RestoreFactory;
        private System.Windows.Forms.TabPage tp_GPIO;
        private System.Windows.Forms.GroupBox gb_GPI;
        private MyFormTemplet.QQButton btn_0001_0A_GET;
        private MyFormTemplet.RoundButton btn_GPI_4;
        private MyFormTemplet.RoundButton btn_GPI_3;
        private MyFormTemplet.RoundButton btn_GPI_2;
        private MyFormTemplet.RoundButton btn_GPI_1;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox gb_GPO;
        private System.Windows.Forms.ComboBox cmb_GPO_4;
        private System.Windows.Forms.ComboBox cmb_GPO_2;
        private System.Windows.Forms.ComboBox cmb_GPO_3;
        private System.Windows.Forms.ComboBox cmb_GPO_1;
        private MyFormTemplet.QQButton btn_0001_09_Hight;
        private MyFormTemplet.QQCheckBox chk_GPO_4;
        private MyFormTemplet.QQCheckBox chk_GPO_3;
        private MyFormTemplet.QQCheckBox chk_GPO_2;
        private MyFormTemplet.QQCheckBox chk_GPO_1;
        private System.Windows.Forms.GroupBox groupBox19;
        private MyFormTemplet.QQButton btn_0001_0E_Get;
        private MyFormTemplet.QQButton btn_0001_0D_Get;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox cb_0001_0D_02;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox cb_0001_0D_01;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox cb_0001_0D_00;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label lb_DelayTime_1;
        private MyFormTemplet.QQButton btn_0001_0C_Get;
        private MyFormTemplet.QQButton btn_0001_0B_Set;
        private System.Windows.Forms.TextBox tb_0001_0B_04;
        private System.Windows.Forms.Label lb_DelayTime;
        private System.Windows.Forms.ComboBox cb_0001_0B_03;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox tb_0001_0B_02;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox cb_0001_0B_01;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cb_0001_0B_00;
        private System.Windows.Forms.TabPage tp_ReaderSet;
        private System.Windows.Forms.GroupBox groupBox20;
        private MyFormTemplet.QQButton btn_0001_15_Set;
        private MyFormTemplet.QQButton btn_0001_16_Get;
        private System.Windows.Forms.Label label39;
        private MyFormTemplet.QQTextBoxEx tb_0001_15_00;
        private System.Windows.Forms.GroupBox groupBox18;
        private MyFormTemplet.QQButton btn_0001_07_Set;
        private MyFormTemplet.QQButton btn_0001_08_Get;
        private MyFormTemplet.QQTextBoxEx tb_0001_08_04;
        private MyFormTemplet.QQTextBoxEx tb_0001_08_03;
        private MyFormTemplet.QQTextBoxEx tb_0001_08_01;
        private MyFormTemplet.QQRadioButton rb_0001_08_02;
        private MyFormTemplet.QQRadioButton rb_0001_08_00;
        private System.Windows.Forms.GroupBox groupBox17;
        private MyFormTemplet.QQTextBoxEx tb_0001_10_00;
        private MyFormTemplet.QQButton btn_0001_10_Set;
        private MyFormTemplet.QQButton btn_0001_11_Get;
        private System.Windows.Forms.GroupBox groupBox16;
        private MyFormTemplet.QQTextBoxEx tb_0001_06_00;
        private MyFormTemplet.QQButton btn_0001_13_Set;
        private MyFormTemplet.QQButton btn_0001_06_Get;
        private System.Windows.Forms.GroupBox groupBox14;
        private MyFormTemplet.QQButton btn_0001_05_Set;
        private MyFormTemplet.QQButton btn_0001_04_Get;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private MyFormTemplet.QQTextBoxEx tb_0001_04_02;
        private MyFormTemplet.QQTextBoxEx tb_0001_04_01;
        private MyFormTemplet.QQTextBoxEx tb_0001_04_00;
        private System.Windows.Forms.GroupBox groupBox2;
        private MyFormTemplet.QQButton btn_0001_02_Set;
        private MyFormTemplet.QQButton btn_0001_02_Get;
        private System.Windows.Forms.ComboBox cb_0001_02_00;
        private System.Windows.Forms.TabPage tp_Main;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ComboBox cb_0010_03;
        private MyFormTemplet.QQButton btn_Set_0010_03;
        private MyFormTemplet.QQButton btn_0010_04_Get;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private MyFormTemplet.QQButton btn_0010_0B_Set;
        private MyFormTemplet.QQButton btn_0010_0C_Get;
        private System.Windows.Forms.ComboBox cb_0010_0B_03;
        private System.Windows.Forms.ComboBox cb_0010_0B_02;
        private System.Windows.Forms.ComboBox cb_0010_0B_01;
        private System.Windows.Forms.ComboBox cb_0010_0B_00;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label10;
        private MyFormTemplet.QQButton btn_0010_09_Set;
        private MyFormTemplet.QQButton btn_0010_0A_Get;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private MyFormTemplet.QQTextBoxEx tb_0010_09_01;
        private MyFormTemplet.QQTextBoxEx tb_0010_09_00;
        private System.Windows.Forms.GroupBox gb_ANTEnable;
        private MyFormTemplet.QQButton btn_0010_07_Set;
        private MyFormTemplet.QQButton btn_0010_08_Get;
        private System.Windows.Forms.GroupBox groupBox8;
        private MyFormTemplet.CheckedComboBox cb_0010_05_01;
        private MyFormTemplet.QQButton btn_0010_05_Set;
        private MyFormTemplet.QQButton btn_0010_06_Get;
        private System.Windows.Forms.ComboBox cb_0010_05_00;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label40;
        private MyFormTemplet.QQButton btn_0010_0D_Set;
        private MyFormTemplet.QQButton btn_0010_0E_Get;
        private System.Windows.Forms.Label label16;
        private MyFormTemplet.QQTextBoxEx tb_0010_0D_01;
        private System.Windows.Forms.ComboBox cb_0010_0D_00;
        private System.Windows.Forms.GroupBox gb_SetANTPower;
        private MyFormTemplet.QQButton btn_0010_01_Set;
        private MyFormTemplet.QQButton btn_0010_02_Get;
        private System.Windows.Forms.ComboBox cb_0010_01_04;
        private MyFormTemplet.QQCheckBox chk_0010_01_04;
        private System.Windows.Forms.ComboBox cb_0010_01_03;
        private MyFormTemplet.QQCheckBox chk_0010_01_03;
        private System.Windows.Forms.ComboBox cb_0010_01_02;
        private MyFormTemplet.QQCheckBox chk_0010_01_02;
        private System.Windows.Forms.ComboBox cb_0010_01_01;
        private MyFormTemplet.QQCheckBox chk_0010_01_01;
        private MyFormTemplet.QQTabControl tc_Main;
        private System.Windows.Forms.ComboBox cb_0010_01_08;
        private MyFormTemplet.QQCheckBox chk_0010_01_08;
        private System.Windows.Forms.ComboBox cb_0010_01_07;
        private MyFormTemplet.QQCheckBox chk_0010_01_07;
        private System.Windows.Forms.ComboBox cb_0010_01_06;
        private MyFormTemplet.QQCheckBox chk_0010_01_06;
        private System.Windows.Forms.ComboBox cb_0010_01_05;
        private MyFormTemplet.QQCheckBox chk_0010_01_05;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmb_0001_17_00;
        private System.Windows.Forms.Label label1;
        private MyFormTemplet.QQButton btn_0001_17_Set;
        private MyFormTemplet.QQButton btn_0001_18_Get;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ComboBox cmbSelfCheck;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cb_0001_0B_05;
        private System.Windows.Forms.Label lb_upload;
        private MyFormTemplet.QQTextBoxEx tbxSelfCheckIP;
        private System.Windows.Forms.Panel pl_New24Ant;
        private MyFormTemplet.QQCheckBox ANT24;
        private MyFormTemplet.QQCheckBox ANT23;
        private MyFormTemplet.QQCheckBox ANT22;
        private MyFormTemplet.QQCheckBox ANT21;
        private MyFormTemplet.QQCheckBox ANT20;
        private MyFormTemplet.QQCheckBox ANT19;
        private MyFormTemplet.QQCheckBox ANT18;
        private MyFormTemplet.QQCheckBox ANT17;
        private MyFormTemplet.QQCheckBox ANT16;
        private MyFormTemplet.QQCheckBox ANT15;
        private MyFormTemplet.QQCheckBox ANT14;
        private MyFormTemplet.QQCheckBox ANT13;
        private MyFormTemplet.QQCheckBox ANT12;
        private MyFormTemplet.QQCheckBox ANT11;
        private MyFormTemplet.QQCheckBox ANT10;
        private MyFormTemplet.QQCheckBox ANT9;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.ComboBox cb_0010_01_24;
        private MyFormTemplet.QQCheckBox chk_0010_01_24;
        private System.Windows.Forms.ComboBox cb_0010_01_23;
        private MyFormTemplet.QQCheckBox chk_0010_01_23;
        private System.Windows.Forms.ComboBox cb_0010_01_22;
        private MyFormTemplet.QQCheckBox chk_0010_01_22;
        private System.Windows.Forms.ComboBox cb_0010_01_21;
        private MyFormTemplet.QQCheckBox chk_0010_01_21;
        private System.Windows.Forms.ComboBox cb_0010_01_20;
        private MyFormTemplet.QQCheckBox chk_0010_01_20;
        private System.Windows.Forms.ComboBox cb_0010_01_19;
        private MyFormTemplet.QQCheckBox chk_0010_01_19;
        private System.Windows.Forms.ComboBox cb_0010_01_18;
        private MyFormTemplet.QQCheckBox chk_0010_01_18;
        private System.Windows.Forms.ComboBox cb_0010_01_17;
        private MyFormTemplet.QQCheckBox chk_0010_01_17;
        private System.Windows.Forms.ComboBox cb_0010_01_16;
        private MyFormTemplet.QQCheckBox chk_0010_01_16;
        private System.Windows.Forms.ComboBox cb_0010_01_15;
        private MyFormTemplet.QQCheckBox chk_0010_01_15;
        private System.Windows.Forms.ComboBox cb_0010_01_14;
        private MyFormTemplet.QQCheckBox chk_0010_01_14;
        private System.Windows.Forms.ComboBox cb_0010_01_13;
        private MyFormTemplet.QQCheckBox chk_0010_01_13;
        private System.Windows.Forms.ComboBox cb_0010_01_12;
        private MyFormTemplet.QQCheckBox chk_0010_01_12;
        private System.Windows.Forms.ComboBox cb_0010_01_11;
        private MyFormTemplet.QQCheckBox chk_0010_01_11;
        private System.Windows.Forms.ComboBox cb_0010_01_10;
        private MyFormTemplet.QQCheckBox chk_0010_01_10;
        private System.Windows.Forms.ComboBox cb_0010_01_09;
        private MyFormTemplet.QQCheckBox chk_0010_01_09;
        private MyFormTemplet.QQCheckBox cb_0010_07_08;
        private MyFormTemplet.QQCheckBox cb_0010_07_07;
        private MyFormTemplet.QQCheckBox cb_0010_07_06;
        private MyFormTemplet.QQCheckBox cb_0010_07_05;
        private MyFormTemplet.QQCheckBox cb_0010_07_04;
        private MyFormTemplet.QQCheckBox cb_0010_07_03;
        private MyFormTemplet.QQCheckBox cb_0010_07_02;
        private MyFormTemplet.QQCheckBox cb_0010_07_01;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button17;
		private System.Windows.Forms.GroupBox groupBox3;
		private MyFormTemplet.QQButton btn_0101_05;
		private System.Windows.Forms.ComboBox cb_FrequencySingle;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.ComboBox cb_ANTSingle;
    }
}