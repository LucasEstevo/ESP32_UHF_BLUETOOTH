﻿namespace SimpleReaderDemo.MySingleForm.TestForm
{
    partial class ReadTag_Param
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReadTag_Param));
            this.tc_Main = new SimpleReaderDemo.MyFormTemplet.QQTabControl();
            this.tp_6C = new System.Windows.Forms.TabPage();
            this.tb_09_01 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label23 = new System.Windows.Forms.Label();
            this.tb_09_00 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label24 = new System.Windows.Forms.Label();
            this.chk_10 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.qqTextBoxEx1 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label22 = new System.Windows.Forms.Label();
            this.chk_05 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.btn_Save_6C = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.tb_04_01 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label8 = new System.Windows.Forms.Label();
            this.tb_04_00 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label9 = new System.Windows.Forms.Label();
            this.tb_03_01 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label7 = new System.Windows.Forms.Label();
            this.tb_03_00 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label6 = new System.Windows.Forms.Label();
            this.chk_04 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.chk_03 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.tb_02_01 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cb_02_00 = new System.Windows.Forms.ComboBox();
            this.chk_02 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.tb_01_02 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_01_01 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.cb_01_00 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lb_0010_11_MatchStart = new System.Windows.Forms.Label();
            this.chk_01 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.tp_6B = new System.Windows.Forms.TabPage();
            this.btn_Save_6B = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.tb_0010_40_03 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.tb_0010_40_02 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.tb_0010_40_01 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.cb_0010_40_00 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tp_GB = new System.Windows.Forms.TabPage();
            this.txt_subUserDataIndex = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label20 = new System.Windows.Forms.Label();
            this.btn_Save_GB = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.label21 = new System.Windows.Forms.Label();
            this.cb_gb_04_00 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.cb_gb_03_02 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label18 = new System.Windows.Forms.Label();
            this.cb_gb_03_01 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label19 = new System.Windows.Forms.Label();
            this.chk_gb_03 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.cb_gb_02_01 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.cb_gb_02_00 = new System.Windows.Forms.ComboBox();
            this.chk_gb_02 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.tb_gb_01_02 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.label13 = new System.Windows.Forms.Label();
            this.tb_gb_01_01 = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.cb_gb_01_00 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.chk_gb_01 = new SimpleReaderDemo.MyFormTemplet.QQCheckBox();
            this.tc_Main.SuspendLayout();
            this.tp_6C.SuspendLayout();
            this.tp_6B.SuspendLayout();
            this.tp_GB.SuspendLayout();
            this.SuspendLayout();
            // 
            // tc_Main
            // 
            resources.ApplyResources(this.tc_Main, "tc_Main");
            this.tc_Main.BackColor = System.Drawing.Color.Transparent;
            this.tc_Main.BaseColor = System.Drawing.Color.White;
            this.tc_Main.BorderColor = System.Drawing.Color.White;
            this.tc_Main.Controls.Add(this.tp_6C);
            this.tc_Main.Controls.Add(this.tp_6B);
            this.tc_Main.Controls.Add(this.tp_GB);
            this.tc_Main.Name = "tc_Main";
            this.tc_Main.PageColor = System.Drawing.Color.White;
            this.tc_Main.SelectedIndex = 0;
            this.tc_Main.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            // 
            // tp_6C
            // 
            resources.ApplyResources(this.tp_6C, "tp_6C");
            this.tp_6C.BackColor = System.Drawing.Color.White;
            this.tp_6C.Controls.Add(this.tb_09_01);
            this.tp_6C.Controls.Add(this.label23);
            this.tp_6C.Controls.Add(this.tb_09_00);
            this.tp_6C.Controls.Add(this.label24);
            this.tp_6C.Controls.Add(this.chk_10);
            this.tp_6C.Controls.Add(this.qqTextBoxEx1);
            this.tp_6C.Controls.Add(this.label22);
            this.tp_6C.Controls.Add(this.chk_05);
            this.tp_6C.Controls.Add(this.btn_Save_6C);
            this.tp_6C.Controls.Add(this.tb_04_01);
            this.tp_6C.Controls.Add(this.label8);
            this.tp_6C.Controls.Add(this.tb_04_00);
            this.tp_6C.Controls.Add(this.label9);
            this.tp_6C.Controls.Add(this.tb_03_01);
            this.tp_6C.Controls.Add(this.label7);
            this.tp_6C.Controls.Add(this.tb_03_00);
            this.tp_6C.Controls.Add(this.label6);
            this.tp_6C.Controls.Add(this.chk_04);
            this.tp_6C.Controls.Add(this.chk_03);
            this.tp_6C.Controls.Add(this.tb_02_01);
            this.tp_6C.Controls.Add(this.label4);
            this.tp_6C.Controls.Add(this.label3);
            this.tp_6C.Controls.Add(this.cb_02_00);
            this.tp_6C.Controls.Add(this.chk_02);
            this.tp_6C.Controls.Add(this.tb_01_02);
            this.tp_6C.Controls.Add(this.label2);
            this.tp_6C.Controls.Add(this.tb_01_01);
            this.tp_6C.Controls.Add(this.cb_01_00);
            this.tp_6C.Controls.Add(this.label5);
            this.tp_6C.Controls.Add(this.lb_0010_11_MatchStart);
            this.tp_6C.Controls.Add(this.chk_01);
            this.tp_6C.Name = "tp_6C";
            // 
            // tb_09_01
            // 
            resources.ApplyResources(this.tb_09_01, "tb_09_01");
            this.tb_09_01.BackColor = System.Drawing.Color.Transparent;
            this.tb_09_01.Icon = null;
            this.tb_09_01.IconIsButton = false;
            this.tb_09_01.IsPasswordChat = '\0';
            this.tb_09_01.IsSystemPasswordChar = false;
            this.tb_09_01.Lines = new string[] {
        "4"};
            this.tb_09_01.MaxLength = 32767;
            this.tb_09_01.Multiline = false;
            this.tb_09_01.Name = "tb_09_01";
            this.tb_09_01.ReadOnly = false;
            this.tb_09_01.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_09_01.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_09_01.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_09_01.WaterText = "00";
            this.tb_09_01.WordWrap = true;
            // 
            // label23
            // 
            resources.ApplyResources(this.label23, "label23");
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Name = "label23";
            // 
            // tb_09_00
            // 
            resources.ApplyResources(this.tb_09_00, "tb_09_00");
            this.tb_09_00.BackColor = System.Drawing.Color.Transparent;
            this.tb_09_00.Icon = null;
            this.tb_09_00.IconIsButton = false;
            this.tb_09_00.IsPasswordChat = '\0';
            this.tb_09_00.IsSystemPasswordChar = false;
            this.tb_09_00.Lines = new string[] {
        "0"};
            this.tb_09_00.MaxLength = 32767;
            this.tb_09_00.Multiline = false;
            this.tb_09_00.Name = "tb_09_00";
            this.tb_09_00.ReadOnly = false;
            this.tb_09_00.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_09_00.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_09_00.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_09_00.WaterText = "0";
            this.tb_09_00.WordWrap = true;
            // 
            // label24
            // 
            resources.ApplyResources(this.label24, "label24");
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Name = "label24";
            // 
            // chk_10
            // 
            resources.ApplyResources(this.chk_10, "chk_10");
            this.chk_10.BackColor = System.Drawing.Color.Transparent;
            this.chk_10.Name = "chk_10";
            this.chk_10.UseVisualStyleBackColor = false;
            // 
            // qqTextBoxEx1
            // 
            resources.ApplyResources(this.qqTextBoxEx1, "qqTextBoxEx1");
            this.qqTextBoxEx1.BackColor = System.Drawing.Color.Transparent;
            this.qqTextBoxEx1.Icon = null;
            this.qqTextBoxEx1.IconIsButton = false;
            this.qqTextBoxEx1.IsPasswordChat = '\0';
            this.qqTextBoxEx1.IsSystemPasswordChar = false;
            this.qqTextBoxEx1.Lines = new string[0];
            this.qqTextBoxEx1.MaxLength = 32767;
            this.qqTextBoxEx1.Multiline = false;
            this.qqTextBoxEx1.Name = "qqTextBoxEx1";
            this.qqTextBoxEx1.ReadOnly = false;
            this.qqTextBoxEx1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.qqTextBoxEx1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.qqTextBoxEx1.WaterColor = System.Drawing.Color.DarkGray;
            this.qqTextBoxEx1.WaterText = "00000000";
            this.qqTextBoxEx1.WordWrap = true;
            // 
            // label22
            // 
            resources.ApplyResources(this.label22, "label22");
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Name = "label22";
            // 
            // chk_05
            // 
            resources.ApplyResources(this.chk_05, "chk_05");
            this.chk_05.BackColor = System.Drawing.Color.Transparent;
            this.chk_05.Name = "chk_05";
            this.chk_05.UseVisualStyleBackColor = false;
            // 
            // btn_Save_6C
            // 
            resources.ApplyResources(this.btn_Save_6C, "btn_Save_6C");
            this.btn_Save_6C.BackColor = System.Drawing.Color.Transparent;
            this.btn_Save_6C.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_Save_6C.DownImage")));
            this.btn_Save_6C.IsShowBorder = true;
            this.btn_Save_6C.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_Save_6C.MoveImage")));
            this.btn_Save_6C.Name = "btn_Save_6C";
            this.btn_Save_6C.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_Save_6C.NormalImage")));
            this.btn_Save_6C.UseVisualStyleBackColor = false;
            this.btn_Save_6C.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // tb_04_01
            // 
            resources.ApplyResources(this.tb_04_01, "tb_04_01");
            this.tb_04_01.BackColor = System.Drawing.Color.Transparent;
            this.tb_04_01.Icon = null;
            this.tb_04_01.IconIsButton = false;
            this.tb_04_01.IsPasswordChat = '\0';
            this.tb_04_01.IsSystemPasswordChar = false;
            this.tb_04_01.Lines = new string[] {
        "4"};
            this.tb_04_01.MaxLength = 32767;
            this.tb_04_01.Multiline = false;
            this.tb_04_01.Name = "tb_04_01";
            this.tb_04_01.ReadOnly = false;
            this.tb_04_01.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_04_01.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_04_01.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_04_01.WaterText = "00";
            this.tb_04_01.WordWrap = true;
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Name = "label8";
            // 
            // tb_04_00
            // 
            resources.ApplyResources(this.tb_04_00, "tb_04_00");
            this.tb_04_00.BackColor = System.Drawing.Color.Transparent;
            this.tb_04_00.Icon = null;
            this.tb_04_00.IconIsButton = false;
            this.tb_04_00.IsPasswordChat = '\0';
            this.tb_04_00.IsSystemPasswordChar = false;
            this.tb_04_00.Lines = new string[] {
        "0"};
            this.tb_04_00.MaxLength = 32767;
            this.tb_04_00.Multiline = false;
            this.tb_04_00.Name = "tb_04_00";
            this.tb_04_00.ReadOnly = false;
            this.tb_04_00.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_04_00.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_04_00.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_04_00.WaterText = "0";
            this.tb_04_00.WordWrap = true;
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Name = "label9";
            // 
            // tb_03_01
            // 
            resources.ApplyResources(this.tb_03_01, "tb_03_01");
            this.tb_03_01.BackColor = System.Drawing.Color.Transparent;
            this.tb_03_01.Icon = null;
            this.tb_03_01.IconIsButton = false;
            this.tb_03_01.IsPasswordChat = '\0';
            this.tb_03_01.IsSystemPasswordChar = false;
            this.tb_03_01.Lines = new string[] {
        "6"};
            this.tb_03_01.MaxLength = 32767;
            this.tb_03_01.Multiline = false;
            this.tb_03_01.Name = "tb_03_01";
            this.tb_03_01.ReadOnly = false;
            this.tb_03_01.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_03_01.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_03_01.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_03_01.WaterText = "0";
            this.tb_03_01.WordWrap = true;
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Name = "label7";
            // 
            // tb_03_00
            // 
            resources.ApplyResources(this.tb_03_00, "tb_03_00");
            this.tb_03_00.BackColor = System.Drawing.Color.Transparent;
            this.tb_03_00.Icon = null;
            this.tb_03_00.IconIsButton = false;
            this.tb_03_00.IsPasswordChat = '\0';
            this.tb_03_00.IsSystemPasswordChar = false;
            this.tb_03_00.Lines = new string[] {
        "0"};
            this.tb_03_00.MaxLength = 32767;
            this.tb_03_00.Multiline = false;
            this.tb_03_00.Name = "tb_03_00";
            this.tb_03_00.ReadOnly = false;
            this.tb_03_00.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_03_00.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_03_00.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_03_00.WaterText = "0";
            this.tb_03_00.WordWrap = true;
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Name = "label6";
            // 
            // chk_04
            // 
            resources.ApplyResources(this.chk_04, "chk_04");
            this.chk_04.BackColor = System.Drawing.Color.Transparent;
            this.chk_04.Name = "chk_04";
            this.chk_04.UseVisualStyleBackColor = false;
            // 
            // chk_03
            // 
            resources.ApplyResources(this.chk_03, "chk_03");
            this.chk_03.BackColor = System.Drawing.Color.Transparent;
            this.chk_03.Name = "chk_03";
            this.chk_03.UseVisualStyleBackColor = false;
            // 
            // tb_02_01
            // 
            resources.ApplyResources(this.tb_02_01, "tb_02_01");
            this.tb_02_01.BackColor = System.Drawing.Color.Transparent;
            this.tb_02_01.Icon = null;
            this.tb_02_01.IconIsButton = false;
            this.tb_02_01.IsPasswordChat = '\0';
            this.tb_02_01.IsSystemPasswordChar = false;
            this.tb_02_01.Lines = new string[] {
        "6"};
            this.tb_02_01.MaxLength = 32767;
            this.tb_02_01.Multiline = false;
            this.tb_02_01.Name = "tb_02_01";
            this.tb_02_01.ReadOnly = false;
            this.tb_02_01.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_02_01.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_02_01.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_02_01.WaterText = "0";
            this.tb_02_01.WordWrap = true;
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Name = "label4";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Name = "label3";
            // 
            // cb_02_00
            // 
            resources.ApplyResources(this.cb_02_00, "cb_02_00");
            this.cb_02_00.FormattingEnabled = true;
            this.cb_02_00.Items.AddRange(new object[] {
            resources.GetString("cb_02_00.Items"),
            resources.GetString("cb_02_00.Items1")});
            this.cb_02_00.Name = "cb_02_00";
            // 
            // chk_02
            // 
            resources.ApplyResources(this.chk_02, "chk_02");
            this.chk_02.BackColor = System.Drawing.Color.Transparent;
            this.chk_02.Name = "chk_02";
            this.chk_02.UseVisualStyleBackColor = false;
            // 
            // tb_01_02
            // 
            resources.ApplyResources(this.tb_01_02, "tb_01_02");
            this.tb_01_02.BackColor = System.Drawing.Color.Transparent;
            this.tb_01_02.Icon = null;
            this.tb_01_02.IconIsButton = false;
            this.tb_01_02.IsPasswordChat = '\0';
            this.tb_01_02.IsSystemPasswordChar = false;
            this.tb_01_02.Lines = new string[0];
            this.tb_01_02.MaxLength = 32767;
            this.tb_01_02.Multiline = false;
            this.tb_01_02.Name = "tb_01_02";
            this.tb_01_02.ReadOnly = false;
            this.tb_01_02.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_01_02.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_01_02.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_01_02.WaterText = "0000";
            this.tb_01_02.WordWrap = true;
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Name = "label2";
            // 
            // tb_01_01
            // 
            resources.ApplyResources(this.tb_01_01, "tb_01_01");
            this.tb_01_01.BackColor = System.Drawing.Color.Transparent;
            this.tb_01_01.Icon = null;
            this.tb_01_01.IconIsButton = false;
            this.tb_01_01.IsPasswordChat = '\0';
            this.tb_01_01.IsSystemPasswordChar = false;
            this.tb_01_01.Lines = new string[] {
        "0"};
            this.tb_01_01.MaxLength = 32767;
            this.tb_01_01.Multiline = false;
            this.tb_01_01.Name = "tb_01_01";
            this.tb_01_01.ReadOnly = false;
            this.tb_01_01.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_01_01.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_01_01.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_01_01.WaterText = "0000";
            this.tb_01_01.WordWrap = true;
            // 
            // cb_01_00
            // 
            resources.ApplyResources(this.cb_01_00, "cb_01_00");
            this.cb_01_00.AutoCompleteCustomSource.AddRange(new string[] {
            resources.GetString("cb_01_00.AutoCompleteCustomSource"),
            resources.GetString("cb_01_00.AutoCompleteCustomSource1"),
            resources.GetString("cb_01_00.AutoCompleteCustomSource2"),
            resources.GetString("cb_01_00.AutoCompleteCustomSource3")});
            this.cb_01_00.FormattingEnabled = true;
            this.cb_01_00.Items.AddRange(new object[] {
            resources.GetString("cb_01_00.Items"),
            resources.GetString("cb_01_00.Items1"),
            resources.GetString("cb_01_00.Items2")});
            this.cb_01_00.Name = "cb_01_00";
            this.cb_01_00.SelectedIndexChanged += new System.EventHandler(this.cb_01_00_SelectedIndexChanged);
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Name = "label5";
            // 
            // lb_0010_11_MatchStart
            // 
            resources.ApplyResources(this.lb_0010_11_MatchStart, "lb_0010_11_MatchStart");
            this.lb_0010_11_MatchStart.BackColor = System.Drawing.Color.Transparent;
            this.lb_0010_11_MatchStart.Name = "lb_0010_11_MatchStart";
            // 
            // chk_01
            // 
            resources.ApplyResources(this.chk_01, "chk_01");
            this.chk_01.BackColor = System.Drawing.Color.Transparent;
            this.chk_01.Name = "chk_01";
            this.chk_01.UseVisualStyleBackColor = false;
            // 
            // tp_6B
            // 
            resources.ApplyResources(this.tp_6B, "tp_6B");
            this.tp_6B.BackColor = System.Drawing.Color.White;
            this.tp_6B.Controls.Add(this.btn_Save_6B);
            this.tp_6B.Controls.Add(this.tb_0010_40_03);
            this.tp_6B.Controls.Add(this.tb_0010_40_02);
            this.tp_6B.Controls.Add(this.tb_0010_40_01);
            this.tp_6B.Controls.Add(this.label1);
            this.tp_6B.Controls.Add(this.label10);
            this.tp_6B.Controls.Add(this.label11);
            this.tp_6B.Controls.Add(this.cb_0010_40_00);
            this.tp_6B.Controls.Add(this.label12);
            this.tp_6B.Name = "tp_6B";
            // 
            // btn_Save_6B
            // 
            resources.ApplyResources(this.btn_Save_6B, "btn_Save_6B");
            this.btn_Save_6B.BackColor = System.Drawing.Color.Transparent;
            this.btn_Save_6B.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_Save_6B.DownImage")));
            this.btn_Save_6B.IsShowBorder = true;
            this.btn_Save_6B.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_Save_6B.MoveImage")));
            this.btn_Save_6B.Name = "btn_Save_6B";
            this.btn_Save_6B.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_Save_6B.NormalImage")));
            this.btn_Save_6B.UseVisualStyleBackColor = false;
            this.btn_Save_6B.Click += new System.EventHandler(this.btn_Save_6B_Click);
            // 
            // tb_0010_40_03
            // 
            resources.ApplyResources(this.tb_0010_40_03, "tb_0010_40_03");
            this.tb_0010_40_03.BackColor = System.Drawing.Color.Transparent;
            this.tb_0010_40_03.Icon = null;
            this.tb_0010_40_03.IconIsButton = false;
            this.tb_0010_40_03.IsPasswordChat = '\0';
            this.tb_0010_40_03.IsSystemPasswordChar = false;
            this.tb_0010_40_03.Lines = new string[0];
            this.tb_0010_40_03.MaxLength = 32767;
            this.tb_0010_40_03.Multiline = false;
            this.tb_0010_40_03.Name = "tb_0010_40_03";
            this.tb_0010_40_03.ReadOnly = false;
            this.tb_0010_40_03.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_0010_40_03.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_0010_40_03.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_0010_40_03.WaterText = "00";
            this.tb_0010_40_03.WordWrap = true;
            // 
            // tb_0010_40_02
            // 
            resources.ApplyResources(this.tb_0010_40_02, "tb_0010_40_02");
            this.tb_0010_40_02.BackColor = System.Drawing.Color.Transparent;
            this.tb_0010_40_02.Icon = null;
            this.tb_0010_40_02.IconIsButton = false;
            this.tb_0010_40_02.IsPasswordChat = '\0';
            this.tb_0010_40_02.IsSystemPasswordChar = false;
            this.tb_0010_40_02.Lines = new string[0];
            this.tb_0010_40_02.MaxLength = 32767;
            this.tb_0010_40_02.Multiline = false;
            this.tb_0010_40_02.Name = "tb_0010_40_02";
            this.tb_0010_40_02.ReadOnly = false;
            this.tb_0010_40_02.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_0010_40_02.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_0010_40_02.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_0010_40_02.WaterText = "00";
            this.tb_0010_40_02.WordWrap = true;
            // 
            // tb_0010_40_01
            // 
            resources.ApplyResources(this.tb_0010_40_01, "tb_0010_40_01");
            this.tb_0010_40_01.BackColor = System.Drawing.Color.Transparent;
            this.tb_0010_40_01.Icon = null;
            this.tb_0010_40_01.IconIsButton = false;
            this.tb_0010_40_01.IsPasswordChat = '\0';
            this.tb_0010_40_01.IsSystemPasswordChar = false;
            this.tb_0010_40_01.Lines = new string[0];
            this.tb_0010_40_01.MaxLength = 32767;
            this.tb_0010_40_01.Multiline = false;
            this.tb_0010_40_01.Name = "tb_0010_40_01";
            this.tb_0010_40_01.ReadOnly = false;
            this.tb_0010_40_01.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_0010_40_01.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_0010_40_01.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_0010_40_01.WaterText = "00";
            this.tb_0010_40_01.WordWrap = true;
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Name = "label1";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Name = "label10";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Name = "label11";
            // 
            // cb_0010_40_00
            // 
            resources.ApplyResources(this.cb_0010_40_00, "cb_0010_40_00");
            this.cb_0010_40_00.FormattingEnabled = true;
            this.cb_0010_40_00.Items.AddRange(new object[] {
            resources.GetString("cb_0010_40_00.Items"),
            resources.GetString("cb_0010_40_00.Items1"),
            resources.GetString("cb_0010_40_00.Items2")});
            this.cb_0010_40_00.Name = "cb_0010_40_00";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Name = "label12";
            // 
            // tp_GB
            // 
            resources.ApplyResources(this.tp_GB, "tp_GB");
            this.tp_GB.BackColor = System.Drawing.Color.White;
            this.tp_GB.Controls.Add(this.txt_subUserDataIndex);
            this.tp_GB.Controls.Add(this.label20);
            this.tp_GB.Controls.Add(this.btn_Save_GB);
            this.tp_GB.Controls.Add(this.label21);
            this.tp_GB.Controls.Add(this.cb_gb_04_00);
            this.tp_GB.Controls.Add(this.cb_gb_03_02);
            this.tp_GB.Controls.Add(this.label18);
            this.tp_GB.Controls.Add(this.cb_gb_03_01);
            this.tp_GB.Controls.Add(this.label19);
            this.tp_GB.Controls.Add(this.chk_gb_03);
            this.tp_GB.Controls.Add(this.cb_gb_02_01);
            this.tp_GB.Controls.Add(this.label16);
            this.tp_GB.Controls.Add(this.label17);
            this.tp_GB.Controls.Add(this.cb_gb_02_00);
            this.tp_GB.Controls.Add(this.chk_gb_02);
            this.tp_GB.Controls.Add(this.tb_gb_01_02);
            this.tp_GB.Controls.Add(this.label13);
            this.tp_GB.Controls.Add(this.tb_gb_01_01);
            this.tp_GB.Controls.Add(this.cb_gb_01_00);
            this.tp_GB.Controls.Add(this.label14);
            this.tp_GB.Controls.Add(this.label15);
            this.tp_GB.Controls.Add(this.chk_gb_01);
            this.tp_GB.Name = "tp_GB";
            // 
            // txt_subUserDataIndex
            // 
            resources.ApplyResources(this.txt_subUserDataIndex, "txt_subUserDataIndex");
            this.txt_subUserDataIndex.BackColor = System.Drawing.Color.Transparent;
            this.txt_subUserDataIndex.Icon = null;
            this.txt_subUserDataIndex.IconIsButton = false;
            this.txt_subUserDataIndex.IsPasswordChat = '\0';
            this.txt_subUserDataIndex.IsSystemPasswordChar = false;
            this.txt_subUserDataIndex.Lines = new string[] {
        "0"};
            this.txt_subUserDataIndex.MaxLength = 32767;
            this.txt_subUserDataIndex.Multiline = false;
            this.txt_subUserDataIndex.Name = "txt_subUserDataIndex";
            this.txt_subUserDataIndex.ReadOnly = false;
            this.txt_subUserDataIndex.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_subUserDataIndex.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_subUserDataIndex.WaterColor = System.Drawing.Color.DarkGray;
            this.txt_subUserDataIndex.WaterText = "0";
            this.txt_subUserDataIndex.WordWrap = true;
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Name = "label20";
            // 
            // btn_Save_GB
            // 
            resources.ApplyResources(this.btn_Save_GB, "btn_Save_GB");
            this.btn_Save_GB.BackColor = System.Drawing.Color.Transparent;
            this.btn_Save_GB.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_Save_GB.DownImage")));
            this.btn_Save_GB.IsShowBorder = true;
            this.btn_Save_GB.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_Save_GB.MoveImage")));
            this.btn_Save_GB.Name = "btn_Save_GB";
            this.btn_Save_GB.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_Save_GB.NormalImage")));
            this.btn_Save_GB.UseVisualStyleBackColor = false;
            this.btn_Save_GB.Click += new System.EventHandler(this.btn_Save_GB_Click);
            // 
            // label21
            // 
            resources.ApplyResources(this.label21, "label21");
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Name = "label21";
            // 
            // cb_gb_04_00
            // 
            resources.ApplyResources(this.cb_gb_04_00, "cb_gb_04_00");
            this.cb_gb_04_00.BackColor = System.Drawing.Color.Transparent;
            this.cb_gb_04_00.Icon = null;
            this.cb_gb_04_00.IconIsButton = false;
            this.cb_gb_04_00.IsPasswordChat = '\0';
            this.cb_gb_04_00.IsSystemPasswordChar = false;
            this.cb_gb_04_00.Lines = new string[0];
            this.cb_gb_04_00.MaxLength = 32767;
            this.cb_gb_04_00.Multiline = false;
            this.cb_gb_04_00.Name = "cb_gb_04_00";
            this.cb_gb_04_00.ReadOnly = false;
            this.cb_gb_04_00.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.cb_gb_04_00.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.cb_gb_04_00.WaterColor = System.Drawing.Color.DarkGray;
            this.cb_gb_04_00.WaterText = "0000";
            this.cb_gb_04_00.WordWrap = true;
            // 
            // cb_gb_03_02
            // 
            resources.ApplyResources(this.cb_gb_03_02, "cb_gb_03_02");
            this.cb_gb_03_02.BackColor = System.Drawing.Color.Transparent;
            this.cb_gb_03_02.Icon = null;
            this.cb_gb_03_02.IconIsButton = false;
            this.cb_gb_03_02.IsPasswordChat = '\0';
            this.cb_gb_03_02.IsSystemPasswordChar = false;
            this.cb_gb_03_02.Lines = new string[] {
        "6"};
            this.cb_gb_03_02.MaxLength = 32767;
            this.cb_gb_03_02.Multiline = false;
            this.cb_gb_03_02.Name = "cb_gb_03_02";
            this.cb_gb_03_02.ReadOnly = false;
            this.cb_gb_03_02.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.cb_gb_03_02.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.cb_gb_03_02.WaterColor = System.Drawing.Color.DarkGray;
            this.cb_gb_03_02.WaterText = "0";
            this.cb_gb_03_02.WordWrap = true;
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Name = "label18";
            // 
            // cb_gb_03_01
            // 
            resources.ApplyResources(this.cb_gb_03_01, "cb_gb_03_01");
            this.cb_gb_03_01.BackColor = System.Drawing.Color.Transparent;
            this.cb_gb_03_01.Icon = null;
            this.cb_gb_03_01.IconIsButton = false;
            this.cb_gb_03_01.IsPasswordChat = '\0';
            this.cb_gb_03_01.IsSystemPasswordChar = false;
            this.cb_gb_03_01.Lines = new string[] {
        "4"};
            this.cb_gb_03_01.MaxLength = 32767;
            this.cb_gb_03_01.Multiline = false;
            this.cb_gb_03_01.Name = "cb_gb_03_01";
            this.cb_gb_03_01.ReadOnly = false;
            this.cb_gb_03_01.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.cb_gb_03_01.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.cb_gb_03_01.WaterColor = System.Drawing.Color.DarkGray;
            this.cb_gb_03_01.WaterText = "0";
            this.cb_gb_03_01.WordWrap = true;
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Name = "label19";
            // 
            // chk_gb_03
            // 
            resources.ApplyResources(this.chk_gb_03, "chk_gb_03");
            this.chk_gb_03.BackColor = System.Drawing.Color.Transparent;
            this.chk_gb_03.Name = "chk_gb_03";
            this.chk_gb_03.UseVisualStyleBackColor = false;
            // 
            // cb_gb_02_01
            // 
            resources.ApplyResources(this.cb_gb_02_01, "cb_gb_02_01");
            this.cb_gb_02_01.BackColor = System.Drawing.Color.Transparent;
            this.cb_gb_02_01.Icon = null;
            this.cb_gb_02_01.IconIsButton = false;
            this.cb_gb_02_01.IsPasswordChat = '\0';
            this.cb_gb_02_01.IsSystemPasswordChar = false;
            this.cb_gb_02_01.Lines = new string[] {
        "6"};
            this.cb_gb_02_01.MaxLength = 32767;
            this.cb_gb_02_01.Multiline = false;
            this.cb_gb_02_01.Name = "cb_gb_02_01";
            this.cb_gb_02_01.ReadOnly = false;
            this.cb_gb_02_01.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.cb_gb_02_01.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.cb_gb_02_01.WaterColor = System.Drawing.Color.DarkGray;
            this.cb_gb_02_01.WaterText = "0";
            this.cb_gb_02_01.WordWrap = true;
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Name = "label16";
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Name = "label17";
            // 
            // cb_gb_02_00
            // 
            resources.ApplyResources(this.cb_gb_02_00, "cb_gb_02_00");
            this.cb_gb_02_00.FormattingEnabled = true;
            this.cb_gb_02_00.Items.AddRange(new object[] {
            resources.GetString("cb_gb_02_00.Items"),
            resources.GetString("cb_gb_02_00.Items1")});
            this.cb_gb_02_00.Name = "cb_gb_02_00";
            // 
            // chk_gb_02
            // 
            resources.ApplyResources(this.chk_gb_02, "chk_gb_02");
            this.chk_gb_02.BackColor = System.Drawing.Color.Transparent;
            this.chk_gb_02.Name = "chk_gb_02";
            this.chk_gb_02.UseVisualStyleBackColor = false;
            // 
            // tb_gb_01_02
            // 
            resources.ApplyResources(this.tb_gb_01_02, "tb_gb_01_02");
            this.tb_gb_01_02.BackColor = System.Drawing.Color.Transparent;
            this.tb_gb_01_02.Icon = null;
            this.tb_gb_01_02.IconIsButton = false;
            this.tb_gb_01_02.IsPasswordChat = '\0';
            this.tb_gb_01_02.IsSystemPasswordChar = false;
            this.tb_gb_01_02.Lines = new string[0];
            this.tb_gb_01_02.MaxLength = 32767;
            this.tb_gb_01_02.Multiline = false;
            this.tb_gb_01_02.Name = "tb_gb_01_02";
            this.tb_gb_01_02.ReadOnly = false;
            this.tb_gb_01_02.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_gb_01_02.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_gb_01_02.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_gb_01_02.WaterText = "0000";
            this.tb_gb_01_02.WordWrap = true;
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Name = "label13";
            // 
            // tb_gb_01_01
            // 
            resources.ApplyResources(this.tb_gb_01_01, "tb_gb_01_01");
            this.tb_gb_01_01.BackColor = System.Drawing.Color.Transparent;
            this.tb_gb_01_01.Icon = null;
            this.tb_gb_01_01.IconIsButton = false;
            this.tb_gb_01_01.IsPasswordChat = '\0';
            this.tb_gb_01_01.IsSystemPasswordChar = false;
            this.tb_gb_01_01.Lines = new string[] {
        "0"};
            this.tb_gb_01_01.MaxLength = 32767;
            this.tb_gb_01_01.Multiline = false;
            this.tb_gb_01_01.Name = "tb_gb_01_01";
            this.tb_gb_01_01.ReadOnly = false;
            this.tb_gb_01_01.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_gb_01_01.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_gb_01_01.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_gb_01_01.WaterText = "0000";
            this.tb_gb_01_01.WordWrap = true;
            // 
            // cb_gb_01_00
            // 
            resources.ApplyResources(this.cb_gb_01_00, "cb_gb_01_00");
            this.cb_gb_01_00.AutoCompleteCustomSource.AddRange(new string[] {
            resources.GetString("cb_gb_01_00.AutoCompleteCustomSource"),
            resources.GetString("cb_gb_01_00.AutoCompleteCustomSource1"),
            resources.GetString("cb_gb_01_00.AutoCompleteCustomSource2"),
            resources.GetString("cb_gb_01_00.AutoCompleteCustomSource3")});
            this.cb_gb_01_00.FormattingEnabled = true;
            this.cb_gb_01_00.Items.AddRange(new object[] {
            resources.GetString("cb_gb_01_00.Items"),
            resources.GetString("cb_gb_01_00.Items1"),
            resources.GetString("cb_gb_01_00.Items2")});
            this.cb_gb_01_00.Name = "cb_gb_01_00";
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Name = "label14";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Name = "label15";
            // 
            // chk_gb_01
            // 
            resources.ApplyResources(this.chk_gb_01, "chk_gb_01");
            this.chk_gb_01.BackColor = System.Drawing.Color.Transparent;
            this.chk_gb_01.Name = "chk_gb_01";
            this.chk_gb_01.UseVisualStyleBackColor = false;
            // 
            // ReadTag_Param
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tc_Main);
            this.IsResize = false;
            this.Name = "ReadTag_Param";
            this.ShowIcon = false;
            this.Load += new System.EventHandler(this.ReadTag_Param_Load);
            this.tc_Main.ResumeLayout(false);
            this.tp_6C.ResumeLayout(false);
            this.tp_6C.PerformLayout();
            this.tp_6B.ResumeLayout(false);
            this.tp_6B.PerformLayout();
            this.tp_GB.ResumeLayout(false);
            this.tp_GB.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MyFormTemplet.QQTabControl tc_Main;
        private System.Windows.Forms.TabPage tp_6C;
        private MyFormTemplet.QQButton btn_Save_6C;
        private MyFormTemplet.QQTextBoxEx tb_04_01;
        private System.Windows.Forms.Label label8;
        private MyFormTemplet.QQTextBoxEx tb_04_00;
        private System.Windows.Forms.Label label9;
        private MyFormTemplet.QQTextBoxEx tb_03_01;
        private System.Windows.Forms.Label label7;
        private MyFormTemplet.QQTextBoxEx tb_03_00;
        private System.Windows.Forms.Label label6;
        private MyFormTemplet.QQCheckBox chk_04;
        private MyFormTemplet.QQCheckBox chk_03;
        private MyFormTemplet.QQTextBoxEx tb_02_01;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cb_02_00;
        private MyFormTemplet.QQCheckBox chk_02;
        private MyFormTemplet.QQTextBoxEx tb_01_02;
        private System.Windows.Forms.Label label2;
        private MyFormTemplet.QQTextBoxEx tb_01_01;
        private System.Windows.Forms.ComboBox cb_01_00;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lb_0010_11_MatchStart;
        private MyFormTemplet.QQCheckBox chk_01;
        private System.Windows.Forms.TabPage tp_6B;
        private MyFormTemplet.QQButton btn_Save_6B;
        private MyFormTemplet.QQTextBoxEx tb_0010_40_03;
        private MyFormTemplet.QQTextBoxEx tb_0010_40_02;
        private MyFormTemplet.QQTextBoxEx tb_0010_40_01;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cb_0010_40_00;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TabPage tp_GB;
        private MyFormTemplet.QQCheckBox chk_gb_01;
        private MyFormTemplet.QQTextBoxEx tb_gb_01_02;
        private System.Windows.Forms.Label label13;
        private MyFormTemplet.QQTextBoxEx tb_gb_01_01;
        private System.Windows.Forms.ComboBox cb_gb_01_00;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private MyFormTemplet.QQTextBoxEx cb_gb_02_01;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cb_gb_02_00;
        private MyFormTemplet.QQCheckBox chk_gb_02;
        private MyFormTemplet.QQCheckBox chk_gb_03;
        private MyFormTemplet.QQTextBoxEx cb_gb_03_02;
        private System.Windows.Forms.Label label18;
        private MyFormTemplet.QQTextBoxEx cb_gb_03_01;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private MyFormTemplet.QQTextBoxEx cb_gb_04_00;
        private MyFormTemplet.QQButton btn_Save_GB;
        private MyFormTemplet.QQCheckBox chk_05;
        private MyFormTemplet.QQTextBoxEx qqTextBoxEx1;
        private System.Windows.Forms.Label label22;
        private MyFormTemplet.QQTextBoxEx txt_subUserDataIndex;
        private System.Windows.Forms.Label label20;
        private MyFormTemplet.QQTextBoxEx tb_09_01;
        private System.Windows.Forms.Label label23;
        private MyFormTemplet.QQTextBoxEx tb_09_00;
        private System.Windows.Forms.Label label24;
        private MyFormTemplet.QQCheckBox chk_10;


    }
}