﻿namespace SimpleReaderDemo.MySingleForm.TestForm
{
    partial class Tag_Option6B
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tag_Option6B));
            this.tc_Main = new SimpleReaderDemo.MyFormTemplet.QQTabControl();
            this.tp_Main = new System.Windows.Forms.TabPage();
            this.gb_WriteTag = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_0010_41_00 = new System.Windows.Forms.TextBox();
            this.btn_0010_41 = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.tb_0010_41_01 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_0010_43 = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_0010_42_00 = new System.Windows.Forms.TextBox();
            this.btn_0010_42 = new SimpleReaderDemo.MyFormTemplet.QQButton();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.gb_TagMatch = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tb_TID = new SimpleReaderDemo.MyFormTemplet.QQTextBoxEx();
            this.tc_Main.SuspendLayout();
            this.tp_Main.SuspendLayout();
            this.gb_WriteTag.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gb_TagMatch.SuspendLayout();
            this.SuspendLayout();
            // 
            // tc_Main
            // 
            resources.ApplyResources(this.tc_Main, "tc_Main");
            this.tc_Main.BackColor = System.Drawing.Color.Transparent;
            this.tc_Main.BaseColor = System.Drawing.Color.White;
            this.tc_Main.BorderColor = System.Drawing.Color.White;
            this.tc_Main.Controls.Add(this.tp_Main);
            this.tc_Main.Controls.Add(this.tabPage1);
            this.tc_Main.Controls.Add(this.tabPage2);
            this.tc_Main.Name = "tc_Main";
            this.tc_Main.PageColor = System.Drawing.Color.White;
            this.tc_Main.SelectedIndex = 0;
            this.tc_Main.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            // 
            // tp_Main
            // 
            resources.ApplyResources(this.tp_Main, "tp_Main");
            this.tp_Main.BackColor = System.Drawing.Color.White;
            this.tp_Main.Controls.Add(this.gb_WriteTag);
            this.tp_Main.Name = "tp_Main";
            // 
            // gb_WriteTag
            // 
            resources.ApplyResources(this.gb_WriteTag, "gb_WriteTag");
            this.gb_WriteTag.Controls.Add(this.label6);
            this.gb_WriteTag.Controls.Add(this.tb_0010_41_00);
            this.gb_WriteTag.Controls.Add(this.btn_0010_41);
            this.gb_WriteTag.Controls.Add(this.tb_0010_41_01);
            this.gb_WriteTag.Controls.Add(this.label3);
            this.gb_WriteTag.Name = "gb_WriteTag";
            this.gb_WriteTag.TabStop = false;
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // tb_0010_41_00
            // 
            resources.ApplyResources(this.tb_0010_41_00, "tb_0010_41_00");
            this.tb_0010_41_00.Name = "tb_0010_41_00";
            // 
            // btn_0010_41
            // 
            resources.ApplyResources(this.btn_0010_41, "btn_0010_41");
            this.btn_0010_41.BackColor = System.Drawing.Color.Transparent;
            this.btn_0010_41.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_41.DownImage")));
            this.btn_0010_41.IsShowBorder = true;
            this.btn_0010_41.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_41.MoveImage")));
            this.btn_0010_41.Name = "btn_0010_41";
            this.btn_0010_41.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_41.NormalImage")));
            this.btn_0010_41.UseVisualStyleBackColor = true;
            this.btn_0010_41.Click += new System.EventHandler(this.btn_0010_41_Click);
            // 
            // tb_0010_41_01
            // 
            resources.ApplyResources(this.tb_0010_41_01, "tb_0010_41_01");
            this.tb_0010_41_01.Name = "tb_0010_41_01";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // tabPage1
            // 
            resources.ApplyResources(this.tabPage1, "tabPage1");
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Name = "tabPage1";
            // 
            // groupBox1
            // 
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Controls.Add(this.btn_0010_43);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.tb_0010_42_00);
            this.groupBox1.Controls.Add(this.btn_0010_42);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // btn_0010_43
            // 
            resources.ApplyResources(this.btn_0010_43, "btn_0010_43");
            this.btn_0010_43.BackColor = System.Drawing.Color.Transparent;
            this.btn_0010_43.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_43.DownImage")));
            this.btn_0010_43.IsShowBorder = true;
            this.btn_0010_43.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_43.MoveImage")));
            this.btn_0010_43.Name = "btn_0010_43";
            this.btn_0010_43.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_43.NormalImage")));
            this.btn_0010_43.UseVisualStyleBackColor = true;
            this.btn_0010_43.Click += new System.EventHandler(this.btn_0010_43_Click);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // tb_0010_42_00
            // 
            resources.ApplyResources(this.tb_0010_42_00, "tb_0010_42_00");
            this.tb_0010_42_00.Name = "tb_0010_42_00";
            // 
            // btn_0010_42
            // 
            resources.ApplyResources(this.btn_0010_42, "btn_0010_42");
            this.btn_0010_42.BackColor = System.Drawing.Color.Transparent;
            this.btn_0010_42.DownImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_42.DownImage")));
            this.btn_0010_42.IsShowBorder = true;
            this.btn_0010_42.MoveImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_42.MoveImage")));
            this.btn_0010_42.Name = "btn_0010_42";
            this.btn_0010_42.NormalImage = ((System.Drawing.Image)(resources.GetObject("btn_0010_42.NormalImage")));
            this.btn_0010_42.UseVisualStyleBackColor = true;
            this.btn_0010_42.Click += new System.EventHandler(this.btn_0010_42_Click);
            // 
            // tabPage2
            // 
            resources.ApplyResources(this.tabPage2, "tabPage2");
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Name = "tabPage2";
            // 
            // gb_TagMatch
            // 
            resources.ApplyResources(this.gb_TagMatch, "gb_TagMatch");
            this.gb_TagMatch.BackColor = System.Drawing.Color.Transparent;
            this.gb_TagMatch.Controls.Add(this.label10);
            this.gb_TagMatch.Controls.Add(this.tb_TID);
            this.gb_TagMatch.Name = "gb_TagMatch";
            this.gb_TagMatch.TabStop = false;
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // tb_TID
            // 
            resources.ApplyResources(this.tb_TID, "tb_TID");
            this.tb_TID.BackColor = System.Drawing.Color.Transparent;
            this.tb_TID.Icon = null;
            this.tb_TID.IconIsButton = false;
            this.tb_TID.IsPasswordChat = '\0';
            this.tb_TID.IsSystemPasswordChar = false;
            this.tb_TID.Lines = new string[0];
            this.tb_TID.MaxLength = 32767;
            this.tb_TID.Multiline = false;
            this.tb_TID.Name = "tb_TID";
            this.tb_TID.ReadOnly = false;
            this.tb_TID.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_TID.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tb_TID.WaterColor = System.Drawing.Color.DarkGray;
            this.tb_TID.WaterText = "0000";
            this.tb_TID.WordWrap = true;
            // 
            // Tag_Option6B
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gb_TagMatch);
            this.Controls.Add(this.tc_Main);
            this.IsResize = false;
            this.Name = "Tag_Option6B";
            this.ShowIcon = false;
            this.SysButton = SimpleReaderDemo.Forms.ESysButton.Close;
            this.tc_Main.ResumeLayout(false);
            this.tp_Main.ResumeLayout(false);
            this.gb_WriteTag.ResumeLayout(false);
            this.gb_WriteTag.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gb_TagMatch.ResumeLayout(false);
            this.gb_TagMatch.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MyFormTemplet.QQTabControl tc_Main;
        private System.Windows.Forms.TabPage tp_Main;
        private System.Windows.Forms.GroupBox gb_WriteTag;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_0010_41_00;
        private MyFormTemplet.QQButton btn_0010_41;
        private System.Windows.Forms.TextBox tb_0010_41_01;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox1;
        private MyFormTemplet.QQButton btn_0010_42;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox gb_TagMatch;
        private System.Windows.Forms.Label label10;
        private MyFormTemplet.QQTextBoxEx tb_TID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_0010_42_00;
        private MyFormTemplet.QQButton btn_0010_43;
    }
}