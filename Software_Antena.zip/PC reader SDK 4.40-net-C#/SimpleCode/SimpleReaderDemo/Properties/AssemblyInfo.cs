﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General information about the assembly is controlled by the following feature set.
// Changing the values of these properties can modify
// 与the information associated with the assembly.
[assembly: AssemblyTitle("SimpleReaderDemo")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("HopeLand ShenZhen")]
[assembly: AssemblyProduct("SimpleReaderDemo")]
[assembly: AssemblyCopyright("Copyright © SZclou 2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly invisible to COM components.
// If you need to access the type in this assembly from COM,
// set the ComVisible attribute on the type to true.
[assembly: ComVisible(false)]

// If this project is exposed to COM, the following GUID is used for the ID of the type library
[assembly: Guid("cd48546f-4097-43c9-9a74-f2450702b64c")]

// The version information of the assembly consists of the following four values:
//
//      Major version
//      Minor version 
//      Internal version number
//      Amendment No
//
// You can specify all of these values, or you can use the default values of 
// "Build Number" and "Revision Number" by using "*" as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.4.0.0")]
[assembly: AssemblyFileVersion("1.4.0.0")]
